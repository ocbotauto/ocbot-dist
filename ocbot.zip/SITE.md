# Сайт с лучшими пресетами (GitHub Pages)

Бот сам отправляет каталог пресетов в ваш репозиторий GitHub, сайт на GitHub Pages показывает его. Руками ничего
загружать не нужно: после каждого нового проверенного пресета бот через минуту обновляет файл `catalog.json`.
В файле нет UUID карт и имён ригов; каждый риг подписан короткой меткой.

## Один раз: сайт

1. На github.com создайте репозиторий с именем `ocbot-site`, публичный: так страница откроется по ссылке без входа.
2. Загрузите в него **всё содержимое папки `site/` из архива бота** (все файлы и подпапку `assets/`), сохраняя
   структуру: страницы `index.html`/`index.ru.html`, `catalog.html`/`catalog.ru.html`, `guide.html`/`guide.ru.html`
   (а `guide.en.html` — короткая переадреска на `guide.html` для старых ссылок), `buy.html`/`buy.ru.html`,
   `status.html`/`status.ru.html`, страницы моделей (`rtx-*.html`/`rtx-*.ru.html`), `assets/*.css`, `sitemap.xml`,
   `robots.txt`, `revoked.json` (список отозванных лицензий, бот читает его оттуда) и `chat.js`/`chat.en.js`.
   Проще всего через git (`git init`, `git add .`, `git commit`, `git push`), чем через Add file → Upload files:
   веб-интерфейс GitHub не умеет загружать вложенную папку `assets/` одним действием. Имена и пути не меняйте.
3. Settings → Pages → Source: Deploy from a branch → ветка `main`, папка `/ (root)` → Save.
   Через минуту сайт откроется по адресу `https://ВАШ_ЛОГИН.github.io/ocbot-site/`.
4. Необязательно: в папке лежит `.github/workflows/models.yml` — раз в сутки сам перестраивает страницы моделей
   из общего каталога. Для него нужно задать в репозитории (Settings → Secrets and variables → Actions → Variables)
   переменные `CATALOG_URL` (адрес приёмника общего каталога) и `SITE_BASE` (адрес вашего сайта с `/` на конце).
   Без них просто ничего не запустится — на остальной сайт это не влияет.

## Один раз: токен для бота

1. github.com → Settings → Developer settings → Personal access tokens → Fine-grained tokens → Generate new token.
2. Repository access: Only select repositories → ваш репозиторий. Permissions → Repository permissions → Contents: Read and write.
3. Скопируйте токен (показывается один раз). Токен только на этот репозиторий: больше он ничего не может.

## На каждом риге

    cd /root/ocbot
    python3 -m ocbot --config config.json --github-set ВАШ_ЛОГИН/ocbot-site 'ТОКЕН' rig1
    python3 -m ocbot --config config.json --service restart

Третий параметр (`rig1`) это метка источника на сайте; без неё берётся короткий код, имя рига наружу не уходит.
Команда `--github-set` сразу обновляет каталог и пишет результат. Проверить вручную в любой момент:

    python3 -m ocbot --config config.json --catalog-publish

Токен не вставляйте в чат и не публикуйте: он записывается в конфиг (доступен только владельцу).

## Как это работает

- Риг читает файл `catalog.json` из репозитория, заменяет в нём только свои записи и сохраняет; записи других ригов остаются.
- Файл можно скачать и принять в бота другого человека: `--catalog-import catalog.json`.
- Если GitHub недоступен, бот пишет в лог причину и повторяет при следующем обновлении, работа рига не страдает.
- Новый пресет на сайте появляется примерно через минуту после проверки, страница при открытии берёт свежий файл.
