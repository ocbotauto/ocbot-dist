import hashlib
p = 2 ** 255 - 19
q = 2 ** 252 + 27742317777372353535851937790883648493

def _sha512(s: bytes) -> bytes:
    return hashlib.sha512(s).digest()

def _inv(x: int) -> int:
    return pow(x, p - 2, p)
_d = -121665 * _inv(121666) % p
_sqrt_m1 = pow(2, (p - 1) // 4, p)

def _add(P, Q):
    A = (P[1] - P[0]) * (Q[1] - Q[0]) % p
    B = (P[1] + P[0]) * (Q[1] + Q[0]) % p
    C = 2 * P[3] * Q[3] * _d % p
    D = 2 * P[2] * Q[2] % p
    E, F, G_, H = (B - A, D - C, D + C, B + A)
    return (E * F % p, G_ * H % p, F * G_ % p, E * H % p)

def _mul(s: int, P):
    Q = (0, 1, 1, 0)
    while s > 0:
        if s & 1:
            Q = _add(Q, P)
        P = _add(P, P)
        s >>= 1
    return Q

def _eq(P, Q) -> bool:
    return (P[0] * Q[2] - Q[0] * P[2]) % p == 0 and (P[1] * Q[2] - Q[1] * P[2]) % p == 0

def _recover_x(y: int, sign: int):
    if y >= p:
        return None
    x2 = (y * y - 1) * _inv(_d * y * y + 1) % p
    if x2 == 0:
        return None if sign else 0
    x = pow(x2, (p + 3) // 8, p)
    if (x * x - x2) % p != 0:
        x = x * _sqrt_m1 % p
    if (x * x - x2) % p != 0:
        return None
    if x & 1 != sign:
        x = p - x
    return x
_gy = 4 * _inv(5) % p
_gx = _recover_x(_gy, 0)
G = (_gx, _gy, 1, _gx * _gy % p)

def _compress(P) -> bytes:
    zinv = _inv(P[2])
    x, y = (P[0] * zinv % p, P[1] * zinv % p)
    return int.to_bytes(y | (x & 1) << 255, 32, 'little')

def _decompress(s: bytes):
    y = int.from_bytes(s, 'little')
    sign, y = (y >> 255, y & (1 << 255) - 1)
    x = _recover_x(y, sign)
    return None if x is None else (x, y, 1, x * y % p)

def _expand(secret: bytes):
    h = _sha512(secret)
    a = int.from_bytes(h[:32], 'little')
    a &= (1 << 254) - 8
    a |= 1 << 254
    return (a, h[32:])

def public_key(secret: bytes) -> bytes:
    a, _ = _expand(secret)
    return _compress(_mul(a, G))

def sign(secret: bytes, msg: bytes) -> bytes:
    a, prefix = _expand(secret)
    A = _compress(_mul(a, G))
    r = int.from_bytes(_sha512(prefix + msg), 'little') % q
    Rs = _compress(_mul(r, G))
    h = int.from_bytes(_sha512(Rs + A + msg), 'little') % q
    return Rs + int.to_bytes((r + h * a) % q, 32, 'little')

def verify(public: bytes, msg: bytes, signature: bytes) -> bool:
    if len(public) != 32 or len(signature) != 64:
        return False
    A = _decompress(public)
    R = _decompress(signature[:32])
    if A is None or R is None:
        return False
    s = int.from_bytes(signature[32:], 'little')
    if s >= q:
        return False
    h = int.from_bytes(_sha512(signature[:32] + public + msg), 'little') % q
    return _eq(_mul(s, G), _add(R, _mul(h, A)))
