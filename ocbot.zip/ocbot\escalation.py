from __future__ import annotations
from enum import Enum
from .db import DB, utcnow

class Action(Enum):
    REBOOT_NOW = 'reboot_now'
    REBOOT_DELAYED = 'reboot_delayed'
    MARK = 'mark'

def next_action(db: DB, uuid: str, fast_attempts: int, allow_delayed: bool=True) -> Action:
    row = db.escalation(uuid)
    ts = utcnow()
    if row['reboot_attempts'] < fast_attempts:
        db.set_escalation(uuid, reboot_attempts=row['reboot_attempts'] + 1, last_event_ts=ts)
        return Action.REBOOT_NOW
    if allow_delayed and (not row['delayed_done']):
        db.set_escalation(uuid, delayed_done=1, last_event_ts=ts)
        return Action.REBOOT_DELAYED
    db.set_escalation(uuid, last_event_ts=ts)
    return Action.MARK

def reset(db: DB, uuid: str) -> None:
    db.set_escalation(uuid, reboot_attempts=0, delayed_done=0, reset_ts=utcnow())
