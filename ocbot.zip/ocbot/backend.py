from __future__ import annotations
import json
import logging
import os
import re
import signal
import subprocess
import time
from dataclasses import dataclass
from typing import Callable, Optional
log = logging.getLogger(__name__)
THERMAL_BITS = 32 | 64

class BackendError(RuntimeError):
    pass

class CommandTimeout(BackendError):
    pass

def ensure_kernel_panic(seconds: int=10) -> bool:
    try:
        with open('/proc/sys/kernel/panic', 'w') as f:
            f.write(str(seconds))
        return True
    except OSError:
        return False

@dataclass
class GpuInfo:
    index: int
    uuid: str
    model: str
    vbios: str
    bus_id: str
    mem_vendor: Optional[str] = None
    mem_mb: Optional[int] = None
    board: Optional[str] = None

    @property
    def slot(self) -> int:
        return self.index

@dataclass
class Sample:
    hashrate: float = 0.0
    power_w: float = 0.0
    temp_core: float = 0.0
    temp_mem: Optional[float] = None
    thermal_throttle: bool = False
    invalid_pct: float = 0.0
    lost: bool = False
    uptime_s: Optional[float] = None

def system_boot_time() -> Optional[float]:
    try:
        with open('/proc/uptime') as f:
            return time.time() - float(f.read().split()[0])
    except (OSError, ValueError, IndexError):
        return None

def bus_key(bus: str) -> str:
    m = re.search('([0-9a-fA-F]{2}:[0-9a-fA-F]{2})(?:\\.\\d)?$', bus.strip())
    return m.group(1).lower() if m else bus.lower()

def _num(s: str) -> Optional[float]:
    s = s.strip().strip('[]')
    try:
        return float(s)
    except ValueError:
        return None

class NvidiaBackend:

    def boot_time(self) -> Optional[float]:
        return system_boot_time()

    def __init__(self, cfg, runner: Optional[Callable]=None):
        self.cfg = cfg
        self._raw_run = runner or self._run
        self.run = self._counted_run
        self.hang_counts: dict = {}
        self.hang_count = 0
        self._by_uuid: dict = {}
        self._boards: dict = {}
        self._gs: dict = {}
        self._gs_ts: float = -1000000000.0
        self._power_src: dict = {}
        self._xmap: dict = {}

    def _hang_key(self, cmd) -> Optional[str]:
        if isinstance(cmd, (list, tuple)) and cmd and (cmd[0] == 'nvidia-smi'):
            if '-i' in cmd:
                i = list(cmd).index('-i')
                if i + 1 < len(cmd):
                    return f'i{cmd[i + 1]}'
            return 'ALL'
        prefix = getattr(self.cfg, 'nvidia_settings_prefix', '') or ''
        if isinstance(cmd, str) and prefix and cmd.startswith(prefix):
            m = re.search('\\[gpu:(\\d+)\\]', cmd)
            if not m:
                return 'ALL'
            x = int(m.group(1))
            for u, xi in self._xmap.items():
                if xi == x:
                    return f'u{u}'
            return f'x{x}'
        return None

    def _counted_run(self, cmd, *a, **kw):
        key = self._hang_key(cmd)
        try:
            out = self._raw_run(cmd, *a, **kw)
        except CommandTimeout:
            if key:
                self.hang_counts[key] = self.hang_counts.get(key, 0) + 1
                self.hang_count = max(self.hang_counts.values())
            raise
        if key:
            self.hang_counts[key] = 0
            self.hang_count = max(self.hang_counts.values(), default=0)
        return out
    HIVE_PATH = '/hive/bin:/hive/sbin:/usr/local/bin:/usr/local/sbin:/usr/sbin:/sbin'
    ETC_ENV = '/etc/environment'
    HIVE_ENV_FALLBACKS = {'RIG_CONF': '/hive-config/rig.conf', 'WALLET_CONF': '/hive-config/wallet.conf'}

    @classmethod
    def _env(cls) -> dict:
        env = dict(os.environ)
        try:
            with open(cls.ETC_ENV, encoding='utf-8', errors='replace') as f:
                for line in f:
                    line = line.strip()
                    if line and (not line.startswith('#')) and ('=' in line):
                        k, _, v = line.partition('=')
                        env.setdefault(k.strip(), v.strip().strip('"').strip("'"))
        except OSError:
            pass
        for k, v in cls.HIVE_ENV_FALLBACKS.items():
            env.setdefault(k, v)
        have = env.get('PATH', '').split(':')
        env['PATH'] = ':'.join([p for p in have if p] + [p for p in cls.HIVE_PATH.split(':') if p not in have])
        return env

    @classmethod
    def _run(cls, cmd, timeout: int=30) -> str:
        p = subprocess.Popen(cmd, shell=isinstance(cmd, str), stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, env=cls._env(), start_new_session=True)
        try:
            out, err = p.communicate(timeout=timeout)
        except subprocess.TimeoutExpired:
            try:
                os.killpg(os.getpgid(p.pid), signal.SIGKILL)
            except Exception:
                try:
                    p.kill()
                except Exception:
                    pass
            try:
                p.communicate(timeout=10)
            except Exception:
                pass
            raise CommandTimeout(f'{cmd!r}: нет ответа за {timeout} с')
        if p.returncode != 0:
            raise BackendError(f'{cmd!r}: {err.strip()[:200]}')
        return out

    def list_gpus(self) -> list:
        out = self.run(['nvidia-smi', '--query-gpu=index,uuid,name,vbios_version,pci.bus_id,memory.total', '--format=csv,noheader'])
        gpus = []
        for ln in out.strip().splitlines():
            idx, uuid, name, vbios, bus, mem = [x.strip() for x in ln.split(', ')]
            try:
                mem_mb = int(float(mem.split()[0]))
            except (ValueError, IndexError):
                mem_mb = None
            gpus.append(GpuInfo(int(idx), uuid, name, vbios, bus, self.cfg.mem_vendor_by_uuid.get(uuid), mem_mb, self._board(bus)))
        self._by_uuid = {g.uuid: g for g in gpus}
        return gpus
    BOARDS = (('micro-star', 'MSI'), ('asustek', 'ASUS'), ('asus', 'ASUS'), ('gigabyte', 'Gigabyte'), ('palit', 'Palit'), ('gainward', 'Gainward'), ('zotac', 'Zotac'), ('evga', 'EVGA'), ('colorful', 'Colorful'), ('inno3d', 'Inno3D'), ('pny', 'PNY'), ('galax', 'Galax'), ('kfa2', 'KFA2'), ('sapphire', 'Sapphire'), ('powercolor', 'PowerColor'))

    def _board(self, bus: str) -> Optional[str]:
        if bus in self._boards:
            return self._boards[bus]
        name = None
        try:
            short = re.sub('^[0-9a-fA-F]{4,8}:', '', bus.strip())
            out = self.run(['lspci', '-s', short, '-vmm'])
            m = re.search('^SVendor:\\s*(.+)$', out, re.M)
            if m:
                raw = m.group(1).strip()
                low = raw.lower()
                name = next((v for k, v in self.BOARDS if k in low), None)
                if not name:
                    name = re.sub('[,.]|\\b(Inc|Co|Ltd|Corporation|Corp|International|Microsystems|Technology)\\b', '', raw).split()[0]
        except Exception:
            name = None
        self._boards[bus] = name
        return name

    def _idx(self, uuid: str) -> int:
        if uuid not in self._by_uuid:
            self.list_gpus()
        if uuid not in self._by_uuid:
            raise BackendError(f'карта {uuid} не видна в nvidia-smi')
        return self._by_uuid[uuid].index

    def driver_version(self) -> Optional[str]:
        try:
            return self.run(['nvidia-smi', '--query-gpu=driver_version', '--format=csv,noheader']).splitlines()[0].strip()
        except (BackendError, IndexError):
            return None

    def power_limits(self, uuid: str) -> tuple:
        i = self._idx(uuid)
        out = self.run(['nvidia-smi', '-i', str(i), '--query-gpu=power.min_limit,power.default_limit,power.max_limit', '--format=csv,noheader,nounits'])
        try:
            lo, df, hi = (int(float(x)) for x in out.strip().split(','))
        except ValueError:
            raise BackendError(f'карта {uuid}: nvidia-smi не отдал лимиты питания числом ({out.strip()!r}) — карта в нерабочем состоянии')
        return (lo, df, hi)

    @staticmethod
    def parse_xgpus(text: str) -> dict:
        out, cur = ({}, None)
        for ln in text.splitlines():
            m = re.search('\\[gpu:(\\d+)\\]', ln)
            if m:
                cur = int(m.group(1))
                continue
            m = re.search('(GPU-[0-9a-fA-F]{8}-[0-9a-fA-F-]{27})', ln)
            if m and cur is not None:
                out[m.group(1)] = cur
        return out

    def _xindex(self, uuid: str) -> int:
        i = self._idx(uuid)
        if uuid not in self._xmap:
            try:
                self._xmap = self.parse_xgpus(self.run(f'{self.cfg.nvidia_settings_prefix} -q gpus'))
            except BackendError:
                return i
            if not self._xmap:
                return i
        if uuid not in self._xmap:
            raise BackendError(f'карта {uuid} не видна X-серверу: No targets match target specification (nvidia-settings)')
        return self._xmap[uuid]

    def x_visible(self, uuid: str) -> bool:
        try:
            self._xindex(uuid)
        except BackendError as e:
            return 'no targets match' not in str(e).lower()
        return True

    def apply(self, uuid: str, core: int, mem: int, pl: int, fan: Optional[int]) -> None:
        i = self._idx(uuid)
        x = self._xindex(uuid)
        self.run(['nvidia-smi', '-i', str(i), '-pl', str(int(pl))])
        parts = [f"-a '[gpu:{x}]/GPUGraphicsClockOffsetAllPerformanceLevels={int(core)}'", f"-a '[gpu:{x}]/GPUMemoryTransferRateOffsetAllPerformanceLevels={int(mem)}'"]
        if fan is not None:
            parts += [f"-a '[gpu:{x}]/GPUFanControlState=1'", f"-a '[fan:{x}]/GPUTargetFanSpeed={int(fan)}'"]
        try:
            self.run(f'{self.cfg.nvidia_settings_prefix} ' + ' '.join(parts))
        except BackendError:
            self._xmap = {}
            raise

    def clocks(self, uuid: str):
        i = self._idx(uuid)
        try:
            out = self.run(['nvidia-smi', '-i', str(i), '--query-gpu=clocks.current.graphics,clocks.current.memory', '--format=csv,noheader,nounits'])
            gr, mem = (int(float(x)) for x in out.strip().splitlines()[0].split(','))
            return (gr, mem)
        except (BackendError, ValueError, IndexError):
            return None

    def supported_clocks(self, uuid: str) -> dict:
        from .clocklock import parse_supported
        i = self._idx(uuid)
        try:
            return parse_supported(self.run(['nvidia-smi', '-i', str(i), '--query-supported-clocks=mem,gr', '--format=csv,noheader,nounits']))
        except BackendError:
            return {}

    def lock_clocks(self, uuid: str, core, mem) -> str:
        i = self._idx(uuid)
        warn = ''
        if core:
            self.run(['nvidia-smi', '-i', str(i), '-lgc', f'{int(core)},{int(core)}'])
        if mem:
            try:
                self.run(['nvidia-smi', '-i', str(i), '-lmc', f'{int(mem)},{int(mem)}'])
            except BackendError as e:
                warn = f'фиксация памяти {mem} МГц не принята: {e}'
        return warn

    def unlock_clocks(self, uuid: str) -> None:
        i = self._idx(uuid)
        for flag in ('-rgc', '-rmc'):
            try:
                self.run(['nvidia-smi', '-i', str(i), flag])
            except BackendError:
                pass

    def sample(self, uuid: str) -> Sample:
        try:
            i = self._idx(uuid)
        except BackendError:
            return Sample(lost=True)
        out = self.run(['nvidia-smi', '-i', str(i), '--query-gpu=power.draw,temperature.gpu,temperature.memory', '--format=csv,noheader,nounits'])
        pw, tc, tm = (_num(x) for x in out.strip().split(','))
        if pw is None:
            pw = self._power_fallback(i)
        if tm is None:
            tm = self._hive_memtemp(i)
        thermal = False
        for field in ('clocks_throttle_reasons.active', 'clocks_event_reasons.active'):
            try:
                v = self.run(['nvidia-smi', '-i', str(i), f'--query-gpu={field}', '--format=csv,noheader']).strip()
                thermal = bool(int(v, 16) & THERMAL_BITS)
                break
            except (BackendError, ValueError):
                continue
        hs, invalid, up = self._miner_stats(i)
        return Sample(hs, pw or 0.0, tc or 0.0, tm, thermal, invalid, uptime_s=up)

    def _power_fallback(self, i: int) -> Optional[float]:
        for field in ('power.draw.instant', 'power.draw.average'):
            try:
                v = _num(self.run(['nvidia-smi', '-i', str(i), f'--query-gpu={field}', '--format=csv,noheader,nounits']))
            except BackendError:
                continue
            if v:
                self._note_power_src(i, field)
                return v
        v = self._power_samples_avg(i)
        if v:
            self._note_power_src(i, 'power_samples.avg')
            return v
        try:
            v = _num(self.run(['nvidia-smi', '-i', str(i), '--query-gpu=power.limit', '--format=csv,noheader,nounits']))
        except BackendError:
            v = None
        if v:
            self._note_power_src(i, 'power.limit')
            return v
        return None

    def _power_samples_avg(self, i: int) -> Optional[float]:
        try:
            out = self.run(['nvidia-smi', '-i', str(i), '-q', '-d', 'POWER'])
        except BackendError:
            return None
        m = re.search('Power Samples.*?Avg\\s*:\\s*([\\d.]+)\\s*W', out, re.S)
        return float(m.group(1)) if m else None

    def _note_power_src(self, i: int, field: str) -> None:
        if self._power_src.get(i) != field:
            self._power_src[i] = field
            log.warning('карта %s: power.draw недоступен, мощность берётся из %s%s', i, field, ' (это лимит, а не замер)' if field == 'power.limit' else '')

    def _hive_memtemp(self, index: int) -> Optional[float]:
        cmd = self.cfg.gpu_stats_cmd
        if not cmd:
            return None
        now = time.monotonic()
        if now - self._gs_ts > 5:
            try:
                self._gs = json.loads(self.run(cmd))
            except (BackendError, ValueError):
                self._gs = {}
            self._gs_ts = now
        try:
            v = float(self._gs.get('mtemp', [])[index])
        except (IndexError, ValueError, TypeError, AttributeError):
            return None
        return v if v > 0 else None

    def _miner_stats(self, index: int) -> tuple:
        if not self.cfg.stats_cmd:
            raise BackendError('не задан stats_cmd: нечем измерять хешрейт')
        try:
            data = json.loads(self.run(self.cfg.stats_cmd))
        except (BackendError, ValueError) as e:
            self._stats_fail = getattr(self, '_stats_fail', 0) + 1
            if self._stats_fail == 1 or self._stats_fail % 30 == 0:
                log.warning('статистика майнера недоступна (%s), считаю хешрейт нулевым (подряд сбоев: %s)', str(e)[:160], self._stats_fail)
            return (0.0, 0.0, None)
        self._stats_fail = 0
        row = data.get(str(index), {}) if isinstance(data, dict) else {}
        up = row.get('uptime_s')
        return (float(row.get('hashrate', 0.0)), float(row.get('invalid_pct', 0.0)), float(up) if up is not None else None)

    def total_hashrate(self) -> Optional[float]:
        if not self.cfg.stats_cmd:
            return None
        try:
            data = json.loads(self.run(self.cfg.stats_cmd))
            return sum((float(v.get('hashrate', 0.0) or 0.0) for v in data.values())) if isinstance(data, dict) else None
        except (BackendError, ValueError, AttributeError, TypeError):
            return None

    def power_draws(self) -> dict:
        out = self.run(['nvidia-smi', '--query-gpu=uuid,power.draw', '--format=csv,noheader,nounits'])
        res = {}
        for ln in out.strip().splitlines():
            u, _, w = ln.partition(',')
            val = _num(w)
            u = u.strip()
            if val is None and u in self._by_uuid:
                val = self._power_fallback(self._by_uuid[u].index)
            if val is not None:
                res[u] = val
        return res

    def cpu_temp(self) -> 'Optional[float]':
        import glob
        best = None
        for z in glob.glob('/sys/class/thermal/thermal_zone*/temp'):
            try:
                with open(z) as f:
                    t = int(f.read().strip()) / 1000.0
            except (OSError, ValueError):
                continue
            if best is None or t > best:
                best = t
        return best

    def xids(self) -> list:
        try:
            out = self.run("dmesg | grep -i 'NVRM: Xid' || true")
        except BackendError:
            return []
        res = []
        for ln in out.splitlines():
            m = re.search('Xid \\(PCI:([0-9a-fA-F:]+)\\): (\\d+)', ln)
            if m:
                res.append({'bus': m.group(1), 'code': int(m.group(2)), 'line': ln.strip()})
        return res

    def miner(self, action: str) -> None:
        self.run(self.cfg.miner_stop_cmd if action == 'stop' else self.cfg.miner_start_cmd, timeout=120)

    def reboot(self, force: bool=False) -> None:
        self.run('reboot -f' if force else 'reboot')
        time.sleep(3600)
