from __future__ import annotations
'Дополнительные каналы оповещений, помимо Telegram (который остаётся основным и всегда\nвключён отдельно, этот модуль о нём не знает). Покупатель сам включает нужные каналы\nкомандой /notify в Telegram (bot.py) — здесь только сами отправители и общий broadcast().\n\nНамеренно НЕ показывается на установке и не требует отдельного вопроса в мастере — ленивому\nпокупателю незачем видеть лишний текст про вебхуки при первом запуске; канал появляется,\nтолько если его сами явно попросили через /notify.'
import json
import logging
import urllib.error
import urllib.request
from typing import Callable, Dict, List, Tuple
log = logging.getLogger('ocbot')

def _post(url: str, data: bytes, headers: Dict[str, str], timeout: float=8.0) -> None:
    req = urllib.request.Request(url, data=data, headers=headers, method='POST')
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        resp.read()

def send_webhook(url: str, rig: str, text: str, post: Callable=_post) -> None:
    payload = json.dumps({'rig': rig, 'text': text}, ensure_ascii=False).encode('utf-8')
    post(url, payload, {'Content-Type': 'application/json'})

def send_discord(url: str, rig: str, text: str, post: Callable=_post) -> None:
    content = f'**{rig}**: {text}'
    if len(content) > 1900:
        content = content[:1897] + '...'
    payload = json.dumps({'content': content}, ensure_ascii=False).encode('utf-8')
    post(url, payload, {'Content-Type': 'application/json'})
MAX_API = 'https://platform-api2.max.ru'

def _get(url: str, headers: Dict[str, str], timeout: float=8.0) -> bytes:
    req = urllib.request.Request(url, headers=headers, method='GET')
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read()

def _ntfy_headers(url: str) -> Dict[str, str]:
    from urllib.parse import urlsplit, parse_qs
    token = (parse_qs(urlsplit(url).query).get('token') or [''])[0].strip()
    return {'Authorization': f'Bearer {token}'} if token else {}

def send_ntfy(url: str, rig: str, text: str, post: Callable=_post) -> None:
    headers = {'Content-Type': 'text/plain; charset=utf-8'}
    try:
        title = rig.encode('ascii')
        headers['Title'] = title.decode('ascii')
    except UnicodeEncodeError:
        headers['Title'] = 'OCBot'
    headers.update(_ntfy_headers(url))
    post(url, text.encode('utf-8'), headers)

def poll_ntfy(url: str, since: str, get: Callable=_get) -> Tuple[List[str], str]:
    base, _, query = url.partition('?')
    qs = f'{query}&poll=1&since={since}' if query else f'poll=1&since={since}'
    raw = get(f'{base}/json?{qs}', _ntfy_headers(url))
    msgs: List[str] = []
    marker = since
    for line in raw.decode('utf-8', 'replace').splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            j = json.loads(line)
        except ValueError:
            continue
        if j.get('event') != 'message':
            continue
        text = (j.get('message') or '').strip()
        if text:
            msgs.append(text)
        marker = j.get('id') or marker
    return (msgs, marker)

def send_max(url: str, rig: str, text: str, post: Callable=_post) -> None:
    from urllib.parse import quote as urlquote
    chat_id, token = _max_parse(url)
    content = f'[{rig}] {text}'
    if len(content) > 3900:
        content = content[:3897] + '...'
    req_url = f'{MAX_API}/messages?chat_id={urlquote(chat_id)}'
    payload = json.dumps({'text': content}, ensure_ascii=False).encode('utf-8')
    post(req_url, payload, {'Content-Type': 'application/json', 'Authorization': token})

def _max_parse(url: str) -> Tuple[str, str]:
    from urllib.parse import urlsplit, parse_qs, unquote
    parts = urlsplit(url)
    if parts.scheme != 'max':
        raise ValueError('MAX-канал настраивается в формате max://<chat_id>?token=<токен>')
    chat_id = unquote(parts.netloc).strip()
    token = (parse_qs(parts.query).get('token') or [''])[0].strip()
    if not chat_id or not token:
        raise ValueError('в MAX-канале нет chat_id или токена бота')
    return (chat_id, token)

def poll_max(url: str, marker: str, get: Callable=_get) -> Tuple[List[str], str]:
    chat_id, token = _max_parse(url)
    tail = f'&marker={marker}' if marker else ''
    raw = get(f'{MAX_API}/updates?timeout=0&types=message_created{tail}', {'Authorization': token})
    out = json.loads(raw)
    msgs: List[str] = []
    next_marker = str(out.get('marker') or marker or '')
    for upd in out.get('updates') or []:
        if upd.get('update_type') != 'message_created':
            continue
        m = upd.get('message') or {}
        sender = m.get('sender') or {}
        rcpt = m.get('recipient') or {}
        if sender.get('is_bot'):
            continue
        mine = str(rcpt.get('chat_id') or '') == chat_id or str(sender.get('user_id') or '') == chat_id
        if not mine:
            continue
        text = ((m.get('body') or {}).get('text') or '').strip()
        if text:
            msgs.append(text)
    return (msgs, next_marker)

def detect_max_chat_id(token: str, get: Callable=_get) -> str:
    try:
        out = json.loads(get(f'{MAX_API}/updates?timeout=0', {'Authorization': token}))
    except Exception:
        return ''
    for upd in out.get('updates') or []:
        if upd.get('update_type') == 'bot_added' and upd.get('chat_id'):
            return str(upd['chat_id'])
        m = upd.get('message') or {}
        chat = str((m.get('recipient') or {}).get('chat_id') or '')
        if chat:
            return chat
        if str((m.get('sender') or {}).get('user_id') or ''):
            return str(m['sender']['user_id'])
    return ''
SENDERS: Dict[str, Callable] = {'webhook': send_webhook, 'discord': send_discord, 'ntfy': send_ntfy, 'max': send_max}

def broadcast(channels: dict, rig: str, text: str, post: Callable=_post) -> List[Tuple[str, str]]:
    errors: List[Tuple[str, str]] = []
    for name, chan_cfg in (channels or {}).items():
        url = (chan_cfg or {}).get('url') if isinstance(chan_cfg, dict) else None
        fn = SENDERS.get(name)
        if not url or not fn:
            continue
        try:
            fn(url, rig, text, post=post)
        except (urllib.error.URLError, OSError, ValueError) as e:
            log.warning('notify %s: %s', name, e)
            errors.append((name, str(e)))
        except Exception as e:
            log.exception('notify %s: непредвиденная ошибка', name)
            errors.append((name, str(e)))
    return errors
