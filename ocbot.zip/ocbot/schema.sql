-- ============================================================
-- Схема базы бота подбора разгона (HiveOS, только NVIDIA)
-- Каждый риг хранит свою полную копию. Обмен пресетами идёт
-- через Telegram: бот -> владелец -> общая группа -> все боты.
-- Время везде в UTC, формат ISO 8601 (TEXT).
-- ============================================================

PRAGMA foreign_keys = ON;

-- ------------------------------------------------------------
-- Риги: параметры, которые бот помнит про каждый риг
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS rigs (
    name            TEXT PRIMARY KEY,
    driver_version  TEXT,
    slots_total     INTEGER,
    note            TEXT,               -- питание, охлаждение, условия
    updated_at      TEXT NOT NULL
);

-- ------------------------------------------------------------
-- Карты: ключ = GPU UUID (nvidia-smi), не зависит от рига и слота
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS gpus (
    uuid            TEXT PRIMARY KEY,
    model           TEXT NOT NULL,
    vbios           TEXT,
    mem_vendor      TEXT,               -- Samsung / Micron / Hynix
    label           TEXT,               -- ваша метка, например A17
    status          TEXT NOT NULL DEFAULT 'ok'
                    CHECK (status IN ('ok', 'suspect', 'faulty')),
    status_reason   TEXT,
    current_rig     TEXT REFERENCES rigs(name),
    current_slot    INTEGER,
    first_seen      TEXT NOT NULL,
    updated_at      TEXT NOT NULL
);

-- ------------------------------------------------------------
-- История перестановок: где и когда стояла карта
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS placements (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    gpu_uuid        TEXT NOT NULL REFERENCES gpus(uuid),
    rig             TEXT NOT NULL,
    slot            INTEGER,
    from_ts         TEXT NOT NULL,
    to_ts           TEXT,               -- NULL = стоит сейчас
    note            TEXT                -- например: "стабильнее, чем в риге A"
);
CREATE INDEX IF NOT EXISTS idx_placements_gpu ON placements(gpu_uuid, from_ts);

-- ------------------------------------------------------------
-- Профили (пресеты)
--   candidate : лучшая точка поиска, ждёт 2 часа проверки
--   verified  : прошёл 2 часа стабильной работы
--   imported  : получен от другого рига, перед использованием
--               проходит короткую проверку на этом месте
--   outdated  : сменились VBIOS / драйвер / майнер, нужна перепроверка
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS profiles (
    id              TEXT PRIMARY KEY,   -- уникальный ID (ULID/UUID), нужен для дедупликации
    gpu_uuid        TEXT NOT NULL REFERENCES gpus(uuid),
    algo            TEXT NOT NULL,
    miner           TEXT NOT NULL,
    miner_version   TEXT NOT NULL,
    driver_version  TEXT,
    vbios           TEXT,
    core_offset     INTEGER NOT NULL,
    mem_offset      INTEGER NOT NULL,
    power_limit     INTEGER NOT NULL,   -- ватты
    fan             INTEGER,            -- проценты, NULL = авто
    hashrate        REAL,
    power_w         REAL,
    efficiency      REAL,               -- хешрейт на ватт
    status          TEXT NOT NULL
                    CHECK (status IN ('candidate', 'verified', 'imported', 'outdated')),
    weak_card       INTEGER NOT NULL DEFAULT 0,  -- 1 = заметно мягче типичного для модели
    source          TEXT NOT NULL DEFAULT 'local'
                    CHECK (source IN ('local', 'imported')),
    seed_from       TEXT,               -- откуда взята стартовая точка (id профиля или 'median')
    rig             TEXT,               -- где найден
    slot            INTEGER,
    temp_at_verify  REAL,               -- температура при верификации
    objective       TEXT,               -- цель подбора, при которой найден пресет (efficiency / compromise / hashrate)
    core_lock       INTEGER,            -- режим «4 параметра»: фиксация частоты ядра, МГц (NULL = нет)
    mem_lock        INTEGER,            -- и памяти
    created_at      TEXT NOT NULL,
    verified_at     TEXT
);
-- Один действующий verified-профиль на карту/алгоритм/майнер/версию
CREATE UNIQUE INDEX IF NOT EXISTS idx_profiles_verified
    ON profiles(gpu_uuid, algo, miner, miner_version)
    WHERE status = 'verified';
CREATE INDEX IF NOT EXISTS idx_profiles_lookup
    ON profiles(gpu_uuid, algo, miner, status);

-- ------------------------------------------------------------
-- Прогоны: каждая тестовая точка и каждая верификация
--   kind   : search (3-10 мин), verify (2 часа), recheck (короткая проверка при переносе)
--   status : ok / unstable / crash / suspect
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS runs (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    gpu_uuid            TEXT NOT NULL REFERENCES gpus(uuid),
    rig                 TEXT NOT NULL,
    slot                INTEGER,
    algo                TEXT NOT NULL,
    miner               TEXT NOT NULL,
    miner_version       TEXT NOT NULL,
    driver_version      TEXT,
    vbios               TEXT,
    core_offset         INTEGER NOT NULL,
    mem_offset          INTEGER NOT NULL,
    power_limit         INTEGER NOT NULL,
    fan                 INTEGER,
    kind                TEXT NOT NULL CHECK (kind IN ('search', 'verify', 'recheck', 'work')),
    started_at          TEXT NOT NULL,
    finished_at         TEXT,           -- NULL после ребута: точка начата, но не завершена
    status              TEXT CHECK (status IN ('ok', 'unstable', 'crash', 'suspect')),
    hashrate_median     REAL,
    power_w             REAL,
    efficiency          REAL,
    invalid_share_pct   REAL,
    max_temp_core       REAL,
    max_temp_mem        REAL,           -- может быть недоступна на части карт
    throttle_reasons    TEXT,
    crash_cause         TEXT CHECK (crash_cause IN (
                            'aggressive_oc', 'overheat', 'power',
                            'bus_lost', 'miner', 'unknown', 'rig_wide')),
    note                TEXT
);
CREATE INDEX IF NOT EXISTS idx_runs_gpu ON runs(gpu_uuid, algo, miner, started_at);
CREATE INDEX IF NOT EXISTS idx_runs_place ON runs(rig, slot);

-- ------------------------------------------------------------
-- Журнал изменений пресета с причиной
-- ("mem 1200 -> 1100, причина: Xid на графическом движке")
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS preset_changes (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    gpu_uuid        TEXT NOT NULL REFERENCES gpus(uuid),
    ts              TEXT NOT NULL,
    algo            TEXT,
    miner           TEXT,
    old_values      TEXT,               -- JSON: {"core":..,"mem":..,"pl":..,"fan":..}
    new_values      TEXT,
    reason          TEXT NOT NULL
);

-- ------------------------------------------------------------
-- Лесенка перезагрузок после отвала:
--   попытки 1-3 без паузы -> перезагрузка с задержкой -> пометка карты
-- Счётчик обнуляется после стабильной работы
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS escalation (
    gpu_uuid        TEXT PRIMARY KEY REFERENCES gpus(uuid),
    reboot_attempts INTEGER NOT NULL DEFAULT 0,
    delayed_done    INTEGER NOT NULL DEFAULT 0,
    last_event_ts   TEXT,
    reset_ts        TEXT
);

-- ------------------------------------------------------------
-- Импорт пресетов, полученных через Telegram
-- msg_key (id пресета + контрольная сумма) защищает от дублей
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS imports (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    msg_key         TEXT NOT NULL UNIQUE,
    profile_id      TEXT,
    received_at     TEXT NOT NULL,
    from_user_id    INTEGER NOT NULL,   -- только ваш Telegram ID
    accepted        INTEGER NOT NULL,   -- 1 = сохранён, 0 = отклонён
    reject_reason   TEXT                -- плохая сумма, значения вне границ, чужой отправитель
);

-- ------------------------------------------------------------
-- Сводка по местам: помогает находить проблемные слоты и риги.
-- Общие отвалы всего рига (rig_wide) в статистику не входят.
-- ------------------------------------------------------------
CREATE VIEW IF NOT EXISTS rig_slot_stats AS
SELECT rig,
       slot,
       COUNT(*)                                          AS runs_total,
       SUM(CASE WHEN status = 'crash' THEN 1 ELSE 0 END) AS crashes,
       AVG(CASE WHEN status = 'ok' THEN efficiency END)  AS avg_efficiency
FROM runs
WHERE crash_cause IS NOT 'rig_wide'
GROUP BY rig, slot;

-- ------------------------------------------------------------
-- Замок на power limit: бот применяет именно это значение и не меняет его.
-- watts NULL = замок явно снят командой (перекрывает значение из конфига)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS pl_locks (
    gpu_uuid        TEXT PRIMARY KEY REFERENCES gpus(uuid),
    watts           INTEGER,
    updated_at      TEXT NOT NULL
);

-- ============================================================
-- ФОРМАТ СООБЩЕНИЯ С ПРЕСЕТОМ (бот -> вы -> группа -> боты)
--
-- Первая строка машинная, вторая читаемая для вас:
--
--   OCP1|<profile_id>|<gpu_uuid>|<model>|<vbios>|<mem_vendor>|<algo>|<miner>|<miner_version>|<driver>|<core>|<mem>|<pl>|<fan>|<hashrate>|<power_w>|<efficiency>|<verified_at>|<crc32>
--   Карта A17 (RTX 3070, Samsung): <algo>, core <..>, mem <..>, PL <..> Вт, <..> H/W
--
-- Правила приёма (бот-получатель):
--   1. отправитель = ваш Telegram ID, иначе игнорировать;
--   2. crc32 сходится, иначе отклонить;
--   3. значения в допустимых границах для модели, иначе отклонить;
--   4. msg_key уже есть в imports -> дубликат, пропустить;
--   5. сохранить со статусом 'imported' и source = 'imported';
--      перед использованием короткая проверка (recheck) на этом месте.
--
-- КОМАНДЫ В TELEGRAM (у каждого рига свой бот)
--   /status /profiles /tune <карта> /stop /verify <карта> /safe
--   /history <карта> /slots /faulty <карта> /export /import /resume /pl /psu
-- ============================================================

-- ------------------------------------------------------------
-- Каталог пресетов по моделям: свои записи считаются из profiles (ocbot/catalog.py), чужие (из файла каталога)
-- лежат здесь и используются только как стартовая точка поиска для карт без своей истории
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS model_catalog_imported (
    model          TEXT NOT NULL,
    mem_vendor     TEXT NOT NULL DEFAULT '',
    algo           TEXT NOT NULL,
    miner          TEXT NOT NULL,
    miner_version  TEXT NOT NULL,
    objective      TEXT NOT NULL DEFAULT '',
    cards          INTEGER NOT NULL DEFAULT 1,
    best_core      INTEGER NOT NULL, best_mem INTEGER NOT NULL, best_pl INTEGER NOT NULL,
    med_core       INTEGER NOT NULL, med_mem  INTEGER NOT NULL, med_pl  INTEGER NOT NULL,
    hashrate       REAL, power_w REAL, efficiency REAL,
    updated_at     TEXT,
    imported_at    TEXT NOT NULL,
    PRIMARY KEY (model, mem_vendor, algo, miner, miner_version, objective)
);

-- ------------------------------------------------------------
-- Проба осей для нового алгоритма: как меняются хешрейт и мощность при сдвиге одной оси от базовой точки
-- (d_* в процентах за весь сдвиг, steps = на сколько шагов оси сдвигали). По ней выбирается приоритет подбора.
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS axis_probe (
    algo           TEXT NOT NULL,
    miner          TEXT NOT NULL,
    miner_version  TEXT NOT NULL,
    driver_version TEXT NOT NULL DEFAULT '',
    axis           TEXT NOT NULL CHECK (axis IN ('core', 'mem', 'pl')),
    -- Модель карты — часть первичного ключа: проба одной модели не должна решать за другую модель
    -- на том же риге (core может быть чувствителен на одной карте и бесполезен на другой).
    model          TEXT NOT NULL DEFAULT '',
    steps          REAL NOT NULL,
    d_hash         REAL NOT NULL,
    d_power        REAL,
    d_eff          REAL,
    created_at     TEXT NOT NULL,
    PRIMARY KEY (algo, miner, miner_version, driver_version, axis, model)
);
