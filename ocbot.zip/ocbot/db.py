from __future__ import annotations
import sqlite3
import statistics
import threading
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional
SCHEMA = Path(__file__).with_name('schema.sql')
BOUNDARY_CAUSES = ('aggressive_oc', 'unknown', 'overheat')

def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat(timespec='seconds')

class DB:

    def __init__(self, path: str=':memory:'):
        self.c = sqlite3.connect(path, check_same_thread=False)
        self.c.row_factory = sqlite3.Row
        self.lock = threading.RLock()
        with self.lock:
            cols = {r[1] for r in self.c.execute('pragma table_info(profiles)')}
            self.c.executescript(SCHEMA.read_text(encoding='utf-8'))
            if cols and 'objective' not in cols:
                self.c.execute('alter table profiles add column objective text')
                self.c.commit()
            cols = {r[1] for r in self.c.execute('pragma table_info(profiles)')}
            for col in ('core_lock', 'mem_lock'):
                if col not in cols:
                    self.c.execute(f'alter table profiles add column {col} integer')
            self._migrate_axis_probe_model()
            self.c.commit()

    def _migrate_axis_probe_model(self) -> None:
        info = self.c.execute('pragma table_info(axis_probe)').fetchall()
        if not info:
            return
        model_is_pk = any((r[1] == 'model' and r[5] for r in info))
        if model_is_pk:
            return
        self.c.execute('alter table axis_probe rename to axis_probe_pre_model_pk')
        self.c.execute("create table axis_probe ( algo text not null, miner text not null, miner_version text not null, driver_version text not null default '', axis text not null check (axis in ('core', 'mem', 'pl')), model text not null default '', steps real not null, d_hash real not null, d_power real, d_eff real, created_at text not null, primary key (algo, miner, miner_version, driver_version, axis, model))")
        self.c.execute("insert into axis_probe(algo, miner, miner_version, driver_version, axis, model, steps, d_hash, d_power, d_eff, created_at) select algo, miner, miner_version, driver_version, axis, coalesce(model, ''), steps, d_hash, d_power, d_eff, created_at from axis_probe_pre_model_pk")
        self.c.execute('drop table axis_probe_pre_model_pk')

    def q(self, sql: str, args=()) -> list:
        with self.lock:
            return self.c.execute(sql, args).fetchall()

    def one(self, sql: str, args=()):
        rows = self.q(sql, args)
        return rows[0] if rows else None

    def x(self, sql: str, args=()):
        with self.lock:
            cur = self.c.execute(sql, args)
            self.c.commit()
            return cur

    def ensure_rig(self, name: str, driver: Optional[str]=None) -> None:
        self.x('insert into rigs(name, driver_version, updated_at) values(?,?,?) on conflict(name) do update set driver_version=coalesce(excluded.driver_version, driver_version), updated_at=excluded.updated_at', (name, driver, utcnow()))

    def gpu(self, uuid: str):
        return self.one('select * from gpus where uuid=?', (uuid,))

    def pl_lock_row(self, uuid: str):
        return self.one('select * from pl_locks where gpu_uuid=?', (uuid,))

    def set_pl_lock(self, uuid: str, watts: Optional[int]) -> None:
        self.x('insert into pl_locks(gpu_uuid, watts, updated_at) values(?,?,?) on conflict(gpu_uuid) do update set watts=excluded.watts, updated_at=excluded.updated_at', (uuid, watts, utcnow()))

    def upsert_gpu(self, uuid, model, vbios, mem_vendor, rig, slot, label=None):
        ts, g = (utcnow(), self.gpu(uuid))
        vendor = None if mem_vendor in (None, '', 'unknown') else mem_vendor
        if g is None:
            self.x('insert into gpus(uuid,model,vbios,mem_vendor,label,current_rig,current_slot,first_seen,updated_at) values(?,?,?,?,?,?,?,?,?)', (uuid, model, vbios, vendor, label, rig, slot, ts, ts))
            prev = None
        else:
            prev = (g['current_rig'], g['current_slot']) if g['current_rig'] else None
            self.x('update gpus set model=?, vbios=?, mem_vendor=coalesce(?, mem_vendor), label=coalesce(?, label), current_rig=?, current_slot=?, updated_at=? where uuid=?', (model, vbios, vendor, label, rig, slot, ts, uuid))
        moved = rig is not None and prev != (rig, slot)
        if moved:
            self.x('update placements set to_ts=? where gpu_uuid=? and to_ts is null', (ts, uuid))
            self.x('insert into placements(gpu_uuid, rig, slot, from_ts) values(?,?,?,?)', (uuid, rig, slot, ts))
        return (moved, prev)

    def set_gpu_status(self, uuid: str, status: str, reason: Optional[str]=None) -> None:
        self.x('update gpus set status=?, status_reason=?, updated_at=? where uuid=?', (status, reason, utcnow(), uuid))

    def note_placement(self, uuid: str, note: str) -> None:
        self.x('update placements set note=? where gpu_uuid=? and to_ts is null', (note, uuid))

    def rig_gpus(self, rig: str) -> list:
        return self.q('select * from gpus where current_rig=?', (rig,))

    def start_run(self, **kw) -> int:
        cols = ','.join(kw)
        cur = self.x(f"insert into runs({cols}) values({','.join('?' * len(kw))})", tuple(kw.values()))
        return cur.lastrowid

    def finish_run(self, run_id: int, **kw) -> None:
        kw.setdefault('finished_at', utcnow())
        sets = ','.join(("note=case when note is null or note='' then ? else note || '; ' || ? end" if k == 'note' else f'{k}=?' for k in kw))
        vals = []
        for k, v in kw.items():
            vals += [v, v] if k == 'note' else [v]
        self.x(f'update runs set {sets} where id=?', (*vals, run_id))

    def recent_extend_crashes(self, uuid, algo, miner, miner_version, hours: float) -> int:
        cutoff = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat(timespec='seconds')
        return self.one("select count(*) c from runs where gpu_uuid=? and algo=? and miner=? and miner_version=? and status='crash' and note like 'extend%' and started_at > ?", (uuid, algo, miner, miner_version, cutoff))['c']

    def work_crashes_since(self, uuid, since_iso) -> int:
        return self.one("select count(*) c from runs where gpu_uuid=? and kind='work' and status='crash' and started_at > ?", (uuid, since_iso))['c']

    def unfinished_runs(self, rig: str) -> list:
        return self.q('select * from runs where finished_at is null and rig=? order by started_at', (rig,))

    def crash_points(self, uuid, algo, miner, miner_version, driver, same=True) -> list:
        eq, glue = ('=', 'and') if same else ('!=', 'or')
        rows = self.q(f"select core_offset, mem_offset, power_limit from runs where gpu_uuid=? and algo=? and miner=? and finished_at is not null and kind in ('search','verify','recheck','work') and coalesce(note,'') not like 'lock%' and coalesce(note,'') not like '%No targets match%' and coalesce(note,'') not like '%Error resolving target%' and status in ('crash','unstable') and crash_cause in ({','.join('?' * len(BOUNDARY_CAUSES))}) and (miner_version {eq} ? {glue} coalesce(driver_version,'') {eq} coalesce(?,''))", (uuid, algo, miner, *BOUNDARY_CAUSES, miner_version, driver))
        return [(r[0], r[1], r[2]) for r in rows]

    def search_history(self, uuid, algo, miner, miner_version, driver) -> list:
        rows = self.q("select core_offset, mem_offset, power_limit, fan, efficiency from runs where gpu_uuid=? and algo=? and miner=? and miner_version=? and coalesce(driver_version,'')=coalesce(?,'') and kind='search' and coalesce(note,'')!='scout' and coalesce(note,'') not like 'lock%' and status='ok' and efficiency is not null order by id", (uuid, algo, miner, miner_version, driver))
        return [tuple(r) for r in rows]

    def search_hashrates(self, uuid, algo, miner, miner_version, driver) -> list:
        rows = self.q("select core_offset, mem_offset, power_limit, fan, hashrate_median from runs where gpu_uuid=? and algo=? and miner=? and miner_version=? and coalesce(driver_version,'')=coalesce(?,'') and kind='search' and coalesce(note,'')!='scout' and coalesce(note,'') not like 'lock%' and status='ok' and hashrate_median is not null order by id", (uuid, algo, miner, miner_version, driver))
        return [tuple(r) for r in rows]

    def curve_points(self, uuid, algo, miner, miner_version, driver) -> list:
        rows = self.q("select core_offset, mem_offset, power_limit, avg(hashrate_median) h, avg(efficiency) e from runs where gpu_uuid=? and algo=? and miner=? and miner_version=? and coalesce(driver_version,'')=coalesce(?,'') and kind in ('search','verify') and coalesce(note,'')!='scout' and coalesce(note,'') not like 'lock%' and status='ok' and hashrate_median > 0 and finished_at is not null group by core_offset, mem_offset, power_limit", (uuid, algo, miner, miner_version, driver))
        return [tuple(r) for r in rows]

    def axis_probe_rows(self, algo, miner, miner_version, driver, model) -> dict:
        rows = self.q('select axis, d_hash, d_power, d_eff, steps from axis_probe where algo=? and miner=? and miner_version=? and driver_version=? and model=?', (algo, miner, miner_version, driver or '', model or ''))
        return {r['axis']: (r['d_hash'], r['d_power'], r['d_eff'], r['steps']) for r in rows}

    def save_axis_probe(self, algo, miner, miner_version, driver, axis, steps, d_hash, d_power, d_eff, model) -> None:
        self.x('insert or replace into axis_probe(algo, miner, miner_version, driver_version, axis, model, steps, d_hash, d_power, d_eff, created_at) values(?,?,?,?,?,?,?,?,?,?,?)', (algo, miner, miner_version, driver or '', axis, model or '', steps, d_hash, d_power, d_eff, utcnow()))

    def hashrate_evidence(self, algo, miner, miner_version, driver) -> list:
        rows = self.q("select gpu_uuid, core_offset, mem_offset, power_limit, hashrate_median, efficiency from runs where algo=? and miner=? and miner_version=? and coalesce(driver_version,'')=coalesce(?,'') and kind='search' and coalesce(note,'') not like 'lock%' and status='ok' and hashrate_median > 0 and efficiency > 0", (algo, miner, miner_version, driver))
        return [tuple(r) for r in rows]

    def save_profile(self, p: dict) -> None:
        if p['status'] == 'verified':
            self.x("update profiles set status='outdated' where gpu_uuid=? and algo=? and miner=? and miner_version=? and status='verified'", (p['gpu_uuid'], p['algo'], p['miner'], p['miner_version']))
        cols = ','.join(p)
        self.x(f"insert into profiles({cols}) values({','.join('?' * len(p))})", tuple(p.values()))

    def get_profile(self, uuid, algo, miner, miner_version, status):
        return self.one('select * from profiles where gpu_uuid=? and algo=? and miner=? and miner_version=? and status=? order by created_at desc, rowid desc', (uuid, algo, miner, miner_version, status))

    def latest_profile_any(self, uuid, algo, miner, rig=None):
        q = "select * from profiles where gpu_uuid=? and algo=? and miner=? and status in ('verified','outdated','imported')"
        args = [uuid, algo, miner]
        if rig is not None:
            q += ' and rig=?'
            args.append(rig)
        q += ' order by created_at desc, rowid desc'
        return self.one(q, args)

    def previous_profile(self, uuid, algo, miner, miner_version):
        return self.one("select * from profiles where gpu_uuid=? and algo=? and miner=? and miner_version=? and status='outdated' and verified_at is not null order by verified_at desc, rowid desc", (uuid, algo, miner, miner_version))

    def restore_profile(self, profile_id: str) -> None:
        p = self.one('select * from profiles where id=?', (profile_id,))
        self.x("update profiles set status='outdated' where gpu_uuid=? and algo=? and miner=? and miner_version=? and status in ('verified','imported') and id!=?", (p['gpu_uuid'], p['algo'], p['miner'], p['miner_version'], profile_id))
        self.x("update profiles set status='verified' where id=?", (profile_id,))

    def set_profile_status(self, profile_id: str, status: str) -> None:
        self.x('update profiles set status=? where id=?', (status, profile_id))

    def promote(self, profile_id: str, rig: str, slot: int) -> None:
        p = self.one('select * from profiles where id=?', (profile_id,))
        self.x("update profiles set status='outdated' where gpu_uuid=? and algo=? and miner=? and miner_version=? and status='verified' and id!=?", (p['gpu_uuid'], p['algo'], p['miner'], p['miner_version'], profile_id))
        self.x("update profiles set status='verified', rig=?, slot=?, verified_at=? where id=?", (rig, slot, utcnow(), profile_id))

    def mark_stale(self, uuid, vbios, driver, max_age_days) -> int:
        cutoff = (datetime.now(timezone.utc) - timedelta(days=max_age_days)).isoformat(timespec='seconds')
        cur = self.x("update profiles set status='outdated' where gpu_uuid=? and status='verified' and ((vbios is not null and ? is not null and vbios != ?) or  (driver_version is not null and ? is not null and driver_version != ?) or  verified_at < ?)", (uuid, vbios, vbios, driver, driver, cutoff))
        return cur.rowcount

    def median_seed(self, model, mem_vendor, algo, miner, exclude_uuid, vbios) -> Optional[dict]:
        rows = self.q("select p.* from profiles p join gpus g on g.uuid=p.gpu_uuid where p.status='verified' and p.algo=? and p.miner=? and g.model=? and coalesce(g.mem_vendor,'')=coalesce(?,'') and p.gpu_uuid != ? and coalesce(p.weak_card,0)=0", (algo, miner, model, mem_vendor, exclude_uuid))
        same_bios = [r for r in rows if vbios and r['vbios'] == vbios]
        rows = same_bios or rows
        if not rows:
            return None
        med = lambda col: int(statistics.median((r[col] for r in rows)))
        return {'core': med('core_offset'), 'mem': med('mem_offset'), 'pl': med('power_limit'), 'n': len(rows)}

    def log_change(self, uuid, algo, miner, old, new, reason) -> None:
        import json
        self.x('insert into preset_changes(gpu_uuid, ts, algo, miner, old_values, new_values, reason) values(?,?,?,?,?,?,?)', (uuid, utcnow(), algo, miner, json.dumps(old) if old else None, json.dumps(new) if new else None, reason))

    def escalation(self, uuid: str):
        self.x('insert or ignore into escalation(gpu_uuid) values(?)', (uuid,))
        return self.one('select * from escalation where gpu_uuid=?', (uuid,))

    def set_escalation(self, uuid: str, **kw) -> None:
        self.escalation(uuid)
        sets = ','.join((f'{k}=?' for k in kw))
        self.x(f'update escalation set {sets} where gpu_uuid=?', (*kw.values(), uuid))

    def has_import(self, msg_key: str) -> bool:
        return self.one('select 1 from imports where msg_key=?', (msg_key,)) is not None

    def record_import(self, msg_key, profile_id, from_user, accepted, reason=None) -> None:
        self.x('insert or ignore into imports(msg_key, profile_id, received_at, from_user_id, accepted, reject_reason) values(?,?,?,?,?,?)', (msg_key, profile_id, utcnow(), from_user, int(accepted), reason))

    def slot_stats(self) -> list:
        return self.q('select * from rig_slot_stats order by crashes desc, runs_total desc')
