from __future__ import annotations
import hashlib
import json
import os
import re
import time
import urllib.request
from datetime import date, datetime, timedelta, timezone
from typing import Optional, Tuple, Union
from . import ed25519
REQUIRED = True
PUBKEY = '6b75fd2f4776238edd2c7de071e9298533db6edc3dab7771258bea87c6b982a4'
SALES_PUBKEY = 'fc7bdf953500989d6f10fc56a829e1ff361e86778ed076443212f17593e0485c'
OFFLINE_GRACE_DAYS = 3
KEY_RE = re.compile('^OC-[A-Z0-9]{5}(-[A-Z0-9]{5}){3}$')
RIG_CONF = '/hive-config/rig.conf'
MACHINE_ID = '/etc/machine-id'

def hw_id(rig_conf: str=RIG_CONF, machine_id: str=MACHINE_ID) -> str:
    src = ''
    try:
        m = re.search('^RIG_ID\\s*=\\s*\\"?([^\\"\\s]+)', open(rig_conf, encoding='utf-8', errors='ignore').read(), re.M)
        if m:
            src = 'rig:' + m.group(1)
    except OSError:
        pass
    if not src:
        try:
            src = 'mid:' + open(machine_id, encoding='utf-8').read().strip()
        except OSError:
            src = 'none'
    h = hashlib.sha256(src.encode()).hexdigest()[:12].upper()
    return f'HW-{h[:4]}-{h[4:8]}-{h[8:]}'

def _canon(payload: dict) -> bytes:
    return json.dumps(payload, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode('utf-8')

def make_license(secret: bytes, payload: dict) -> dict:
    return {'payload': payload, 'sig': ed25519.sign(secret, _canon(payload)).hex()}

def default_keys() -> list:
    return [PUBKEY] + ([SALES_PUBKEY] if SALES_PUBKEY else [])

def check_file(path: str, hwid: str, today: Optional[date]=None, pubkey: Union[str, tuple, list, None]=None) -> Tuple[bool, str, dict]:
    today = today or datetime.now(timezone.utc).date()
    keys = [pubkey] if isinstance(pubkey, str) else list(pubkey or default_keys())
    try:
        raw = json.load(open(path, encoding='utf-8'))
        payload, sig = (raw['payload'], bytes.fromhex(raw['sig']))
    except FileNotFoundError:
        return (False, f'нет файла лицензии {path}', {})
    except (OSError, ValueError, KeyError, TypeError):
        return (False, f'файл лицензии {path} повреждён', {})
    if not any((ed25519.verify(bytes.fromhex(k), _canon(payload), sig) for k in keys)):
        return (False, 'подпись лицензии неверна', {})
    if payload.get('hw') != hwid:
        return (False, f'лицензия выдана на другой риг (этот риг: {hwid})', payload)
    exp = payload.get('expires')
    if exp:
        try:
            if date.fromisoformat(exp) < today:
                return (False, f'срок лицензии истёк {exp}', payload)
        except ValueError:
            return (False, 'в лицензии неверный срок', payload)
    return (True, 'действует до ' + exp if exp else 'бессрочная', payload)

def read_key(path: str) -> str:
    try:
        return open(path, encoding='utf-8').read().strip()
    except OSError:
        return ''

def write_key(path: str, key: str) -> None:
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 384)
    with os.fdopen(fd, 'w', encoding='utf-8') as f:
        f.write(key.strip() + '\n')
TRIAL_KEY = 'TRIAL'

def server_call(url: str, key: str, hwid: str, timeout: int=20, path: str='/license') -> dict:
    body = json.dumps({'key': key, 'hw': hwid}).encode()
    req = urllib.request.Request(url.rstrip('/') + path, data=body, headers={'Content-Type': 'application/json', 'User-Agent': 'ocbot'})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode('utf-8'))

def save_license(path: str, resp: dict) -> bool:
    lic = resp.get('license') or {}
    if not isinstance(lic.get('payload'), dict) or not isinstance(lic.get('sig'), str):
        return False
    tmp = path + '.new'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(lic, f, ensure_ascii=False)
    os.replace(tmp, path)
    return True

def start_trial(cfg, call=server_call) -> str:
    if not getattr(cfg, 'sales_url', ''):
        return 'В этой сборке не задан адрес сервера лицензий, пробный период недоступен.'
    hw = hw_id()
    try:
        resp = call(cfg.sales_url, TRIAL_KEY, hw, path='/trial') if call is server_call else call(cfg.sales_url, TRIAL_KEY, hw)
    except Exception as e:
        return f'Не удалось связаться с сервером лицензий: {e}. Повторите позже.'
    st = resp.get('status')
    if st == 'ok' and save_license(cfg.license_path, resp):
        write_key(cfg.license_key_path, TRIAL_KEY)
        return f"Готово: пробный период до {resp['license']['payload'].get('expires')}. Работает режим «Компромисс» (максимум хешрейта при эффективности не хуже лучшей на 3%, менять нельзя — с ключом открывается выбор режима). Дальше нужен ключ с сайта: python3 -m ocbot --activate КЛЮЧ. Идентификатор рига: {hw}. На пробном периоде проверенные пресеты анонимно отправляются в общий каталог; с купленным ключом это можно отключить командой /share off."
    if st == 'trial_used':
        return 'Пробный период для этого рига уже использован. Получите ключ на сайте и введите: python3 -m ocbot --activate КЛЮЧ.'
    if st == 'rate_limited':
        return 'Слишком много запросов, повторите позже.'
    return f'Сервер лицензий ответил непонятно ({st}). Повторите позже.'

def activate(cfg, key: str, call=server_call) -> str:
    key = key.strip().upper()
    if not KEY_RE.match(key):
        return 'Ключ должен выглядеть так: OC-XXXXX-XXXXX-XXXXX-XXXXX.'
    if not getattr(cfg, 'sales_url', ''):
        return 'В этой сборке не задан адрес сервера лицензий, активация недоступна.'
    hw = hw_id()
    try:
        resp = call(cfg.sales_url, key, hw)
    except Exception as e:
        return f'Не удалось связаться с сервером лицензий: {e}. Повторите позже.'
    st = resp.get('status')
    if st == 'ok' and save_license(cfg.license_path, resp):
        write_key(cfg.license_key_path, key)
        return f"Готово: лицензия действует до {resp['license']['payload'].get('expires')}. Идентификатор рига: {hw}."
    if st == 'expired':
        return 'Срок этого ключа закончился. Продлите его на сайте (раздел «Продлить») и повторите команду.'
    if st == 'bound_elsewhere':
        return 'Этот ключ уже используется на другом риге. Один ключ действует на один риг.'
    if st == 'unknown_key':
        return 'Такого ключа нет. Проверьте, что он введён без ошибок.'
    return f'Сервер лицензий ответил непонятно ({st}). Повторите позже.'

class License:

    def __init__(self, cfg, now=time.time, fetch=None, call=None):
        self.cfg, self.now = (cfg, now)
        self.fetch = fetch or self._fetch
        self.call = call or server_call
        self.cache_path = cfg.license_path + '.cache'
        self.hwid = hw_id()
        self.state = 'none'
        self.expiry: Optional[date] = None
        self.trial = False

    def _fetch(self, url: str) -> list:
        req = urllib.request.Request(url, headers={'User-Agent': 'ocbot'})
        with urllib.request.urlopen(req, timeout=20) as r:
            data = json.loads(r.read().decode('utf-8'))
        return [str(x) for x in (data.get('revoked', []) if isinstance(data, dict) else data)]

    def _load(self) -> dict:
        try:
            return json.load(open(self.cache_path, encoding='utf-8'))
        except (OSError, ValueError):
            return {}

    def _save(self, c: dict) -> None:
        try:
            with open(self.cache_path, 'w', encoding='utf-8') as f:
                json.dump(c, f)
        except OSError:
            pass

    def _today(self) -> date:
        return datetime.fromtimestamp(self.now(), timezone.utc).date()

    def _maybe_refresh(self, payload: dict) -> None:
        url = getattr(self.cfg, 'sales_url', '')
        key = read_key(getattr(self.cfg, 'license_key_path', ''))
        if not url or not key:
            return
        c, t = (self._load(), self.now())
        exp = _parse_date((payload or {}).get('expires'))
        left = (exp - self._today()).days if exp else None
        due = left is None or left <= getattr(self.cfg, 'renew_before_days', 3)
        if not due or t - c.get('refresh_ts', 0) < 6 * 3600:
            return
        c['refresh_ts'] = t
        try:
            resp = self.call(url, key, self.hwid)
            st = resp.get('status')
            if st == 'ok' and save_license(self.cfg.license_path, resp):
                c['srv'] = 'ok'
            elif st == 'expired':
                c['srv'], c['expired_confirmed_ts'] = ('expired', t)
            else:
                c['srv'] = str(st)
        except Exception:
            c['srv'] = 'down'
        c['srv_ts'] = t
        self._save(c)

    def status(self) -> Tuple[bool, str]:
        from . import consent
        if REQUIRED and (not consent.accepted(self.cfg)):
            self.state, self.trial = ('invalid', False)
            return (False, 'не подтверждено согласие с условиями: прочитайте их (' + consent.url_of(self.cfg) + ') и подтвердите в Telegram командой /terms accept (или в консоли: python3 -m ocbot --accept-terms)')
        ok, why, payload = check_file(self.cfg.license_path, self.hwid, self._today())
        if not ok and (not payload) and read_key(getattr(self.cfg, 'license_key_path', '')):
            self._maybe_refresh({})
            ok, why, payload = check_file(self.cfg.license_path, self.hwid, self._today())
        elif payload and payload.get('hw') == self.hwid:
            self._maybe_refresh(payload)
            ok, why, payload = check_file(self.cfg.license_path, self.hwid, self._today())
        self.expiry = _parse_date((payload or {}).get('expires'))
        self.trial = bool(ok and payload and str(payload.get('id', '')).startswith('T-'))
        if not ok:
            if payload and payload.get('hw') == self.hwid and self.expiry and (self.expiry < self._today()):
                c = self._load()
                over = (self._today() - self.expiry).days
                recent_down = c.get('srv') == 'down' and self.now() - c.get('srv_ts', 0) < 36 * 3600
                if recent_down and over <= OFFLINE_GRACE_DAYS:
                    self.state = 'grace'
                    return (True, f'срок вышел {self.expiry}, проверить оплату не удаётся, работаю до {self.expiry + timedelta(days=OFFLINE_GRACE_DAYS)}')
                self.state = 'expired'
            else:
                self.state = 'invalid'
            return (False, why)
        url = self.cfg.license_revoke_url
        self.state = 'ok'
        if not url:
            return (True, why)
        c, t = (self._load(), self.now())
        c.setdefault('first_ts', t)
        if t - c.get('checked_ts', 0) >= 86400 or 'revoked' not in c:
            urls = [url] + [u for u in (getattr(self.cfg, 'license_revoke_url_legacy', ''),) if u and u != url]
            for u in urls:
                try:
                    c['revoked'] = self.fetch(u)
                    c['checked_ts'] = c['ok_ts'] = t
                    break
                except Exception:
                    c['checked_ts'] = t - 86400 + 3600
        self._save(c)
        if str(payload.get('id')) in c.get('revoked', []):
            self.state = 'invalid'
            return (False, 'лицензия отозвана владельцем')
        last_ok = c.get('ok_ts', c['first_ts'])
        if t - last_ok > self.cfg.license_grace_days * 86400:
            self.state = 'invalid'
            return (False, f'не удалось сверить лицензию со списком отозванных за {self.cfg.license_grace_days} дн.')
        return (True, why)

    def tick(self) -> dict:
        ev = {'warn': None, 'expired_new': False, 'purge': False}
        c, t = (self._load(), self.now())
        if self.state == 'ok' and self.expiry:
            left = (self.expiry - self._today()).days
            if left > 5:
                c['warned'], c['expired_notified'] = ([], False)
            else:
                warned = set(c.get('warned', []))
                due = [n for n in (5, 3, 1) if left <= n and n not in warned]
                if due:
                    ev['warn'] = min(due)
                    c['warned'] = sorted(warned | set(due))
            c['expired_notified'] = False
        elif self.state == 'expired' and self.expiry:
            if not c.get('expired_notified'):
                ev['expired_new'], c['expired_notified'] = (True, True)
            over = (self._today() - self.expiry).days
            confirmed = t - c.get('expired_confirmed_ts', 0) < 2 * 86400
            if over >= getattr(self.cfg, 'expired_purge_days', 5) and confirmed:
                ev['purge'] = True
        self._save(c)
        return ev

def _parse_date(v) -> Optional[date]:
    try:
        return date.fromisoformat(v) if v else None
    except (TypeError, ValueError):
        return None

def install_gate(agent, cfg) -> bool:
    if not REQUIRED:
        return False
    lc = License(cfg)
    agent.license_gate, agent.hwid, agent.lic = (lc.status, lc.hwid, lc)
    return True
