from __future__ import annotations
import json
import os
from dataclasses import dataclass, field, fields
from typing import Optional
_TUPLES = ('core_range', 'mem_range', 'pl_import_range', 'xid_hard_codes')

@dataclass
class Config:
    rig_name: str = 'rig1'
    db_path: str = 'ocbot.db'
    license_path: str = 'license.json'
    license_revoke_url: str = 'https://raw.githubusercontent.com/ocbotauto/ocbot-site/main/revoked.json'
    license_revoke_url_legacy: str = 'https://raw.githubusercontent.com/makar2186/ocbot-site/main/revoked.json'
    license_key_path: str = 'license.key'
    sales_url: str = 'https://ocbot-sales.ocbotauto.workers.dev'
    site_url: str = 'https://ocbot.org/'
    renew_before_days: int = 3
    expired_purge_days: int = 5
    license_grace_days: int = 14
    state_path: str = 'ocbot_state.json'
    xid_log_path: str = 'ocbot_xid.log'
    token: str = ''
    catalog_share: bool = False
    catalog_submit_url: str = 'https://ocbot-catalog.ocbotauto.workers.dev'
    github_repo: str = ''
    github_token: str = ''
    github_path: str = 'catalog.json'
    github_branch: str = 'main'
    send_preset_export: bool = False
    publish_name: str = ''
    tg_proxy: str = ''
    tg_api_base: str = ''
    owner_id: int = 0
    group_chat_id: int = 0
    algo: str = ''
    miner: str = ''
    miner_version: str = ''
    warmup_s: int = 180
    window_s: int = 300
    sample_every_s: int = 10
    fast_pass: bool = True
    fast_warmup_s: int = 90
    fast_window_s: int = 90
    fast_step_mult: int = 2
    fast_max_points: int = 15
    revive_wait_s: int = 60
    verify_s: int = 7200
    verify_long_mult: int = 3
    fresh_boot_s: int = 900
    recheck_s: int = 900
    cycle_idle_s: int = 60
    core_range: tuple = (-300, 150)
    mem_range: tuple = (-500, 2500)
    auto_extend: bool = True
    core_hard_max: int = 1000
    mem_hard_max: int = 6000
    objective: str = 'compromise'
    eff_tolerance: float = 0.03
    control_path: str = 'ocbot_control.json'
    verify_early: bool = True
    auto_freeze: bool = True
    freeze_axes: tuple = ('core', 'mem')
    freeze_max_effect_pct: float = 1.0
    freeze_min_pairs: int = 6
    freeze_min_span_steps: int = 2
    freeze_min_cards: int = 2
    queue_ttl_s: int = 10800
    queue_cap: int = 50
    hash_trim_pct: float = 0.5
    hash_trim_points: int = 0
    update_token: str = ''
    update_url: str = 'https://raw.githubusercontent.com/ocbotauto/ocbot-dist/main/ocbot.zip'
    update_check_s: int = 86400
    refine_points: int = 12
    step_core: int = 25
    step_mem: int = 50
    step_pl: int = 5
    start_pl_frac: float = 0.8
    min_gain: float = 0.005
    stale_after: int = 5
    max_points: int = 40
    safety_steps: int = 1
    max_search_rounds: int = 3
    fan: Optional[int] = None
    max_invalid_pct: float = 1.0
    max_drop_pct: float = 3.0
    max_temp_core: float = 88.0
    max_temp_mem: float = 99.0
    throttle_is_overheat: bool = False
    fast_reboots: int = 3
    delay_minutes: int = 10
    zero_hash_watch: bool = True
    zero_hash_minutes: int = 5
    zero_hash_boot_grace_s: int = 300
    zero_hash_restart_grace_s: int = 180
    driver_error_minutes: int = 3
    hive_mirror: bool = False
    hive_agent_log: str = '/var/log/hive-agent.log'
    cuda_soft_tolerance: int = 2
    xid_hard_codes: tuple = (79, 109, 119, 120)
    xid_noise_per_day: int = 3
    xid_day_limit: int = 10
    xid_storm_count: int = 5
    xid_storm_window_s: int = 600
    xid_rigwide_cards: int = 3
    hang_reboot_after: int = 3
    watchdog_hang_minutes: int = 15
    autofan: bool = False
    max_temp_cpu: int = 85
    kernel_panic_reboot: bool = True
    max_reboots_per_day: int = 6
    max_tuning_reboots_per_day: int = 40
    stable_reset_s: int = 7200
    profile_max_age_days: int = 30
    compare_threshold: float = 0.04
    psu_required: bool = True
    psu_watts: int = 0
    psu_base_watts: int = 100
    psu_groups: list = field(default_factory=list)
    psu_max_load_frac: float = 0.8
    psu_hard_frac: float = 0.9
    pl_total_max: int = 0
    axis_probe: bool = True
    extend_crash_limit: int = 5
    extend_crash_total: int = 8
    balance_rollback_tol: float = 0.005
    display_wait_s: int = 600
    balance_skip_crash_hours: int = 12
    opt_core_steps: int = 2
    opt_mem_steps: int = 1
    opt_pl_steps: int = 2
    opt_max_points: int = 24
    opt_window_mult: float = 2.0
    opt_top: int = 3
    opt_min_gain: float = 0.01
    lock_core_step: int = 15
    lock_core_stride: int = 3
    lock_core_span: int = 300
    lock_core_floor: int = 600
    lock_mem_count: int = 2
    lock_lift: bool = True
    lock_lift_step: int = 15
    lock_lift_max: int = 150
    lock_lift_margin: int = 30
    lock_max_points: int = 22
    lock_rgminer_floor: int = 1080
    lock_rgminer_span: int = 720
    deep_core_steps: int = 5
    deep_pl_steps: int = 6
    rig_balance: bool = True
    balance_min_gain: float = 0.01
    balance_fallbacks: int = 2
    psu_transient: float = 1.1
    pl_locks: dict = field(default_factory=dict)
    pl_import_range: tuple = (50, 450)
    nvidia_settings_prefix: str = 'DISPLAY=:0 nvidia-settings'
    gpu_stats_cmd: str = 'gpu-stats'
    stats_cmd: str = ''
    miner_stop_cmd: str = 'miner stop'
    miner_start_cmd: str = 'miner start'
    mem_vendor_by_uuid: dict = field(default_factory=dict)

    def __post_init__(self):
        if self.objective not in ('efficiency', 'compromise', 'hashrate'):
            raise ValueError(f'objective: efficiency, compromise или hashrate, а не {self.objective!r}')

    def limits(self) -> dict:
        return {'core': self.search_range('core'), 'mem': self.search_range('mem'), 'pl': self.pl_import_range}

    def search_range(self, axis: str) -> tuple:
        lo, hi = self.core_range if axis == 'core' else self.mem_range
        if self.auto_extend:
            hi = max(hi, self.core_hard_max if axis == 'core' else self.mem_hard_max)
        return (lo, hi)

    @classmethod
    def load(cls, path: str) -> 'Config':
        with open(path, encoding='utf-8') as f:
            raw = json.load(f)
        known = {f.name for f in fields(cls)}
        unknown = set(raw) - known
        if unknown:
            raise ValueError(f'неизвестные поля конфига: {sorted(unknown)}')
        for k in _TUPLES:
            if k in raw:
                raw[k] = tuple(raw[k])
        cfg = cls(**raw)
        cfg.token = os.environ.get('OCBOT_TOKEN', cfg.token)
        cfg._path = os.path.abspath(path)
        return cfg
