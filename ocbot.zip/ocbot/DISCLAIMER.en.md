# Disclaimer and terms of use

By using the bot you accept these terms.

1. **No warranty.** The bot is provided "as is". The author does not guarantee that it fits your purposes, runs without interruption or is free of errors.
2. **Risk to hardware.** The bot changes clock offsets, clock locks and power limits by itself and reboots the rig. This can cause unstable operation, dropped cards, overheating, accelerated wear or failure of GPUs, power supplies, risers and other hardware, loss of hashrate and income, loss of data, and loss of the manufacturer's warranty.
3. **You are responsible for the result.** By installing and running the bot you accept all risks and all responsibility for any consequences of its operation, including direct and indirect losses and lost profit. The author and distributors are not liable for them to the extent permitted by law.
4. **What stays with you.** Cooling, power, risers, temperatures and supervising the rig. PSU data (the /psu command) is entered by the owner and its accuracy is the owner's responsibility. Do the first runs while you are near the rig. Always check any preset before applying it, especially one from the catalog or from other people.
5. **Presets and catalog.** During the trial, verified presets from your rig are submitted anonymously (no rig name, card UUIDs or IP) to the shared catalog; this is a condition of the trial and cannot be turned off during it. With a purchased key you can turn sharing off at any time with /share off. Catalog presets are submitted by third-party users. They do not fit every card or rig, are not verified by the author and come without any warranty.
6. **Third-party software.** This is an independent project, not affiliated with or endorsed by Hiveon or HiveOS. HiveOS, the NVIDIA driver, miners (including rgminer), pools and Telegram are developed by third parties and are not affiliated with the author of the bot. Their names belong to their owners. You comply with their licenses and terms of use yourself.
7. **Access and data.** The Telegram token and, if you enable catalog publishing, the GitHub token are stored in the config on your rig. Keeping them safe is on you: do not publish them or paste them into chats. The catalog contains no card UUIDs or rig names, but you are the one who publishes it.
8. **Law.** You are responsible for complying with the laws of your country (mining, electricity, taxes, etc.) and for making sure that using the bot does not breach warranty or other obligations to third parties.
9. **Changes.** Functionality and these terms may change. The current version is always on this page.
10. **Acceptance.** If you do not agree with these terms, do not install the bot; if it is already installed, remove it with --uninstall --yes.
