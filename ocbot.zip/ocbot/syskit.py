import re
import logging
log = logging.getLogger('ocbot')
ANTI_HANG_FILE = '/etc/sysctl.d/99-ocbot-anti-hang.conf'
ANTI_HANG_SYSCTLS = {'kernel.hung_task_panic': 1, 'kernel.hung_task_timeout_secs': 30, 'kernel.softlockup_panic': 1, 'kernel.hardlockup_panic': 1, 'kernel.nmi_watchdog': 1, 'kernel.watchdog': 1}
JOURNAL_CONF_DIR = '/etc/systemd/journal.conf.d'
JOURNAL_DROPIN_DIR = '/etc/systemd/journald.conf.d'
JOURNAL_DROPIN = JOURNAL_DROPIN_DIR + '/90-ocbot.conf'
JOURNAL_STORAGE = '/root/journal-storage'
JOURNAL_TARGET = '/var/log/journal'
FSTAB = '/etc/fstab'
MACHINE_ID = '/etc/machine-id'
_JOURNAL_DROPIN_TXT = '[Journal]\nStorage=persistent\nSystemMaxUse=900M\n'

def _run(runner, cmd):
    try:
        out = runner(cmd)
    except Exception as e:
        log.info('syskit: команда недоступна (%s): %s', str(e)[:80], cmd[:120])
        return ''
    return out or ''

def ensure_anti_hang(runner) -> list:
    changes = []
    want = ''.join((k + '=' + str(v) + '\n' for k, v in ANTI_HANG_SYSCTLS.items()))
    have = _run(runner, 'cat ' + ANTI_HANG_FILE + ' 2>/dev/null')
    missing = [k for k in ANTI_HANG_SYSCTLS if not re.search(re.escape(k) + '\\s*=\\s*' + str(ANTI_HANG_SYSCTLS[k]) + '\\b', have)]
    if missing or not have:
        _run(runner, 'mkdir -p /etc/sysctl.d && cat > ' + ANTI_HANG_FILE + " << 'EOF'\n" + want + 'EOF')
        if _run(runner, 'cat ' + ANTI_HANG_FILE).strip() == want.strip():
            changes.append('sysctl anti-hang (' + ANTI_HANG_FILE + ')')
    applied = _run(runner, 'sysctl kernel.hung_task_panic kernel.softlockup_panic kernel.hardlockup_panic kernel.nmi_watchdog 2>/dev/null')
    vals = {m.group(1): m.group(2) for m in re.finditer('(\\w+\\.\\w+)\\s*=\\s*(\\d+)', applied)}
    bad = [k for k in ANTI_HANG_SYSCTLS if k in ('kernel.hung_task_panic', 'kernel.softlockup_panic', 'kernel.hardlockup_panic', 'kernel.nmi_watchdog') and vals.get(k) != str(ANTI_HANG_SYSCTLS[k])]
    if bad:
        args = ' '.join((k + '=' + str(ANTI_HANG_SYSCTLS[k]) for k in bad))
        out = _run(runner, 'sysctl -w ' + args + ' 2>&1 || sysctl -q -w ' + args)
        if 'invalid' in out.lower() or not out.strip():
            return changes
        changes.append('sysctl применены живо: ' + ', '.join(bad))
    return changes

def ensure_journal_persistence(runner) -> tuple:
    changes = []
    warns = []
    drop = _run(runner, 'cat ' + JOURNAL_DROPIN + ' 2>/dev/null')
    if 'Storage=persistent' not in drop:
        _run(runner, 'mkdir -p ' + JOURNAL_DROPIN_DIR + ' && cat > ' + JOURNAL_DROPIN + " << 'EOF'\n" + _JOURNAL_DROPIN_TXT + 'EOF')
        if 'Storage=persistent' in _run(runner, 'cat ' + JOURNAL_DROPIN + ' 2>/dev/null'):
            changes.append('journald Storage=persistent drop-in')
    already = _run(runner, 'mount | grep -F " on ' + JOURNAL_TARGET + ' type "')
    if already.strip():
        src_ok = 'journal-storage' in already
        if not src_ok:
            warns.append(JOURNAL_TARGET + ' примонтирован, но не в ' + JOURNAL_STORAGE)
    else:
        _run(runner, 'mkdir -p ' + JOURNAL_STORAGE)
        _run(runner, 'if [ -d ' + JOURNAL_TARGET + ' ] && [ ! -L ' + JOURNAL_TARGET + ' ] && [ -n "$(ls -A ' + JOURNAL_TARGET + ' 2>/dev/null)" ]; then cp -a ' + JOURNAL_TARGET + '/. ' + JOURNAL_STORAGE + '/ 2>/dev/null; fi')
        probe = _run(runner, 'mount --bind ' + JOURNAL_STORAGE + ' ' + JOURNAL_TARGET + ' 2>&1 && echo BINDOK')
        if 'BINDOK' not in probe:
            warns.append('не удалось подключить постоянный журнал (mount --bind отклонён), fstab не менял')
        else:
            changes.append('журнал: bind ' + JOURNAL_STORAGE + ' → ' + JOURNAL_TARGET)
            fst = _run(runner, 'cat ' + FSTAB + ' 2>/dev/null')
            if '/journal-storage' not in fst:
                _run(runner, "printf '%s\\n' '" + JOURNAL_STORAGE + ' ' + JOURNAL_TARGET + " none bind,nofail 0 0' >> " + FSTAB)
                if '/journal-storage' in _run(runner, 'cat ' + FSTAB):
                    changes.append('fstab: строка bind добавлена (bind,nofail)')
    mid = _run(runner, 'wc -c < ' + MACHINE_ID + ' 2>/dev/null').strip()
    if mid and int(mid or 0) > 10:
        imm = _run(runner, 'lsattr ' + MACHINE_ID + ' 2>/dev/null')
        flag = imm.split()[0] if imm and imm.split() else ''
        if 'i' not in flag:
            out = _run(runner, 'chattr +i ' + MACHINE_ID + ' 2>&1 && echo PINOK')
            if 'PINOK' in out:
                changes.append('machine-id зафиксирован (не будет меняться на каждой загрузке)')
    elif not mid:
        warns.append(MACHINE_ID + ' пуст/недоступен — journald может терять прошлые загрузки')
    if 'Storage=persistent drop-in' in changes:
        out = _run(runner, 'systemctl restart systemd-journald 2>&1 && echo JOK')
        if 'JOK' not in out:
            warns.append('не удалось перезапустить systemd-journald (drop-in применится на следующей загрузке)')
        else:
            changes.append('journald перезапущен с persistent')
    return (changes, warns[0] if warns else None)

def ensure_all(runner) -> tuple:
    out_changes, warns = (ensure_anti_hang(runner), [])
    c1 = out_changes
    c2, w2 = ensure_journal_persistence(runner)
    warns = [w2] if w2 else []
    return (c1 + c2, warns[0] if warns else None)
