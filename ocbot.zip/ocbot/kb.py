import json
import os
import re
_cache = None

def load() -> dict:
    global _cache
    if _cache is None:
        path = os.path.join(os.path.dirname(__file__), 'data', 'kb.json')
        try:
            with open(path, encoding='utf-8') as f:
                _cache = json.load(f)
        except (OSError, ValueError):
            _cache = {'models': {}, 'presets': {}, 'ceilings': {}}
    return _cache

def norm_model(name) -> str:
    return re.sub('\\s+', ' ', (name or '').replace('NVIDIA', '').replace('GeForce', '')).strip()

def preset(model, mem_vendor, algo) -> dict:
    presets = load()['presets']
    m, a = (norm_model(model), (algo or '').lower())
    if not a:
        return None
    v = (mem_vendor or '').strip().capitalize()
    return presets.get(f'{m}|{v}|{a}') or presets.get(f'{m}||{a}')

def ceiling(model) -> dict:
    return load()['ceilings'].get(norm_model(model))
