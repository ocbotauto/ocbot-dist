#!/bin/sh
# Установка бота на риг HiveOS: bash install.sh   (запускать из папки бота)
set -e
cd "$(dirname "$0")"
command -v python3 >/dev/null || { echo "python3 не найден"; exit 1; }
python3 -m ocbot --setup
