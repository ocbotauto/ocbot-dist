from __future__ import annotations
import json
import os
import queue
import time

def lang_of(cfg) -> str:
    try:
        with open(getattr(cfg, 'state_path', 'ocbot_state.json'), encoding='utf-8') as f:
            data = json.load(f)
        lang = data.get('lang') or data.get('lang_detected')
        return 'en' if lang == 'en' else 'ru'
    except (OSError, ValueError, TypeError, AttributeError):
        return 'ru'

class State:

    def __init__(self, path: str):
        self.path = path
        self.data = {'reboots': [], 'tuning_reboots': [], 'delay_minutes': 0, 'solo_verify': [], 'mode': None}
        try:
            with open(path, encoding='utf-8') as f:
                self.data.update(json.load(f))
        except (FileNotFoundError, json.JSONDecodeError):
            pass

    def save(self) -> None:
        tmp = self.path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(self.data, f)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, self.path)

    def reboots_24h(self, now: float, kind: str='fault') -> int:
        key = 'reboots' if kind == 'fault' else 'tuning_reboots'
        return sum((1 for t in self.data[key] if now - t < 86400))

    def record_reboot(self, now: float, kind: str='fault', reason: str='') -> None:
        key = 'reboots' if kind == 'fault' else 'tuning_reboots'
        self.data[key] = [t for t in self.data[key] if now - t < 86400] + [now]
        self.data['last_reboot'] = {'time': now, 'kind': kind, 'reason': reason}
        self.save()

    def set_delay(self, minutes: int) -> None:
        self.data['delay_minutes'] = minutes
        self.save()

    def pop_delay(self) -> int:
        m = int(self.data.get('delay_minutes', 0))
        if m:
            self.data['delay_minutes'] = 0
            self.save()
        return m

    def add_solo(self, uuid: str) -> None:
        if uuid not in self.data['solo_verify']:
            self.data['solo_verify'].append(uuid)
            self.save()

    def is_solo(self, uuid: str) -> bool:
        return uuid in self.data['solo_verify']

    def clear_solo(self, uuid: str) -> None:
        if uuid in self.data['solo_verify']:
            self.data['solo_verify'].remove(uuid)
            self.save()

class PersistentQueue(queue.Queue):

    def __init__(self, state, key: str, ttl: float=10800.0, cap: int=50, key_fn=None, no_restore=lambda item: False):
        super().__init__()
        self._state, self._key, self._ttl, self.cap, self._key_fn = (state, key, ttl, cap, key_fn)
        self._times: list = []
        self._loading = True
        self.restored, self.dropped = (0, [])
        now = time.time()
        for rec in state.data.get(key) or []:
            if isinstance(rec, dict):
                item, at = (rec.get('i'), float(rec.get('t') or now))
            else:
                item, at = (rec, now)
            if isinstance(item, (list, tuple)):
                if not item:
                    continue
                item = item[0] if key == 'q_restore' and len(item) == 1 else tuple(item)
            elif item is None:
                continue
            if no_restore(item):
                self.dropped.append((item, 'не восстанавливается после перезапуска'))
            elif now - at > ttl:
                self.dropped.append((item, f'старше {int(ttl // 3600)} ч'))
            else:
                super()._put(item)
                self._times.append(at)
        self.restored = len(self.queue)
        self._loading = False
        if self.dropped:
            self._flush()

    def _flush(self) -> None:
        if self._loading:
            return
        self._state.data[self._key] = [{'t': t, 'i': list(x) if isinstance(x, tuple) else [x]} for x, t in zip(self.queue, self._times)]
        try:
            self._state.save()
        except (OSError, RuntimeError, TypeError, ValueError):
            pass

    def put(self, item, block=True, timeout=None):
        with self.mutex:
            if self._key_fn is not None:
                k = self._key_fn(item)
                keep = [(x, t) for x, t in zip(self.queue, self._times) if k is None or self._key_fn(x) != k]
                same = k is None and any((x == item for x in self.queue))
                if same:
                    return
                if len(keep) != len(self.queue):
                    self.queue.clear()
                    self.queue.extend((x for x, _ in keep))
                    self._times = [t for _, t in keep]
            elif item in self.queue:
                return
            if len(self.queue) >= self.cap:
                raise queue.Full
            self._put(item)
            self.unfinished_tasks += 1
            self.not_empty.notify()

    def _put(self, item) -> None:
        super()._put(item)
        self._times.append(time.time())
        self._flush()

    def _get(self):
        item = super()._get()
        if self._times:
            self._times.pop(0)
        self._flush()
        return item

    def snapshot(self) -> list:
        now = time.time()
        with self.mutex:
            return [(x, now - t) for x, t in zip(self.queue, self._times)]

    def clear(self) -> int:
        with self.mutex:
            n = len(self.queue)
            self.queue.clear()
            self._times = []
            self._flush()
        return n
