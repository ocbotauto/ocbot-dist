from __future__ import annotations
import json
import logging
import os
import queue
import re
import statistics
import subprocess
import threading
import time
import uuid as uuidlib
from dataclasses import dataclass, replace
from datetime import datetime, timedelta, timezone
from typing import Callable, Optional
from . import balance, catalog, clocklock, escalation
from . import backend as backend_mod
from .backend import BackendError, CommandTimeout, bus_key
from .config import Config
from .db import DB, BOUNDARY_CAUSES, utcnow
from .escalation import Action
from .importer import preset_message
from .optimizer import dominated, EvalResult, Point, Searcher, shift_safe
from .psu import PsuGuard
log = logging.getLogger('ocbot')

def L(lang: str, ru: str, en: str) -> str:
    return en if lang == 'en' else ru

class Stopped(Exception):
    pass

class PsuOverload(Exception):
    pass

class Clock:

    def now(self) -> float:
        return time.time()

    def sleep(self, s: float) -> None:
        time.sleep(s)

@dataclass
class Result:
    run_id: int
    status: str
    cause: Optional[str] = None
    hashrate: float = 0.0
    power: float = 0.0
    eff: float = 0.0
    invalid: float = 0.0
    tcore: float = 0.0
    tmem: Optional[float] = None

    @property
    def boundary(self) -> bool:
        return self.cause in BOUNDARY_CAUSES

def iso_ts(s: str) -> float:
    return datetime.fromisoformat(s).timestamp()

class Agent:

    def __init__(self, cfg: Config, db: DB, backend, state, clock=None, notify: Optional[Callable[[str], None]]=None, on_verified: Optional[Callable[[str], None]]=None):
        self.cfg, self.db, self.backend, self.state = (cfg, db, backend, state)
        self.clock = clock or Clock()
        self.notify = notify or (lambda text: log.info('notify: %s', text))
        self.on_verified = on_verified or (lambda profile_id: None)
        self.license_gate: Optional[Callable[[], tuple]] = None
        self._lic_msg: Optional[str] = None
        self.hwid = ''
        self.commands = self._pqueue('q_commands')
        self.stop_flag = threading.Event()
        self.halted = False
        self.gpus: dict = {}
        self.paused: set = set()
        self._hidden_note: dict = {}
        self.recheck_needed: set = set()
        self.force_verify: set = set()
        self.pending: dict = {}
        self.rounds: dict = {}
        self.extended: dict = {}
        self.seed_from: dict = {}
        self.xid_seen = 0
        self.recent_xids: list = []
        self._xid_noise_notified: set = set()
        self._work_xids: list = [tuple(x) for x in self.state.data.get('work_xids') or []]
        self._cuda_pending: list = []
        self.driver = getattr(backend, 'driver_version', lambda: None)()
        self._pl: dict = {}
        self.psu = PsuGuard(cfg)
        self._psu_seen: set = set()
        self.mode_requests = self._pqueue('q_mode')
        self.mode_gen = 0
        self.pending_gen: dict = {}
        self.retune_all = False
        self.params_requests = self._pqueue('q_params')
        self.lift_override: dict = {}
        self.lock_override: dict = {}
        self.boost: Optional[str] = None
        self._boost_pl: dict = {}
        self._boost_x_pl: Optional[int] = None
        self._probed: set = set()
        self.restore_requests = self._pqueue('q_restore')
        self.restored: set = set()
        self.bg_progress: dict = {}
        self.frozen_notified: set = set()
        self.scouted: set = set()
        self._searcher = None
        self._searcher_uuid: Optional[str] = None
        self._zero_since: Optional[float] = None
        self._zero_checked: float = 0.0
        self._zero_hold_until: float = 0.0
        self._zero_deadline: Optional[float] = None
        self._miner_restart_done = False
        self._miner_restarts: list = []
        self._drv_err_since: Optional[float] = None
        self._stats_lie_warned: float = 0.0
        self._gain_now: Optional[float] = None
        self.phase: tuple = ('запуск', self.clock.now())
        self.measuring: Optional[dict] = None
        self.beat: float = self.clock.now()
        self._wall_beat: float = time.time()
        self._watchdog_started = False
        self._workload_checked: float = 0.0
        m = state.data.get('mode')
        if m:
            cfg.objective, cfg.eff_tolerance = (m['objective'], float(m['tolerance']))

    def _touch_beat(self) -> None:
        self.beat = self.clock.now()
        self._wall_beat = time.time()

    def start_watchdog(self) -> None:
        if self._watchdog_started:
            return
        self._watchdog_started = True
        t = threading.Thread(target=self._watchdog_loop, name='ocbot-watchdog', daemon=True)
        t.start()

    def _watchdog_loop(self) -> None:
        while True:
            time.sleep(60)
            age = time.time() - self._wall_beat
            if age < self.cfg.watchdog_hang_minutes * 60:
                continue
            try:
                log.error('сторожевой поток: главный цикл не подаёт признаков жизни %.0f мин — жёсткая перезагрузка рига в обход бота', age / 60)
            except Exception:
                pass
            try:
                os.sync()
            except Exception:
                pass
            try:
                with open('/proc/sysrq-trigger', 'w') as f:
                    f.write('b')
            except Exception:
                try:
                    os.system('reboot -f')
                except Exception:
                    pass
            time.sleep(300)

    def _cpu_watch(self) -> None:
        limit = getattr(self.cfg, 'max_temp_cpu', 0)
        if not limit:
            return
        try:
            t = self.backend.cpu_temp()
        except (BackendError, AttributeError):
            return
        if t is None:
            return
        now = self.clock.now()
        if t >= limit and now - getattr(self, '_cpu_hot_ts', -1000000000.0) >= 3600:
            self._cpu_hot_ts = now
            self.notify(L(self.lang, f'Перегрев CPU: {t:.0f}°C при пределе {limit}°C. Разгон карт не трогаю, но проверьте охлаждение рига: перегретые процессор и плата — частая причина зависаний всего рига.', f'CPU overheat: {t:.0f}°C over the {limit}°C limit. Not touching the card OC, but check the rig cooling: a hot CPU and board are a common cause of whole-rig freezes.'))

    def _autofan_ensure(self) -> None:
        if not getattr(self.cfg, 'autofan', False):
            return
        ok = False
        try:
            ok = self.backend.run(['systemctl', 'is-active', 'autofan']).strip() == 'active'
        except Exception:
            pass
        if not ok:
            try:
                self.backend.run(['systemctl', 'enable', '--now', 'autofan'])
                ok = True
            except Exception as e:
                log.warning('autofan: не удалось запустить сервис: %s', e)
        if ok and (not self.state.data.get('autofan_notified')):
            self.state.data['autofan_notified'] = True
            try:
                self.state.save()
            except Exception:
                pass
            self.notify(L(self.lang, 'Вентиляторы отданы Hive autofan: процент оборотов в точках разгона игнорирую. Целевые температуры настраиваются в панели Hive (раздел autofan).', 'Fans are handed over to Hive autofan: the fan % in overclock points is ignored. Target temps are set in the Hive panel (autofan section).'))

    def label(self, uuid: str) -> str:
        row = self.db.gpu(uuid)
        if row and row['label']:
            return row['label']
        return self.tag(uuid)

    def tag(self, uuid: str) -> str:
        g = self.gpus.get(uuid)
        if not g:
            return uuid[-8:]
        name = re.sub('^NVIDIA\\s+', '', g.model or '').strip()
        mem = f' {g.mem_mb} MB' if g.mem_mb else ''
        return f'GPU {g.slot} {name}{mem}'.strip()

    def card_full(self, uuid: str, slot=None) -> str:
        g = self.gpus.get(uuid)
        if not g:
            return self.label_slot(uuid, slot)
        lab = self.db.gpu(uuid)
        bus = re.search('([0-9a-fA-F]{2}:[0-9a-fA-F]{2}\\.\\d)$', g.bus_id or '')
        name = re.sub('^NVIDIA\\s+', '', g.model or '').strip() + (f' {g.mem_mb} MB' if g.mem_mb else '')
        parts = [f'GPU {g.slot}', bus.group(1).lower() if bus else None, name, g.board]
        if lab and lab['label']:
            parts.append(f"«{lab['label']}»")
        return ' · '.join((p for p in parts if p))

    def label_slot(self, uuid: str, slot=None) -> str:
        lab = self.label(uuid)
        if lab.startswith('GPU '):
            return lab
        n = self.gpus[uuid].slot if uuid in self.gpus else slot
        return f'GPU {n} {lab}' if n is not None else lab

    def set_workload(self, algo: str, miner: str, version: str) -> None:
        changed = (algo, miner, version) != (self.cfg.algo, self.cfg.miner, self.cfg.miner_version)
        self.cfg.algo, self.cfg.miner, self.cfg.miner_version = (algo, miner, version)
        if changed:
            self.state.data['alloc'] = {}
            self.state.data['balance'] = {'phase': 'idle', 'done': []}
            self.state.save()
            self.frozen_notified.clear()
            self.scouted.clear()
            self.pending.clear()
            self.bg_progress.clear()
            self._save_workload_config()

    def _save_workload_config(self) -> bool:
        path = getattr(self.cfg, '_path', None)
        if not path:
            return False
        try:
            with open(path, encoding='utf-8') as f:
                raw = json.load(f)
            raw.update(algo=self.cfg.algo, miner=self.cfg.miner, miner_version=self.cfg.miner_version, stats_cmd=self.cfg.stats_cmd)
            tmp = path + '.tmp'
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump(raw, f, ensure_ascii=False, indent=2)
            os.replace(tmp, path)
            return True
        except (OSError, ValueError) as e:
            log.warning('конфиг не записан после смены полётного листа: %s', e)
            return False

    def check_workload_change(self, interval_s: float=60.0) -> None:
        t = self.clock.now()
        if t - self._workload_checked < interval_s:
            return
        self._workload_checked = t
        from .setup import detect_last_stat, detect_miner, detect_miner_api, detect_stats_file
        raw_name, raw_ver, raw_algo = detect_miner()
        ls = {}
        try:
            ls = detect_last_stat()
        except Exception:
            log.exception('не удалось прочитать снимок статистики агента HiveOS')
        api_url, api_algo, api_ver = ('', '', '')
        try:
            api_url, api_algo, api_ver = detect_miner_api()
        except Exception:
            log.exception('не удалось определить интерфейс статистики майнера')
        stats_file = ''
        if not api_url:
            try:
                stats_file = detect_stats_file()
            except Exception:
                log.exception('не удалось найти файл статистики майнера')
        new_algo = ls.get('algo') or raw_algo or api_algo or self.cfg.algo
        ls_miner = ls.get('miner') or ''
        new_miner = raw_name or (ls_miner if ls_miner != 'custom' else '') or self.cfg.miner
        new_ver = ls.get('ver') or raw_ver or api_ver or self.cfg.miner_version
        old = (self.cfg.algo, self.cfg.miner, self.cfg.miner_version)
        if (new_algo, new_miner, new_ver) != old:
            self.set_workload(new_algo, new_miner, new_ver)
            if not self.gpus:
                try:
                    self.refresh_gpus()
                except Exception:
                    log.exception('не удалось обновить список карт после смены полётного листа')
            for u in list(self.gpus):
                self.apply_safe(u)
            self.notify(L(self.lang, f'Полётный лист сменили: алгоритм/майнер {old[0]}/{old[1]} {old[2]} → {new_algo}/{new_miner} {new_ver}. Карты переведены на безопасные профили, прежние пресеты остаются в базе, подбор для новой связки начинается заново с безопасных точек.', f'Flight sheet changed: algorithm/miner {old[0]}/{old[1]} {old[2]} → {new_algo}/{new_miner} {new_ver}. Cards moved to safe profiles, previous presets stay in the database, tuning for the new combination starts over from safe points.'))
            self._recalibrate_stats_unit()
        if api_url:
            self._set_stats_api(api_url)
        elif stats_file:
            self._set_stats_source('file', stats_file)

    def _recalibrate_stats_unit(self) -> None:
        cmd = self.cfg.stats_cmd or ''
        m = re.search('python3\\s+(\\S*rgminer_stats\\.py)', cmd)
        if not m:
            return
        script = m.group(1)
        workdir = os.path.dirname(os.path.dirname(script))
        if not workdir:
            return
        from .setup import detect_unit
        try:
            unit = detect_unit(workdir)
        except Exception:
            log.exception('не удалось пересчитать единицу хешрейта после смены алгоритма')
            return
        if not unit:
            return
        cur = re.search('--unit\\s+(\\S+)', cmd)
        if cur and cur.group(1) == unit:
            return
        new_cmd = cmd.replace(cur.group(0), f'--unit {unit}') if cur else cmd + f' --unit {unit}'
        self.cfg.stats_cmd = new_cmd
        if self._save_workload_config():
            log.info('stats_cmd: единица хешрейта пересчитана после смены алгоритма → %s', unit)
            self.notify(L(self.lang, f'Единица хешрейта в статистике пересчитана под новый алгоритм: {unit}.', f'Hashrate unit in stats recalculated for the new algorithm: {unit}.'))

    def _set_stats_source(self, kind: str, value: str) -> None:
        cmd = self.cfg.stats_cmd or ''
        m = re.search('python3\\s+\\S*rgminer_stats\\.py', cmd)
        if not m:
            return
        cur = re.search('--(api|file)\\s+(\\S+)', cmd)
        cur_kind, cur_val = (cur.group(1), cur.group(2)) if cur else ('api', 'http://127.0.0.1:9200/metrics')
        if cur_kind == kind and cur_val == value:
            return
        flag = f'--{kind} {value}'
        cmd = cmd.replace(cur.group(0), flag) if cur else cmd.replace(m.group(0), m.group(0) + ' ' + flag)
        self.cfg.stats_cmd = cmd
        if self._save_workload_config():
            log.info('stats_cmd: источник статистики майнера → %s', flag)
            self.notify(L(self.lang, f'Источник статистики майнера сменился, бот переключился сам: {flag}', f'Miner stats source changed, the bot switched on its own: {flag}'))

    def _set_stats_api(self, api_url: str) -> None:
        self._set_stats_source('api', api_url)

    def _raw_pl(self, uuid: str) -> tuple:
        if uuid not in self._pl:
            self._pl[uuid] = self.backend.power_limits(uuid)
        return self._pl[uuid]

    def pl_lock(self, uuid: str) -> Optional[int]:
        row = self.db.pl_lock_row(uuid)
        if row is not None:
            return row['watts']
        for token, watts in self.cfg.pl_locks.items():
            if self.resolve(str(token)) == uuid:
                return int(watts)
        return None

    def _caps(self) -> dict:
        al = self.state.data.get('alloc') or {}
        return {self.gpus[u].slot: int(w) for u, w in al.items() if u in self.gpus}

    def psu_cards(self) -> dict:
        out = {}
        for u, g in self.gpus.items():
            try:
                lo = self._raw_pl(u)[0]
            except BackendError:
                continue
            out[g.slot] = (lo, self.pl_lock(u))
        return out

    def psu_problems(self) -> list:
        if not self.psu.configured:
            return []
        return self.psu.ceilings(self.psu_cards(), self._caps(), self.lang)[1]

    def pl_limits(self, uuid: str) -> tuple:
        lo, df, hi = self._raw_pl(uuid)
        lock = self.pl_lock(uuid)
        if lock:
            w = max(lo, min(hi, lock))
            return (w, w, w)
        if self.psu.configured and uuid in self.gpus:
            ceil = self.psu.ceilings(self.psu_cards(), self._caps())[0].get(self.gpus[uuid].slot)
            if self.boost == uuid:
                ceil = self._boost_ceiling(uuid)
            if ceil is not None:
                hi = max(lo, min(hi, ceil))
                df = max(lo, min(df, hi))
        return (lo, df, hi)

    def bounds(self, uuid: str) -> dict:
        lo, _, hi = self.pl_limits(uuid)
        return {'core': self.cfg.search_range('core'), 'mem': self.cfg.search_range('mem'), 'pl': (lo, hi)}

    @property
    def steps(self) -> dict:
        return {'core': self.cfg.step_core, 'mem': self.cfg.step_mem, 'pl': self.cfg.step_pl}

    def safe_point(self, uuid: str) -> Point:
        return Point(0, 0, self.pl_limits(uuid)[1], self.cfg.fan)

    def start_point(self, uuid: str) -> Point:
        lo, df, hi = self.pl_limits(uuid)
        return Point(0, 0, max(lo, int(df * self.cfg.start_pl_frac)), self.cfg.fan)

    def apply(self, uuid: str, p: Point) -> None:
        lo, _, hi = self.pl_limits(uuid)
        pl = max(lo, min(hi, p.pl))
        if pl != p.pl:
            log.info('PL %s -> %s Вт для %s (замок или бюджет БП)', p.pl, pl, uuid)
            p = replace(p, pl=pl)
        waited = 0
        while True:
            try:
                fan = None if getattr(self.cfg, 'autofan', False) else p.fan
                self.backend.apply(uuid, p.core + self._lift_extra(uuid, p), p.mem, p.pl, fan)
                self._sync_locks(uuid, p)
                return
            except BackendError as e:
                if not self._display_down(e) or self._card_hidden(e) or waited >= self.cfg.display_wait_s:
                    raise
                if waited == 0:
                    log.warning('X-сервер недоступен (nvidia-settings не видит дисплей), жду до %s с', self.cfg.display_wait_s)
                self.clock.sleep(15)
                waited += 15
    DISPLAY_ERRORS = ('control display is undefined', 'unable to init server', 'could not open display', 'cannot open display', 'no targets match', 'error resolving target')

    @staticmethod
    def _card_hidden(e) -> bool:
        s = str(e).lower()
        return 'no targets match' in s or 'error resolving target' in s

    @classmethod
    def _display_down(cls, e) -> bool:
        s = str(e).lower()
        return any((m in s for m in cls.DISPLAY_ERRORS))

    def apply_safe(self, uuid: str) -> None:
        self.lock_override[uuid] = (None, None)
        try:
            self.apply(uuid, self.safe_point(uuid))
        except BackendError as e:
            log.warning('не удалось применить безопасный профиль %s: %s', uuid, e)
        finally:
            self.lock_override.pop(uuid, None)

    def resolve(self, token: str) -> Optional[str]:
        for u, g in self.gpus.items():
            if token == (self.db.gpu(u)['label'] or '') or token == str(g.slot):
                return u
        for u in self.gpus:
            if u.endswith(token):
                return u
        return None

    def poll_xids(self) -> list:
        allx = self.backend.xids()
        if len(allx) < self.xid_seen:
            self.xid_seen = 0
        new, self.xid_seen = (allx[self.xid_seen:], len(allx))
        if new:
            now = self.clock.now()
            with open(self.cfg.xid_log_path, 'a', encoding='utf-8') as f:
                for e in new:
                    f.write(f"{now}|{bus_key(e['bus'])}|{e['code']}\n")
                f.flush()
                os.fsync(f.fileno())
            self.recent_xids += [(now, bus_key(e['bus']), e['code']) for e in new]
        return new

    def read_xid_log(self, since: float) -> list:
        out = []
        try:
            with open(self.cfg.xid_log_path, encoding='utf-8') as f:
                for ln in f:
                    ts, bus, code = ln.strip().split('|')
                    if float(ts) >= since:
                        out.append((float(ts), bus, int(code)))
        except (FileNotFoundError, ValueError):
            pass
        return out

    def _codes_for(self, uuid: str, since: float) -> list:
        g = self.gpus.get(uuid)
        if not g:
            return []
        k = bus_key(g.bus_id)
        return [c for ts, b, c in self.recent_xids if b == k and ts >= since]

    @staticmethod
    def _cause_from_codes(visible: bool, codes: list) -> str:
        if not visible or 79 in codes:
            return 'bus_lost'
        return 'aggressive_oc' if codes else 'unknown'

    def _xid_counts(self, bus: str, now: float) -> tuple:
        hard = set(self.cfg.xid_hard_codes)
        soft = [ts for ts, b, c in self._work_xids if b == bus and c not in hard]
        win = sum((1 for ts in soft if now - ts <= self.cfg.xid_storm_window_s))
        return (win, len(soft))

    def _xid_work_react(self, new: list, by_bus: dict, missing: set) -> None:
        cfg = self.cfg
        hard = set(cfg.xid_hard_codes)
        now = self.clock.now()
        benign_new = [(now, bus_key(e['bus']), e['code']) for e in new if e['code'] not in hard]
        if benign_new:
            cut = now - 86400
            self._work_xids = [x for x in self._work_xids if x[0] >= cut] + benign_new
            self.state.data['work_xids'] = self._work_xids
            try:
                self.state.save()
            except Exception:
                pass
        per_card: dict = {}
        for e in new:
            g = by_bus.get(bus_key(e['bus']))
            if g and g.uuid not in self.paused and (g.uuid not in missing):
                per_card.setdefault(g.uuid, []).append(e['code'])
        storms = []
        for u, codes in per_card.items():
            g = self.gpus[u]
            hard_hit = next((c for c in codes if c in hard), None)
            if hard_hit is not None:
                self.on_work_drop(g, hard_hit)
                continue
            win, day = self._xid_counts(bus_key(g.bus_id), now)
            if win >= cfg.xid_storm_count or day > cfg.xid_day_limit:
                storms.append((g, win, day))
            elif day <= cfg.xid_noise_per_day:
                if u not in self._xid_noise_notified:
                    self._xid_noise_notified.add(u)
                    self.notify(L(self.lang, f'Карта {self.label(u)}: одиночный Xid {codes[0]}, майнер справился сам. Это в пределах нормы ({day} за сутки при допуске {cfg.xid_noise_per_day}): пресет и хешрейт не трогаю, наблюдаю.', f'Card {self.label(u)}: isolated Xid {codes[0]}, the miner recovered on its own. Within normal range ({day} in 24h, tolerance {cfg.xid_noise_per_day}): preset and hashrate untouched, watching.'))
            else:
                log.info('карта %s: %s доброкачественных Xid за сутки — выше шума, но без всплеска; наблюдаю', self.label(u), day)
        if not storms:
            return
        if len(storms) >= cfg.xid_rigwide_cards and len([u for u in self.gpus if u not in self.paused]) >= cfg.xid_rigwide_cards:
            names = ', '.join((self.label(g.uuid) for g, _, _ in storms))
            self.db.log_change(storms[0][0].uuid, cfg.algo, cfg.miner, None, None, f'Xid-шторм сразу на {len(storms)} картах: общий сбой (питание/майнер/драйвер), пресеты и границы не менялись')
            self.notify(L(self.lang, f'Xid-шторм сразу на {len(storms)} картах ({names}): это общий сбой — питание, майнер или драйвер, а не разгон отдельных карт. Пресеты и границы НЕ меняю, перезапускаю майнер.', f'Xid storm on {len(storms)} cards at once ({names}): a rig-wide fault — power, miner or driver, not per-card overclock. Presets and boundaries untouched, restarting the miner.'))
            try:
                self.backend.miner('stop')
                self.backend.miner('start')
                self._zero_hold_until = now + 300
            except Exception as e:
                log.warning('не удалось перезапустить майнер после общего Xid-шторма: %s', e)
            return
        for g, win, day in storms:
            self.notify(L(self.lang, f'Карта {self.label(g.uuid)}: Xid-шторм ({win} за {cfg.xid_storm_window_s // 60} мин, {day} за сутки) — точка не держится. Фиксирую границу и отправляю пресет на переподбор ниже.', f'Card {self.label(g.uuid)}: Xid storm ({win} in {cfg.xid_storm_window_s // 60} min, {day} in 24h) — the point is not stable. Recording the boundary and re-tuning the preset lower.'))
            self.on_work_drop(g, 13)

    def _xid_measure_react(self, new: list, by_bus_items: dict, lost: dict, xid_soft: dict) -> None:
        cfg = self.cfg
        hard = set(cfg.xid_hard_codes)
        work_new = []
        for e in new:
            g = by_bus_items.get(bus_key(e['bus']))
            if g is None:
                work_new.append(e)
                continue
            if g.uuid in lost:
                continue
            if e['code'] in hard:
                lost[g.uuid] = self.clock.now()
                log.warning('карта %s: жёсткий Xid %s во время замера — снимаю с замера, применяю безопасный пресет', self.label(g.uuid), e['code'])
                self.notify(L(self.lang, f"Карта {self.label(g.uuid)}: Xid {e['code']} во время замера (драйвер сбросил карту). Замер точки прекращён, применён безопасный пресет, точка будет переподобрана ниже.", f"Card {self.label(g.uuid)}: Xid {e['code']} during measurement (driver reset the card). Measurement of the point stopped, safe preset applied, the point will be re-tuned lower."))
                try:
                    self.apply_safe(g.uuid)
                except Exception as ex:
                    log.warning('не удалось применить безопасный пресет для %s: %s', g.uuid, ex)
                continue
            n = xid_soft.get(g.uuid, 0) + 1
            xid_soft[g.uuid] = n
            if n >= cfg.xid_storm_count:
                lost[g.uuid] = self.clock.now()
                log.warning('карта %s: Xid-шторм во время замера (%s событий) — точка не держится, снимаю с замера', self.label(g.uuid), n)
                self.notify(L(self.lang, f'Карта {self.label(g.uuid)}: Xid-шторм во время замера ({n} событий) — точка не держится. Применён безопасный пресет, точка станет границей и будет переподобрана ниже.', f'Card {self.label(g.uuid)}: Xid storm during measurement ({n} events) — the point is not stable. Safe preset applied; the point becomes the boundary and will be re-tuned lower.'))
                try:
                    self.apply_safe(g.uuid)
                except Exception as ex:
                    log.warning('не удалось применить безопасный пресет для %s: %s', g.uuid, ex)
        if work_new:
            by_bus = {bus_key(g.bus_id): g for g in self.gpus.values()}
            self._xid_work_react(work_new, by_bus, set())

    def refresh_gpus(self) -> None:
        self.db.ensure_rig(self.cfg.rig_name, self.driver)
        self.gpus = {}
        for g in self.backend.list_gpus():
            moved, prev = self.db.upsert_gpu(g.uuid, g.model, g.vbios, g.mem_vendor, self.cfg.rig_name, g.slot)
            self.gpus[g.uuid] = g
            if moved and prev:
                self.recheck_needed.add(g.uuid)
                self.notify(L(self.lang, f'Карта {self.label(g.uuid)} переехала: {prev[0]}/слот {prev[1]} -> {self.cfg.rig_name}/слот {g.slot}. Пресет будет проверен на новом месте.', f'Card {self.label(g.uuid)} moved: {prev[0]}/slot {prev[1]} -> {self.cfg.rig_name}/slot {g.slot}. The preset will be re-verified in its new spot.'))

    def _evaluate(self, samples: list):
        cfg = self.cfg
        hs = [s.hashrate for s in samples]
        med = statistics.median(hs)
        pw = statistics.fmean((s.power_w for s in samples))
        eff = med / pw if pw > 0 else 0.0
        tmem_vals = [s.temp_mem for s in samples if s.temp_mem is not None]
        tcore, tmem = (max((s.temp_core for s in samples)), max(tmem_vals) if tmem_vals else None)
        invalid = samples[-1].invalid_pct
        n, drop = (len(samples), 0.0)
        if n >= 9:
            third = n // 3
            a, b = (statistics.median(hs[:third]), statistics.median(hs[-third:]))
            drop = (a - b) / a * 100 if a > 0 else 0.0
        status, cause = ('ok', None)
        if med <= 0:
            status, cause = ('unstable', 'miner')
        elif cfg.throttle_is_overheat and any((s.thermal_throttle for s in samples)) or tcore >= cfg.max_temp_core or (tmem is not None and tmem >= cfg.max_temp_mem):
            status, cause = ('unstable', 'overheat')
        elif invalid > cfg.max_invalid_pct or drop > cfg.max_drop_pct:
            status, cause = ('unstable', 'aggressive_oc')
        return (status, cause, med, pw, eff, invalid, tcore, tmem)

    def measure_group(self, items: list, kind: str, duration: int, warmup=None, note=None, kinds=None, keep=()) -> dict:
        warm = self.cfg.warmup_s if warmup is None else warmup
        self.measuring = {'kind': kind, 'note': note, 'kinds': dict(kinds or {}), 't0': self.clock.now(), 'total': warm + duration, 'cards': {g.uuid: p for g, p in items}}
        try:
            return self._measure_group(items, kind, duration, warmup, note, kinds, keep)
        finally:
            self.measuring = None
            self._touch_beat()

    def _measure_group(self, items: list, kind: str, duration: int, warmup=None, note=None, kinds=None, keep=()) -> dict:
        cfg = self.cfg
        t0 = self.clock.now()
        items = [(g, self._clamp(g.uuid, p)) for g, p in items]
        runs, rejected = ({}, {})
        for g, p in items:
            runs[g.uuid] = self.db.start_run(gpu_uuid=g.uuid, rig=cfg.rig_name, slot=g.slot, algo=cfg.algo, miner=cfg.miner, miner_version=cfg.miner_version, driver_version=self.driver, vbios=g.vbios, core_offset=p.core, mem_offset=p.mem, power_limit=p.pl, fan=p.fan, kind=(kinds or {}).get(g.uuid, kind), started_at=utcnow(), **{'note': note} if note else {})
            try:
                if g.uuid not in keep:
                    self.apply(g.uuid, p)
            except BackendError as e:
                log.warning('значения не применились для %s: %s', g.uuid, e)
                env = self._display_down(e)
                self.db.finish_run(runs[g.uuid], status='unstable', crash_cause=None if env else 'unknown', note=('нет X-сервера (nvidia-settings): ' if env else 'драйвер не принял значения: ') + str(e)[-160:])
                rejected[g.uuid] = Result(runs[g.uuid], 'unstable', None if env else 'unknown')
                self.apply_safe(g.uuid)
        items = [(g, p) for g, p in items if g.uuid not in rejected]
        if not items:
            return dict(rejected)
        samples = {g.uuid: [] for g, _ in items}
        lost: dict = {}
        hot: set = set()
        xid_soft: dict = {}
        by_bus_items = {bus_key(g.bus_id): g for g, _ in items}
        workload_at_start = (cfg.algo, cfg.miner, cfg.miner_version)
        abort_note = None
        try:
            self._wait(cfg.warmup_s if warmup is None else warmup)
            end = self.clock.now() + duration
            while True:
                for g, _ in items:
                    if g.uuid in lost:
                        continue
                    if g.uuid in hot:
                        continue
                    try:
                        s = self.backend.sample(g.uuid)
                    except CommandTimeout:
                        lost[g.uuid] = self.clock.now()
                        log.warning('карта %s: nvidia-smi не отвечает во время замера, снимаю с замера и применяю безопасный пресет', self.label(g.uuid))
                        try:
                            self.apply_safe(g.uuid)
                        except Exception as e2:
                            log.warning('не удалось применить безопасный пресет для %s: %s', g.uuid, e2)
                        continue
                    if s.lost:
                        lost[g.uuid] = self.clock.now()
                    else:
                        samples[g.uuid].append(s)
                        if self._too_hot(s):
                            hot.add(g.uuid)
                            self.apply_safe(g.uuid)
                new = self.poll_xids()
                if new:
                    self._xid_measure_react(new, by_bus_items, lost, xid_soft)
                self._drain_hive_cuda({bus_key(g.bus_id) for g, _ in items})
                if self.clock.now() >= end or len(lost) + len(hot) == len(items):
                    break
                try:
                    self.check_workload_change()
                except Exception:
                    log.exception('не удалось проверить смену полётного листа во время замера')
                if (cfg.algo, cfg.miner, cfg.miner_version) != workload_at_start:
                    log.info('полётный лист сменился во время замера (%s/%s %s → %s/%s %s), прерываю замер без вердикта по точке', *workload_at_start, cfg.algo, cfg.miner, cfg.miner_version)
                    abort_note = 'прервано: сменился полётный лист во время замера'
                    break
                if not self.commands.empty():
                    log.info('во время замера пришла команда (очередь не пуста), прерываю замер без вердикта по точке, чтобы её разобрали')
                    abort_note = 'прервано: пришла команда во время замера'
                    break
                self._wait(cfg.sample_every_s)
        except (Stopped, PsuOverload) as e:
            for g, _ in items:
                self.db.finish_run(runs[g.uuid], note='остановлено: перегрузка БП' if isinstance(e, PsuOverload) else 'остановлено командой /stop')
                self.apply_safe(g.uuid)
            raise
        if abort_note:
            results = dict(rejected)
            for g, _ in items:
                self.db.finish_run(runs[g.uuid], note=abort_note)
                results[g.uuid] = Result(runs[g.uuid], 'aborted', None)
            return results
        results = dict(rejected)
        dead: list = []
        visible = {x.uuid for x in self.backend.list_gpus()}
        for g, p in items:
            rid = runs[g.uuid]
            if g.uuid in lost or not samples[g.uuid]:
                cause = self._cause_from_codes(g.uuid in visible, self._codes_for(g.uuid, t0))
                self.db.finish_run(rid, status='crash', crash_cause=cause)
                results[g.uuid] = Result(rid, 'crash', cause)
                continue
            status, cause, med, pw, eff, inv, tc, tm = self._evaluate(samples[g.uuid])
            note_dead = None
            if cause != 'overheat' and g.uuid not in hot:
                others = {x.uuid for x, _ in items}
                zero = med <= 0 or all((x.hashrate <= 0 for x in samples[g.uuid][-3:]))
                if zero and self._others_mining(g.uuid, others, samples):
                    status, cause = ('unstable', 'aggressive_oc')
                    note_dead = 'карта отключена майнером: хешрейт 0 при работающих остальных картах'
                    dead.append(g)
                elif not zero and self._collapsed(samples[g.uuid]) and self._others_mining(g.uuid, others, samples):
                    status, cause = ('unstable', 'aggressive_oc')
                    note_dead = 'хешрейт карты обвалился и восстановился сам: точка нестабильна'
                    self.apply_safe(g.uuid)
                elif self._restarted(samples[g.uuid]) and (not self._rig_wide_restart(g.uuid, samples, t0)):
                    status, cause = ('unstable', 'aggressive_oc')
                    note_dead = 'майнер перезапустил карту после CUDA-ошибки: точка нестабильна'
                    self.apply_safe(g.uuid)
            self.db.finish_run(rid, status=status, crash_cause=cause, hashrate_median=med, power_w=pw, efficiency=eff, invalid_share_pct=inv, max_temp_core=tc, max_temp_mem=tm, **{'note': note_dead} if note_dead else {})
            results[g.uuid] = Result(rid, status, cause, med, pw, eff, inv, tc, tm)
        if dead:
            self._revive_miner(dead)
        if note:
            for g, _ in items:
                if (kinds or {}).get(g.uuid, kind) != kind:
                    continue
                self.db.x('update runs set note=? where id=?', (note, runs[g.uuid]))
        return results

    @staticmethod
    def _restarted(ss: list) -> bool:
        ups = [x.uptime_s for x in ss if x.uptime_s is not None]
        return any((b < a - 5 for a, b in zip(ups, ups[1:])))

    def _rig_wide_restart(self, uuid: str, samples: dict, t0: float) -> bool:
        others = [ss for u, ss in samples.items() if u != uuid and ss]
        if others and all((self._restarted(ss) for ss in others)):
            return True
        elapsed = self.clock.now() - t0
        for u in self.gpus:
            if u == uuid or u in samples:
                continue
            try:
                up = self.backend.sample(u).uptime_s
            except Exception:
                continue
            if up is not None and up < elapsed:
                return True
        return False

    def _collapsed(self, ss: list) -> bool:
        if len(ss) < 4:
            return False
        mh = statistics.median((x.hashrate for x in ss))
        mp = statistics.median((x.power_w for x in ss))
        if mh <= 0:
            return False
        bad = [x.hashrate <= 0 or (x.hashrate < 0.5 * mh and x.power_w < 0.5 * mp) for x in ss]
        return any((a and b for a, b in zip(bad, bad[1:])))

    def _others_mining(self, uuid: str, in_window: set, samples: dict) -> bool:
        for u, ss in samples.items():
            if u != uuid and ss and (statistics.median((x.hashrate for x in ss[-3:])) > 0):
                return True
        for u in self.gpus:
            if u == uuid or u in in_window:
                continue
            try:
                if self.backend.sample(u).hashrate > 0:
                    return True
            except Exception:
                continue
        return False

    def _revive_miner(self, dead: list) -> None:
        for g in dead:
            self.apply_safe(g.uuid)
        self._wait(self.cfg.revive_wait_s)
        still = []
        for g in dead:
            try:
                if self.backend.sample(g.uuid).hashrate <= 0:
                    still.append(g)
            except Exception:
                still.append(g)
        if not still:
            self.notify(L(self.lang, 'Карта отключалась на этой точке, но на безопасном профиле вернулась сама: майнер не трогаю, точка станет границей.', 'The card dropped out at this point but came back on its own on the safe profile: leaving the miner alone, this point becomes a boundary.'))
            return
        dead = still
        names = ', '.join((self.label(g.uuid) for g in dead))
        self.notify(L(self.lang, f'Карта {names}: майнер отключил карту (CUDA-ошибка на этой точке разгона). Ставлю безопасный профиль и перезапускаю майнер, точка станет границей.', f'Card {names}: the miner dropped the card (a CUDA error at this overclock point). Applying the safe profile and restarting the miner; this point becomes a boundary.'))
        try:
            self.backend.miner('stop')
            self.backend.miner('start')
            self._zero_hold_until = self.clock.now() + 300
        except Exception as e:
            log.warning('не удалось перезапустить майнер: %s', e)

    def _note_extension(self, uuid: str, p: Point) -> None:
        for axis, edge in (('core', self.cfg.core_range[1]), ('mem', self.cfg.mem_range[1])):
            v = getattr(p, axis)
            if self.cfg.auto_extend and v > edge and (v > self.extended.get((uuid, axis), edge)):
                first = (uuid, axis) not in self.extended
                self.extended[uuid, axis] = v
                if first:
                    self.notify(L(self.lang, f'Карта {self.label(uuid)}: {axis} держится выше начального диапазона ({edge}), расширяю поиск дальше, пока нет перегрева или отвала.', f'Card {self.label(uuid)}: {axis} is holding above the initial range ({edge}), extending the search further until it overheats or crashes.'))

    def _too_hot(self, s) -> bool:
        cfg = self.cfg
        return s.temp_core >= cfg.max_temp_core or (s.temp_mem is not None and s.temp_mem >= cfg.max_temp_mem)

    def _psu_watch(self) -> None:
        if not self.psu.configured:
            return
        try:
            draws = self.backend.power_draws()
        except (BackendError, AttributeError):
            return
        msg = self.psu.overload({self.gpus[u].slot: w for u, w in draws.items() if u in self.gpus}, self.lang)
        if msg:
            raise PsuOverload(msg)

    def handle_overload(self, e: Exception) -> None:
        for u in self.gpus:
            self.apply_safe(u)
        self.halted = True
        self.stop_flag.clear()
        self.notify(L(self.lang, f'ПЕРЕГРУЗКА БЛОКА ПИТАНИЯ: {e}. Применил безопасные профили, автоматика остановлена. Проверьте psu_watts/base_watts и PL; /resume продолжит работу.', f'PSU OVERLOAD: {e}. Applied safe profiles, automation stopped. Check psu_watts/base_watts and PL; /resume will continue.'))

    def psu_report(self) -> str:
        lang = self.lang
        if not self.psu.configured:
            return L(lang, 'БП не описан в конфиге (psu_watts или psu_groups)', 'PSU not described in the config (psu_watts or psu_groups)')
        try:
            draws = {self.gpus[u].slot: w for u, w in self.backend.power_draws().items() if u in self.gpus}
        except (BackendError, AttributeError):
            draws = {}
        cards = self.psu_cards()
        ceil, errors = self.psu.ceilings(cards, self._caps(), lang)
        lines = []
        if lang == 'en':
            for g in self.psu.groups:
                slots = [s for s in cards if self.psu.group_of(s) is g]
                now = sum((draws.get(s, 0.0) for s in slots)) + g.base_watts
                cap = g.cap or self.cfg.pl_total_max
                lines.append(f"{g.name}: {g.watts} W, cards: slots {', '.join(map(str, sorted(slots))) or 'none'}, base (system) {g.base_watts} W, total PL ceiling {self.psu.budget(g) / self.cfg.psu_transient:.0f} W" + (f' (set to {cap} W)' if cap else '') + f', emergency threshold {self.psu.hard_total(g):.0f} W, now {now:.0f} W')
            for u, g in self.gpus.items():
                lo, _, hi = self.pl_limits(u)
                lock = self.pl_lock(u)
                lines.append(f'{self.label_slot(u)}: PL ' + (f'locked at {lock} W' if lock else f'{lo}..{hi} W') + (f', PSU ceiling {ceil[g.slot]} W' if g.slot in ceil and (not lock) else ''))
            draft = self.state.data.get('psu_draft')
            if draft is not None:
                lines.append('Draft (not applied, waiting for every card to be assigned): ' + self._psu_text(draft) + '. /psu cancel discards it.')
            return '\n'.join(lines + [f'Problem: {e}' for e in errors])
        for g in self.psu.groups:
            slots = [s for s in cards if self.psu.group_of(s) is g]
            now = sum((draws.get(s, 0.0) for s in slots)) + g.base_watts
            cap = g.cap or self.cfg.pl_total_max
            lines.append(f"{g.name}: {g.watts} Вт, карты: слоты {', '.join(map(str, sorted(slots))) or 'нет'}, база (система) {g.base_watts} Вт, потолок суммы PL {self.psu.budget(g) / self.cfg.psu_transient:.0f} Вт" + (f' (задан {cap} Вт)' if cap else '') + f', аварийный порог {self.psu.hard_total(g):.0f} Вт, сейчас {now:.0f} Вт')
        for u, g in self.gpus.items():
            lo, _, hi = self.pl_limits(u)
            lock = self.pl_lock(u)
            lines.append(f'{self.label_slot(u)}: PL ' + (f'заблокирован на {lock} Вт' if lock else f'{lo}..{hi} Вт') + (f', потолок по БП {ceil[g.slot]} Вт' if g.slot in ceil and (not lock) else ''))
        draft = self.state.data.get('psu_draft')
        if draft is not None:
            lines.append('Черновик (не применён, ждёт привязки всех карт): ' + self._psu_text(draft) + '. /psu cancel сбросит.')
        return '\n'.join(lines + [f'Проблема: {e}' for e in errors])

    def set_psu(self, watts: int, cap: int, base=None) -> None:
        cfg, lang = (self.cfg, self.lang)
        errs = []
        if not 300 <= watts <= 6000:
            errs.append(L(lang, f'мощность БП {watts} Вт вне разумного диапазона 300..6000', f'PSU wattage {watts} W is outside the reasonable 300..6000 range'))
        if not 100 <= cap <= watts:
            errs.append(L(lang, f'лимит карт {cap} Вт должен быть от 100 до мощности БП ({watts} Вт)', f'card limit {cap} W must be between 100 and the PSU wattage ({watts} W)'))
        if base is not None and (not 0 <= base <= 1500):
            errs.append(L(lang, f'база рига {base} Вт вне диапазона 0..1500', f'rig base {base} W is outside the 0..1500 range'))
        if errs:
            self.notify(L(lang, 'БП не изменён: ', 'PSU not changed: ') + '; '.join(errs))
            return
        old = (cfg.psu_watts, cfg.pl_total_max, cfg.psu_base_watts)
        cfg.psu_watts, cfg.pl_total_max = (int(watts), int(cap))
        if base is not None:
            cfg.psu_base_watts = int(base)
        cfg.psu_groups = []
        self.state.data.pop('psu_draft', None)
        self.psu = PsuGuard(cfg)
        self.state.data['alloc'] = {}
        self.state.data['balance'] = {'phase': 'idle', 'done': []}
        self.state.save()
        saved = self._save_psu_config()
        for u in self.gpus:
            try:
                self._apply_preset_or_safe(u)
            except BackendError as e:
                log.warning('не удалось применить пресет карты %s: %s', u, e)
        if lang == 'en':
            head = f'PSU updated: {old[0]} -> {cfg.psu_watts} W, total card PL limit {old[1]} -> {cfg.pl_total_max} W, base {old[2]} -> {cfg.psu_base_watts} W. ' + ('Saved to the config.' if saved else 'Not saved to the config file (values will revert after a restart).')
        else:
            head = f'Блок питания обновлён: {old[0]} -> {cfg.psu_watts} Вт, лимит суммы PL карт {old[1]} -> {cfg.pl_total_max} Вт, база {old[2]} -> {cfg.psu_base_watts} Вт. ' + ('Записано в конфиг.' if saved else 'В файл конфига не записано (после перезапуска вернутся прежние значения).')
        self.notify(head + '\n' + self.psu_report())
        if self.halted and self.psu_guard_ok():
            self.notify(L(lang, 'Проверка БП пройдена. Автоматика на паузе, /resume продолжит работу.', 'PSU check passed. Automation is paused, /resume will continue.'))

    def _save_psu_config(self) -> bool:
        path = getattr(self.cfg, '_path', None)
        if not path:
            return False
        try:
            with open(path, encoding='utf-8') as f:
                raw = json.load(f)
            raw.update(psu_watts=self.cfg.psu_watts, pl_total_max=self.cfg.pl_total_max, psu_base_watts=self.cfg.psu_base_watts, psu_groups=self.cfg.psu_groups)
            tmp = path + '.tmp'
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump(raw, f, ensure_ascii=False, indent=2)
            os.replace(tmp, path)
            return True
        except (OSError, ValueError) as e:
            log.warning('конфиг не записан: %s', e)
            return False

    def _psu_current(self) -> list:
        cfg = self.cfg
        if cfg.psu_groups:
            out = [dict(d) for d in cfg.psu_groups]
            for d in out:
                d['slots'] = sorted((self.gpus[u].slot for u in self.gpus)) if d.get('slots') is None else sorted(d['slots'])
            return out
        if cfg.psu_watts:
            return [{'name': 'PSU1', 'watts': int(cfg.psu_watts), 'base_watts': int(cfg.psu_base_watts), 'slots': sorted((g.slot for g in self.gpus.values())), **({'pl_max': int(cfg.pl_total_max)} if cfg.pl_total_max else {})}]
        return []

    def _psu_text(self, groups: list) -> str:
        if self.lang == 'en':
            return '; '.join((f"{d['name']} {d['watts']} W, cards {','.join(map(str, d['slots'])) or '-'}, base {d.get('base_watts', 0)} W" + (f", card limit {d['pl_max']} W" if d.get('pl_max') else '') for d in groups))
        return '; '.join((f"{d['name']} {d['watts']} Вт, карты {','.join(map(str, d['slots'])) or '-'}, база {d.get('base_watts', 0)} Вт" + (f", лимит карт {d['pl_max']} Вт" if d.get('pl_max') else '') for d in groups))

    @staticmethod
    def _parse_slots(tokens: list) -> list:
        out = set()
        for t in tokens:
            for part in str(t).replace(';', ',').split(','):
                part = part.strip()
                if not part:
                    continue
                if '-' in part:
                    a, b = part.split('-', 1)
                    out.update(range(int(a), int(b) + 1))
                else:
                    out.add(int(part))
        return sorted(out)

    def psu_edit(self, args: list) -> None:
        lang = self.lang
        sub_, rest = (args[0], [str(x) for x in args[1:]])
        draft = self.state.data.get('psu_draft')
        if sub_ == 'cancel':
            self.state.data.pop('psu_draft', None)
            self.state.save()
            self.notify(L(lang, 'Черновик описания БП сброшен.', 'PSU draft discarded.'))
            return
        groups = [dict(d) for d in draft] if draft is not None else self._psu_current()
        by = {d['name'].lower(): d for d in groups}
        try:
            if sub_ == 'add' and len(rest) >= 2:
                name, watts = (rest[0], int(rest[1]))
                d = by.get(name.lower()) or {'name': name, 'base_watts': 0, 'slots': []}
                if name.lower() not in by:
                    groups.append(d)
                d['watts'] = watts
                if len(rest) > 2:
                    d['pl_max'] = int(rest[2])
            elif sub_ == 'del' and len(rest) == 1:
                if rest[0].lower() not in by:
                    raise ValueError(L(lang, f'БП «{rest[0]}» нет', f'no PSU «{rest[0]}»'))
                groups = [d for d in groups if d['name'].lower() != rest[0].lower()]
            elif sub_ == 'cards' and len(rest) >= 2:
                if rest[0].lower() not in by:
                    raise ValueError(L(lang, f'БП «{rest[0]}» нет: сначала /psu add {rest[0]} ВАТТЫ', f'no PSU «{rest[0]}»: first /psu add {rest[0]} WATTS'))
                slots = self._parse_slots(rest[1:])
                bad = [s for s in slots if s not in {g.slot for g in self.gpus.values()}]
                if bad:
                    raise ValueError(L(lang, f'в риге нет слотов {bad}', f'the rig has no slots {bad}'))
                for d in groups:
                    d['slots'] = [s for s in d['slots'] if s not in slots]
                by[rest[0].lower()]['slots'] = slots
            elif sub_ == 'system' and len(rest) >= 1:
                if rest[0].lower() not in by:
                    raise ValueError(L(lang, f'БП «{rest[0]}» нет', f'no PSU «{rest[0]}»'))
                val = int(rest[1]) if len(rest) > 1 else max([int(d.get('base_watts', 0)) for d in groups] + [int(self.cfg.psu_base_watts)])
                for d in groups:
                    d['base_watts'] = 0
                by[rest[0].lower()]['base_watts'] = val
            elif sub_ == 'limit' and len(rest) == 2:
                if rest[0].lower() not in by:
                    raise ValueError(L(lang, f'БП «{rest[0]}» нет', f'no PSU «{rest[0]}»'))
                by[rest[0].lower()]['pl_max'] = int(rest[1])
            else:
                raise ValueError(L(lang, 'не понял команду, смотрите /psu', 'command not understood, see /psu'))
        except ValueError as e:
            self.notify(L(lang, f'БП не изменён: {e}', f'PSU not changed: {e}'))
            return
        errs = []
        for d in groups:
            if not 300 <= int(d['watts']) <= 6000:
                errs.append(L(lang, f"{d['name']}: мощность {d['watts']} Вт вне диапазона 300..6000", f"{d['name']}: wattage {d['watts']} W is outside the 300..6000 range"))
            if d.get('pl_max') and int(d['pl_max']) > int(d['watts']):
                errs.append(L(lang, f"{d['name']}: лимит карт {d['pl_max']} Вт больше мощности БП", f"{d['name']}: card limit {d['pl_max']} W is more than the PSU wattage"))
            if not 0 <= int(d.get('base_watts', 0)) <= 1500:
                errs.append(L(lang, f"{d['name']}: база {d['base_watts']} Вт вне диапазона 0..1500", f"{d['name']}: base {d['base_watts']} W is outside the 0..1500 range"))
        if errs:
            self.notify(L(lang, 'БП не изменён: ', 'PSU not changed: ') + '; '.join(errs))
            return
        have = {g.slot for g in self.gpus.values()}
        covered = {s for d in groups for s in d['slots']}
        if have - covered or not groups:
            self.state.data['psu_draft'] = groups
            self.state.save()
            self.notify(L(lang, 'Черновик описания БП (пока не применён): ' + self._psu_text(groups) + (f'. Не привязаны слоты: {sorted(have - covered)}. Привяжите: /psu cards ИМЯ 0,1,2' if have - covered else '') + '. Когда все карты будут привязаны, изменения применятся сами.', 'PSU draft (not applied yet): ' + self._psu_text(groups) + (f'. Unassigned slots: {sorted(have - covered)}. Assign them: /psu cards NAME 0,1,2' if have - covered else '') + '. Once every card is assigned, the changes apply on their own.'))
            return
        self._apply_psu_groups(groups)

    def _apply_psu_groups(self, groups: list) -> None:
        cfg = self.cfg
        old = self._psu_text(self._psu_current())
        cfg.psu_groups = [{'name': d['name'], 'watts': int(d['watts']), 'base_watts': int(d.get('base_watts', 0)), 'slots': sorted(d['slots']), **({'pl_max': int(d['pl_max'])} if d.get('pl_max') else {})} for d in groups]
        cfg.pl_total_max = 0
        self.psu = PsuGuard(cfg)
        self.state.data.pop('psu_draft', None)
        self.state.data['alloc'] = {}
        self.state.data['balance'] = {'phase': 'idle', 'done': []}
        self.state.save()
        saved = self._save_psu_config()
        for u in self.gpus:
            try:
                self._apply_preset_or_safe(u)
            except BackendError as e:
                log.warning('не удалось применить пресет карты %s: %s', u, e)
        lang = self.lang
        self.notify(L(lang, f"Блоки питания обновлены. Было: {old or 'не описано'}. Стало: {self._psu_text(groups)}. " + ('Записано в конфиг.' if saved else 'В файл конфига не записано.') + '\n' + self.psu_report(), f"PSUs updated. Was: {old or 'not described'}. Now: {self._psu_text(groups)}. " + ('Saved to the config.' if saved else 'Not saved to the config file.') + '\n' + self.psu_report()))
        self.psu_guard_ok()

    def psu_guard_ok(self) -> bool:
        lang = self.lang
        if self.cfg.psu_required and (not self.psu.configured):
            msgs = [L(lang, 'блок питания не описан в конфиге (psu_watts или psu_groups): автоматика остановлена, чтобы не перегрузить БП. Укажите мощность БП и базу рига, затем /resume', 'PSU not described in the config (psu_watts or psu_groups): automation stopped to avoid overloading the PSU. Set the PSU wattage and rig base, then /resume')]
        else:
            msgs = self.psu_problems()
        if msgs:
            self.halted = True
            for m in msgs:
                if m not in self._psu_seen:
                    self._psu_seen.add(m)
                    self.notify(L(lang, 'БП: ', 'PSU: ') + m)
            return False
        self._psu_seen.clear()
        return True

    def cmd_pl(self, token: str, value: str) -> None:
        lang = self.lang
        u = self.resolve(token)
        if not u:
            self.notify(L(lang, f'/pl: карта {token} не найдена', f'/pl: card {token} not found'))
            return
        lo, _, hi = self._raw_pl(u)
        if value.lower() in ('off', 'снять'):
            self.db.set_pl_lock(u, None)
            self.notify(L(lang, f'Замок PL снят у карты {self.label(u)}: бот снова подбирает PL сам.', f'PL lock removed from card {self.label(u)}: the bot picks PL on its own again.'))
            return
        try:
            w = int(value)
        except ValueError:
            self.notify(L(lang, f'/pl: ожидается число ватт или off, получено {value!r}', f'/pl: expected a wattage number or off, got {value!r}'))
            return
        if not lo <= w <= hi:
            self.notify(L(lang, f'/pl: {w} Вт вне допустимого диапазона карты {self.label(u)}: {lo}..{hi} Вт', f"/pl: {w} W is outside card {self.label(u)}'s allowed range: {lo}..{hi} W"))
            return
        self.db.set_pl_lock(u, w)
        problems = self.psu_problems()
        self.apply_safe(u)
        self.notify(L(lang, f'PL карты {self.label(u)} заблокирован на {w} Вт: бот его не меняет. Пресеты с другим PL будут перепроверены.' + ('' if not problems else ' ВНИМАНИЕ: ' + '; '.join(problems)), f"PL for card {self.label(u)} is locked at {w} W: the bot won't change it. Presets with a different PL will be re-verified." + ('' if not problems else ' WARNING: ' + '; '.join(problems))))

    def cmd_update(self, mode: str='') -> None:
        from . import selfupdate as su
        lang = self.lang
        if mode != 'rollback' and mode != 'force' and (self.pending or self.bg_progress or self.measuring):
            self.notify(L(lang, 'Обновление отложено: идёт замер или двухчасовая проверка, перезапуск прервал бы её. Подождите или /update force.', 'Update postponed: a measurement or two-hour verification is running, a restart would interrupt it. Wait, or use /update force.'))
            return
        try:
            if mode == 'rollback':
                msg = su.rollback(su.workdir_of_code(), lang)
            else:
                data, sig = su.fetch_signed(self.cfg.update_url, token=self.cfg.update_token, lang=lang)
                msg = su.install(su.workdir_of_code(), data, force=mode == 'force', lang=lang, sig=sig)
        except su.UpdateError as e:
            self.notify(L(lang, f'Обновление не выполнено: {e}', f'Update failed: {e}'))
            return
        self.notify(msg)
        if msg.startswith(('Уже установлена', 'This version is already installed')):
            return
        self.notify(L(lang, 'Перезапускаю бота (пауза ~1 минута при старте).', 'Restarting the bot (about a 1-minute pause on startup).'))
        self._restart_service()

    def _restart_service(self) -> None:
        import subprocess
        try:
            subprocess.Popen(['sh', '-c', 'sleep 3; systemctl restart ocbot'], start_new_session=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except OSError as e:
            self.notify(L(self.lang, f'Не удалось перезапустить службу: {e}. Перезапустите вручную: python3 -m ocbot --service restart', f'Could not restart the service: {e}. Restart it manually: python3 -m ocbot --service restart'))

    def cmd_uninstall(self, keep_data: bool) -> None:
        from . import selfupdate as su
        lang = self.lang
        self.notify(L(lang, 'Удаляю бота с этого рига' + (' (конфиги, база и лог останутся)' if keep_data else '') + '…', 'Removing the bot from this rig' + (' (configs, database and log will stay)' if keep_data else '') + '…'))
        import shlex
        import subprocess
        workdir = su.workdir_of_code()
        cmd = f'sleep 3; cd {shlex.quote(workdir)} && python3 -m ocbot --uninstall --yes' + (' --keep-data' if keep_data else '')
        try:
            subprocess.Popen(['sh', '-c', cmd], start_new_session=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except OSError as e:
            self.notify(L(lang, f'Не удалось запустить удаление: {e}. Выполните на риге: python3 -m ocbot --uninstall --yes' + (' --keep-data' if keep_data else ''), f'Could not start the removal: {e}. Run it on the rig: python3 -m ocbot --uninstall --yes' + (' --keep-data' if keep_data else '')))

    @staticmethod
    def _key_commands(item):
        if item and item[0] == 'pl' and (len(item) > 1):
            return ('pl', str(item[1]))
        if item and item[0] in ('psu_set', 'optimize_gain'):
            return (item[0],)
        return None

    @staticmethod
    def _key_mode(item):
        return ('mode', item[3] if len(item) > 3 else None)

    @staticmethod
    def _key_params(item):
        return ('params', str(item[0]))

    def _pqueue(self, key: str):
        from .state import PersistentQueue
        if not (isinstance(getattr(self.state, 'data', None), dict) and hasattr(self.state, 'save')):
            return queue.Queue()
        fn = {'q_commands': self._key_commands, 'q_mode': self._key_mode, 'q_params': self._key_params}.get(key)
        stale = (lambda it: bool(it) and it[0] in ('stop', 'safe')) if key == 'q_commands' else lambda it: False
        return PersistentQueue(self.state, key, ttl=self.cfg.queue_ttl_s, cap=self.cfg.queue_cap, key_fn=fn or (lambda it: None), no_restore=stale)

    def _queues(self) -> list:
        return [('', self.commands), ('/mode ', self.mode_requests), ('/params ', self.params_requests), ('/restore ', self.restore_requests)]

    @staticmethod
    def _qtext(prefix: str, item) -> str:
        parts = [str(x) for x in (item if isinstance(item, (tuple, list)) else (item,)) if x is not None]
        return (prefix or '/') + ' '.join(parts)

    def queue_report(self) -> str:
        lang = self.lang
        rows = []
        for prefix, q in self._queues():
            for item, age in q.snapshot() if hasattr(q, 'snapshot') else [(x, 0.0) for x in list(q.queue)]:
                rows.append(L(lang, f'{self._qtext(prefix, item)} ({self._dur(age)} назад)', f'{self._qtext(prefix, item)} ({self._dur(age, lang)} ago)'))
        if lang == 'en':
            return f'In queue: {len(rows)}\n' + '\n'.join(rows) + '\n\nClear it: /queue clear' if rows else 'Queue is empty'
        return 'В очереди: ' + str(len(rows)) + '\n' + '\n'.join(rows) + '\n\nОчистить: /queue clear' if rows else 'Очередь пуста'

    def queue_clear(self) -> int:
        return sum((q.clear() for _, q in self._queues() if hasattr(q, 'clear')))

    def set_phase(self, text: str) -> None:
        if self.phase[0] != text:
            self.phase = (text, self.clock.now())
        self._touch_beat()

    def _hash_watch(self) -> None:
        cfg, now = (self.cfg, self.clock.now())
        fn = getattr(self.backend, 'total_hashrate', None)
        if not cfg.zero_hash_watch or self.halted or fn is None or (now < self._zero_hold_until):
            self._zero_since = None
            return
        if now - self._zero_checked < 30:
            return
        self._zero_checked = now
        try:
            total = fn()
        except Exception:
            total = None
        if total is None or total > 0:
            self._zero_since = None
            self._zero_deadline = None
            self._miner_restart_done = False
            return
        if self._mining_by_power():
            if now - self._stats_lie_warned >= 3600:
                self._stats_lie_warned = now
                self.notify(L(self.lang, 'Статистика майнера показывает нулевой хешрейт, но карты под нагрузкой — показания ошибочны, перезагрузки не будет. Попробую сам найти живой интерфейс статистики; проверьте /status.', 'Miner stats show zero hashrate, but the cards are under load — the readings are wrong, no reboot will follow. I will try to find a live stats endpoint myself; check /status.'))
            self._retry_stats_api()
            return
        if self._zero_deadline is not None:
            if now >= self._zero_deadline:
                self._zero_deadline = None
                self._zero_since = None
                self._zero_hold_until = now + 600
                self.reboot(L(self.lang, 'хешрейт на всех картах нулевой, перезапуск майнера не помог', 'hashrate is zero on all cards, the miner restart did not help'), force=True)
            return
        if self._zero_since is None:
            self._zero_since = now
        boot = getattr(self.backend, 'boot_time', lambda: None)()
        start = max(self._zero_since, (boot or 0.0) + cfg.zero_hash_boot_grace_s)
        if now - start < cfg.zero_hash_minutes * 60:
            return
        self._zero_since = None
        if self._try_miner_restart(now):
            self._zero_deadline = now + cfg.zero_hash_restart_grace_s
            return
        self._zero_hold_until = now + 600
        self.reboot(L(self.lang, f'хешрейт на всех картах нулевой уже {cfg.zero_hash_minutes} мин, майнер сам не восстановился', f"hashrate has been zero on all cards for {cfg.zero_hash_minutes} min, the miner didn't recover on its own"), force=True)

    def _mining_by_power(self) -> bool:
        try:
            powers = self.backend.power_draws()
        except Exception:
            return False
        vals = [w for w in powers.values() if w]
        if not vals:
            return False
        loaded = sum((1 for w in vals if w >= 50))
        return loaded >= max(1, len(vals) // 2)

    def _retry_stats_api(self) -> None:
        try:
            from .setup import detect_miner_api, detect_stats_file
            api_url, _, _ = detect_miner_api()
            stats_file = '' if api_url else detect_stats_file()
        except Exception:
            return
        if api_url:
            self._set_stats_api(api_url)
        elif stats_file:
            self._set_stats_source('file', stats_file)

    def _try_miner_restart(self, now: float) -> bool:
        if self._miner_restart_done:
            return False
        day = [t for t in self._miner_restarts if now - t < 86400]
        self._miner_restarts = day
        if len(day) >= 4:
            return False
        self._miner_restart_done = True
        self._miner_restarts.append(now)
        self.notify(L(self.lang, 'Майнер завис: перезапускаю майнер без перезагрузки рига', 'Miner hung: restarting the miner without rebooting the rig'))
        try:
            self.backend.miner('stop')
            self.clock.sleep(5)
            self.backend.miner('start')
        except Exception as e:
            log.warning('miner restart: %s', e)
        return True

    def _driver_error_watch(self, e: Exception, now: float) -> None:
        if not getattr(self.cfg, 'driver_error_minutes', 0):
            return
        text = str(e)
        if 'Unknown Error' not in text and 'Unable to determine the device handle' not in text:
            return
        if self._drv_err_since is None:
            self._drv_err_since = now
            self.notify(L(self.lang, f'Драйвер карты отвалился (nvidia-smi: Unknown Error). Если не восстановится за {self.cfg.driver_error_minutes} мин — перезагружу риг.', f'A GPU driver died (nvidia-smi: Unknown Error). If it does not recover within {self.cfg.driver_error_minutes} min, the rig will be rebooted.'))
            return
        if now - self._drv_err_since >= self.cfg.driver_error_minutes * 60:
            self._drv_err_since = None
            self._zero_hold_until = now + 600
            self.reboot(L(self.lang, 'драйвер карт недоступен дольше лимита (nvidia-smi: Unknown Error)', 'GPU driver unavailable for too long (nvidia-smi: Unknown Error)'), force=True)

    def _wait(self, seconds: float) -> None:
        left = seconds
        self._touch_beat()
        while left > 0:
            self._touch_beat()
            self._hash_watch()
            if self.stop_flag.is_set():
                raise Stopped()
            step = min(left, 10)
            self.clock.sleep(step)
            left -= step
            self._psu_watch()
            self._poll_control()
        if self.stop_flag.is_set():
            raise Stopped()

    @property
    def trial(self) -> bool:
        return bool(getattr(getattr(self, 'lic', None), 'trial', False))

    @property
    def lang(self) -> str:
        return self.state.data.get('lang') or self.state.data.get('lang_detected') or 'ru'

    def not_found_msg(self, target: str) -> str:
        return L(self.lang, f'Карта «{target}» не найдена, смотрите /status', f'Card «{target}» not found, see /status')

    def _trial_block(self, what: str, what_en: str=None) -> bool:
        if not self.trial:
            return False
        site = getattr(self.cfg, 'site_url', '')
        self.notify(L(self.lang, f'{what}: недоступно на пробном периоде (работает режим «Компромисс»). Полная версия с ключом' + (f': {site}' if site else '.') + ' После покупки активируйте его командой /activate <ключ>.', f'{what_en or what}: not available during the trial ("Compromise" mode is active). Full version with a key' + (f': {site}' if site else '.') + ' After buying it, activate it with /activate <key>.'))
        return True

    def _sync_trial(self) -> None:
        cfg, on = (self.cfg, getattr(self, '_trial_saved', None) is not None)
        if self.trial and (not on):
            self._trial_saved = (cfg.objective, cfg.eff_tolerance)
            cfg.objective = 'compromise'
            if self._searcher is not None:
                self._searcher.objective = 'compromise'
            self.notify(L(self.lang, 'Пробный период: бот работает в режиме «Компромисс», доступны основные команды. Полная версия с ключом' + (f': {cfg.site_url}' if getattr(cfg, 'site_url', '') else '.') + ' После покупки активируйте его командой /activate <ключ>.', 'Trial period: the bot runs in "Compromise" mode, basic commands are available. Full version with a key' + (f': {cfg.site_url}' if getattr(cfg, 'site_url', '') else '.') + ' After buying it, activate it with /activate <key>.'))
        elif not self.trial and on:
            cfg.objective, cfg.eff_tolerance = self._trial_saved
            self._trial_saved = None
            if self._searcher is not None and self._searcher_uuid not in (self.state.data.get('card_modes') or {}):
                self._searcher.objective, self._searcher.tolerance = (cfg.objective, cfg.eff_tolerance)

    def obj_of(self, uuid: str) -> tuple:
        if self.trial:
            return ('compromise', self.cfg.eff_tolerance)
        m = (self.state.data.get('card_modes') or {}).get(uuid)
        if m:
            return (m['objective'], float(m.get('tolerance', self.cfg.eff_tolerance)))
        return (self.cfg.objective, self.cfg.eff_tolerance)

    def _hash_cards(self, uuids) -> list:
        return [u for u in uuids if self.obj_of(u)[0] == 'hashrate']
    OBJECTIVE_TEXT = {'efficiency': 'максимум хешрейта на ватт (обычно при пониженном PL)', 'compromise': 'максимум хешрейта при эффективности не хуже лучшей на {tol:.0%}', 'hashrate': 'максимум хешрейта в пределах потолка PL, эффективность не учитывается'}
    OBJECTIVE_TEXT_EN = {'efficiency': 'maximum hashrate per watt (usually at a lower PL)', 'compromise': 'maximum hashrate while efficiency stays within {tol:.0%} of the best', 'hashrate': 'maximum hashrate within the PL ceiling, efficiency not considered'}

    def mode_report(self) -> str:
        c, lang = (self.cfg, self.lang)
        fr = sorted(self.frozen_notified)
        if lang == 'en':
            return 'Tuning target: ' + c.objective + ': ' + self.OBJECTIVE_TEXT_EN[c.objective].format(tol=c.eff_tolerance) + (f". Axes with no effect on hashrate are frozen: {', '.join(fr)}" if fr else '') + self._card_modes_text() + ".\nChange for the whole rig: /mode efficiency | compromise [tolerance %] | hashrate; for one card: /mode 3 hashrate (slot number, label, or end of UUID), return a card to the rig-wide target: /mode 3 rig. A trailing `keep` leaves ready presets as they are (otherwise they're re-tuned from the accumulated history)."
        return f'Цель поиска: {c.objective}: ' + self.OBJECTIVE_TEXT[c.objective].format(tol=c.eff_tolerance) + (f". Оси, не влияющие на хешрейт, заморожены: {', '.join(fr)}" if fr else '') + self._card_modes_text() + '.\nСменить для всего рига: /mode efficiency | compromise [допуск %] | hashrate; для одной карты: /mode 3 hashrate (номер слота, метка или конец UUID), вернуть карту под общую цель: /mode 3 rig. В конце `keep` оставит готовые пресеты как есть (иначе подбираются заново по накопленной истории).'

    def _card_modes_text(self) -> str:
        cm = self.state.data.get('card_modes') or {}
        lang = self.lang
        if lang == 'en':
            rows = [f"{self.label(u)}: {m['objective']}" + (f" (tolerance {float(m['tolerance']):.0%})" if m['objective'] == 'compromise' else '') for u, m in cm.items() if u in self.gpus]
            return '. Cards with their own target: ' + '; '.join(rows) if rows else ''
        rows = [f"{self.label(u)}: {m['objective']}" + (f" (допуск {float(m['tolerance']):.0%})" if m['objective'] == 'compromise' else '') for u, m in cm.items() if u in self.gpus]
        return '. Свои цели у карт: ' + '; '.join(rows) if rows else ''

    def request_mode(self, objective: str, tolerance=None, retune: bool=True) -> None:
        self.mode_requests.put((objective, tolerance, retune))

    def request_card_mode(self, target: str, objective, tolerance=None, retune: bool=True) -> None:
        self.mode_requests.put((objective, tolerance, retune, target))

    def apply_card_mode(self, target: str, objective, tolerance=None, retune: bool=True) -> None:
        if self._trial_block('Смена режима', 'Mode change'):
            return
        u = self.resolve(target)
        if not u:
            self.notify(self.not_found_msg(target))
            return
        cm = self.state.data.setdefault('card_modes', {})
        old = self.obj_of(u)
        if objective is None:
            cm.pop(u, None)
        else:
            if objective not in ('efficiency', 'compromise', 'hashrate'):
                self.notify(L(self.lang, f'Цель поиска «{objective}» неизвестна: efficiency, compromise или hashrate', f'Tuning target "{objective}" is unknown: efficiency, compromise or hashrate'))
                return
            try:
                tol = self.cfg.eff_tolerance if tolerance is None else float(tolerance)
            except (TypeError, ValueError):
                tol = -1.0
            if not 0.0 < tol <= 0.5:
                self.notify(L(self.lang, 'Допуск эффективности должен быть от 0 до 50%', 'Efficiency tolerance must be between 0 and 50%'))
                return
            cm[u] = {'objective': objective, 'tolerance': tol}
        new = self.obj_of(u)
        self.state.save()
        if new == old:
            self.notify(L(self.lang, f'Карта {self.label(u)}: цель уже такая ({new[0]}).', f'Card {self.label(u)}: target is already that ({new[0]}).'))
            return
        if self._searcher is not None and self._searcher_uuid == u:
            self._searcher.objective, self._searcher.tolerance = new
        if retune:
            self.restored.discard(u)
            (self.state.data.get('alloc') or {}).pop(u, None)
            self.db.x("update profiles set status='outdated' where gpu_uuid=? and algo=? and miner=? and status in ('verified','imported')", (u, self.cfg.algo, self.cfg.miner))
            self.pending.pop(u, None)
            self.pending_gen.pop(u, None)
            self.bg_progress.pop(u, None)
            self.state.save()
        self.notify(L(self.lang, f'Карта {self.label(u)}: цель {new[0]}' + (f' (допуск {new[1]:.0%})' if new[0] == 'compromise' else '') + (' (общая цель рига)' if objective is None else '') + '. ' + ('Подбор этой карты начнётся заново по накопленной истории (прежний пресет остаётся в базе как устаревший).' if retune else 'Готовый пресет не тронут, цель действует для следующего поиска.'), f'Card {self.label(u)}: target {new[0]}' + (f' (tolerance {new[1]:.0%})' if new[0] == 'compromise' else '') + (" (the rig's shared target)" if objective is None else '') + '. ' + ("This card's search will restart using the accumulated history (the previous preset stays in the database as outdated)." if retune else 'The current preset is left untouched, the target applies to the next search.')))

    def request_restore(self, target: str='all') -> None:
        self.restore_requests.put(target or 'all')

    def apply_restore(self, target: str='all') -> None:
        cfg = self.cfg
        if target in (None, '', 'all'):
            uuids = list(self.gpus)
        else:
            u = self.resolve(target)
            if not u:
                self.notify(self.not_found_msg(target))
                return
            uuids = [u]
        self.retune_all = False
        al = self.state.data.get('alloc') or {}
        for u in uuids:
            al.pop(u, None)
        done = []
        for u in uuids:
            prev = self.db.previous_profile(u, cfg.algo, cfg.miner, cfg.miner_version)
            if not prev:
                self.notify(L(self.lang, f'Карта {self.label(u)}: прежнего проверенного пресета нет, возвращать нечего.', f'Card {self.label(u)}: no previous verified preset to restore.'))
                continue
            cur = self.db.get_profile(u, cfg.algo, cfg.miner, cfg.miner_version, 'verified')
            self.db.restore_profile(prev['id'])
            self.db.log_change(u, cfg.algo, cfg.miner, {'core': cur['core_offset'], 'mem': cur['mem_offset'], 'pl': cur['power_limit']} if cur else None, {'core': prev['core_offset'], 'mem': prev['mem_offset'], 'pl': prev['power_limit']}, 'возврат прежнего пресета командой')
            self.pending.pop(u, None)
            self.bg_progress.pop(u, None)
            self.rounds.pop(u, None)
            self.paused.discard(u)
            self.restored.add(u)
            self.recheck_needed.add(u)
            done.append(f"{self.label(u)}: core {prev['core_offset']}, mem {prev['mem_offset']}, PL {prev['power_limit']}")
        if done:
            self.state.save()
            self.notify(L(self.lang, 'Возвращён прежний пресет без нового подбора (короткая перепроверка перед работой):\n' + '\n'.join(done), 'Restored the previous preset without a new search (a short re-check runs before it works):\n' + '\n'.join(done)))

    def _poll_control(self) -> None:
        path = self.cfg.control_path
        if path and os.path.exists(path):
            try:
                with open(path, encoding='utf-8') as f:
                    d = json.load(f)
                if d.get('objective'):
                    if d.get('card'):
                        self.mode_requests.put((None if d['objective'] == 'rig' else d['objective'], d.get('tolerance'), bool(d.get('retune', True)), str(d['card'])))
                    else:
                        self.mode_requests.put((d.get('objective'), d.get('tolerance'), bool(d.get('retune', True))))
                if d.get('restore'):
                    self.restore_requests.put(str(d['restore']))
                if d.get('balance'):
                    self.commands.put(('balance', 'deep') if d['balance'] == 'deep' else ('balance',))
                if d.get('optimize'):
                    self.commands.put(('optimize', str(d['optimize']), d.get('gain')))
                if d.get('opt_gain') is not None:
                    self.commands.put(('optimize_gain', d['opt_gain']))
                if d.get('params'):
                    self.params_requests.put((str(d['params'][0]), d['params'][1]))
            except (OSError, ValueError) as e:
                self.notify(L(self.lang, f'Файл управления {path} не разобран: {e}', f'Could not parse control file {path}: {e}'))
            try:
                os.remove(path)
            except OSError:
                pass
        while True:
            try:
                target, n = self.params_requests.get_nowait()
            except queue.Empty:
                break
            self.cmd_params(target, n)
        while True:
            try:
                req = self.mode_requests.get_nowait()
            except queue.Empty:
                break
            if len(req) > 3:
                self.apply_card_mode(req[3], req[0], req[1], req[2])
            else:
                self.apply_mode(*req)
        while True:
            try:
                target = self.restore_requests.get_nowait()
            except queue.Empty:
                return
            self.apply_restore(target)

    def apply_mode(self, objective, tolerance=None, retune: bool=True) -> None:
        if self._trial_block('Смена режима', 'Mode change'):
            return
        cfg, lang = (self.cfg, self.lang)
        if objective not in ('efficiency', 'compromise', 'hashrate'):
            self.notify(L(lang, f'Цель поиска «{objective}» неизвестна: efficiency, compromise или hashrate', f'Tuning target "{objective}" is unknown: efficiency, compromise or hashrate'))
            return
        try:
            tol = cfg.eff_tolerance if tolerance is None else float(tolerance)
        except (TypeError, ValueError):
            tol = -1.0
        if not 0.0 < tol <= 0.5:
            self.notify(L(lang, 'Допуск эффективности должен быть от 0 до 50%', 'Efficiency tolerance must be between 0 and 50%'))
            return
        changed = (objective, tol) != (cfg.objective, cfg.eff_tolerance)
        cfg.objective, cfg.eff_tolerance = (objective, tol)
        self.state.data['mode'] = {'objective': objective, 'tolerance': tol}
        self.state.save()
        if self._searcher is not None and self._searcher_uuid not in (self.state.data.get('card_modes') or {}):
            self._searcher.objective, self._searcher.tolerance = (objective, tol)
        if not changed:
            self.notify(L(lang, 'Цель поиска уже такая: ', 'Tuning target is already this: ') + self.mode_report())
            return
        self.mode_gen += 1
        self.retune_all = retune
        self.notify(L(lang, 'Цель поиска изменена. ' + self.mode_report().split('\n')[0] + (' Карты с готовыми пресетами подбираются заново по накопленной истории (прошлые пресеты остаются в базе как устаревшие).' if retune else ' Готовые пресеты не тронуты, новая цель действует для следующих поисков.'), 'Tuning target changed. ' + self.mode_report().split('\n')[0] + (' Cards with ready presets are re-tuned from the accumulated history (past presets stay in the database as outdated).' if retune else ' Ready presets are untouched, the new target applies to future searches.')))

    def reboot(self, reason: str, tuning: bool=False, force: bool=False) -> bool:
        now, kind = (self.clock.now(), 'tuning' if tuning else 'fault')
        limit = self.cfg.max_tuning_reboots_per_day if tuning else self.cfg.max_reboots_per_day
        lang = self.lang
        if self.state.reboots_24h(now, kind) >= limit:
            self.halted = True
            self.notify(L(lang, f"Лимит перезагрузок за сутки ({limit}, {('подбор' if tuning else 'аварийные')}) исчерпан, автоматика остановлена. Причина последней: {reason}. Проверьте риг (питание, райзеры).", f"Daily reboot limit ({limit}, {('tuning' if tuning else 'emergency')}) reached, automation stopped. Reason for the last one: {reason}. Check the rig (power, risers)."))
            return False
        self.state.record_reboot(now, kind, reason)
        self.notify(L(lang, f'Перезагрузка рига {self.cfg.rig_name}: {reason}', f'Rebooting rig {self.cfg.rig_name}: {reason}'))
        for h in logging.getLogger().handlers + logging.getLogger('ocbot').handlers:
            try:
                h.flush()
            except Exception:
                pass
        self.backend.reboot(force=force if force is not None else not tuning)
        return True

    def _delay_now(self, minutes: int) -> None:
        self.set_phase(L(self.lang, f'пауза {minutes} мин на безопасном профиле перед запуском майнера', f'{minutes}min pause on the safe profile before starting the miner'))
        self.notify(L(self.lang, f'Пауза {minutes} мин на безопасном профиле перед запуском майнера.', f'{minutes}min pause on the safe profile before starting the miner.'))
        self._zero_hold_until = self.clock.now() + minutes * 60 + 300
        self.backend.miner('stop')
        self.clock.sleep(minutes * 60)
        self.backend.miner('start')

    def apply_pending_delay(self) -> None:
        minutes = self.state.pop_delay()
        if minutes:
            self._delay_now(minutes)

    def mark_card(self, uuid: str, status: str, reason: str, halt: bool=True) -> None:
        lang = self.lang
        self.db.set_gpu_status(uuid, status, reason)
        word = L(lang, {'faulty': 'неисправной', 'suspect': 'подозрительной (сбоящей)'}.get(status, status), status)
        if not halt:
            self.notify(L(lang, f'Карта {self.label(uuid)} помечена как {word}: {reason}. Подбор для неё продолжается с консервативной точки, пресет будет мягче типичного для модели.', f'Card {self.label(uuid)} marked as {status}: {reason}. Tuning continues for it from a conservative point, the preset will be milder than typical for the model.'))
            return
        self.paused.add(uuid)
        self.pending.pop(uuid, None)
        self.notify(L(lang, f'Карта {self.label(uuid)} помечена как {word}: {reason}. Автоматика для неё остановлена (/tune {self.label(uuid)} запустит подбор заново).', f'Card {self.label(uuid)} marked as {status}: {reason}. Automation stopped for it (/tune {self.label(uuid)} will start tuning again).'))

    def escalate(self, uuid: str, reason: str, stock: bool, short: bool, do_reboot: bool=True) -> bool:
        lang = self.lang
        fast_attempts = 1 if short else self.cfg.fast_reboots
        act = escalation.next_action(self.db, uuid, fast_attempts, allow_delayed=not short)
        row = self.db.escalation(uuid)
        if act is Action.REBOOT_NOW:
            self.notify(L(lang, f"Карта {self.label(uuid)}: отвал ({reason}), перезагрузка {row['reboot_attempts']} из {fast_attempts}", f"Card {self.label(uuid)}: crash ({reason}), reboot {row['reboot_attempts']} of {fast_attempts}"))
            hard = row['reboot_attempts'] >= fast_attempts
            return bool(do_reboot) and (not self.reboot(L(lang, f'отвал карты {self.label(uuid)}: {reason}', f'card {self.label(uuid)} crashed: {reason}'), force=hard))
        if act is Action.REBOOT_DELAYED:
            self.notify(L(lang, f'Карта {self.label(uuid)}: отвал ({reason}), перезагрузка с задержкой {self.cfg.delay_minutes} мин', f'Card {self.label(uuid)}: crash ({reason}), reboot delayed by {self.cfg.delay_minutes} min'))
            if do_reboot:
                self.state.set_delay(self.cfg.delay_minutes)
                if self.reboot(L(lang, f'отвал карты {self.label(uuid)}: {reason}', f'card {self.label(uuid)} crashed: {reason}'), force=True):
                    self.apply_pending_delay()
                    return False
                self.state.pop_delay()
                return True
            else:
                self._delay_now(self.cfg.delay_minutes)
            return False
        halt = stock or short
        self.mark_card(uuid, 'faulty' if stock else 'suspect', L(lang, f'{reason}; лесенка перезагрузок исчерпана', f'{reason}; reboot escalation exhausted'), halt=halt)
        return halt

    def _driver_alive(self) -> bool:
        try:
            seen = {g.uuid for g in self.backend.list_gpus()}
        except BackendError:
            return False
        return all((u in seen for u in self.gpus))

    def after_point_crash(self, uuid: str, p: Point, cause: str, do_reboot: bool=True) -> bool:
        if uuid not in self.lock_override and self._want_lock(uuid, p) and self._drop_lock(uuid, cause):
            return self.escalate(uuid, cause, stock=False, short=cause == 'bus_lost', do_reboot=do_reboot)
        safe = self.safe_point(uuid)
        mild = p.core <= safe.core and p.mem <= safe.mem and (p.pl >= safe.pl)
        if cause == 'bus_lost':
            return self.escalate(uuid, cause, stock=mild, short=True, do_reboot=do_reboot)
        if mild:
            return self.escalate(uuid, cause, stock=p.core == 0 and p.mem == 0, short=False, do_reboot=do_reboot)
        self.apply_safe(uuid)
        if do_reboot and self._driver_alive():
            log.info('карта %s: граница core %s mem %s PL %s, драйвер жив — без перезагрузки', uuid, p.core, p.mem, p.pl)
            self.notify(L(self.lang, f'Карта {self.label(uuid)}: граница разгона core {p.core}, mem {p.mem}, PL {p.pl}. Драйвер жив — обошлись без перезагрузки, продолжаю подбор ниже.', f'Card {self.label(uuid)}: OC boundary core {p.core}, mem {p.mem}, PL {p.pl}. The driver is alive — no reboot needed, continuing the search lower.'))
            return False
        if do_reboot:
            return not self.reboot(L(self.lang, f'граница разгона у карты {self.label(uuid)}: core {p.core}, mem {p.mem}, PL {p.pl}', f'overclock boundary for card {self.label(uuid)}: core {p.core}, mem {p.mem}, PL {p.pl}'), tuning=True)
        return False

    def _power_suspect_before(self, r) -> bool:
        return self.db.one("select 1 from runs where gpu_uuid=? and algo=? and miner=? and miner_version=? and core_offset=? and mem_offset=? and power_limit=? and crash_cause='power' and id!=? limit 1", (r['gpu_uuid'], r['algo'], r['miner'], r['miner_version'], r['core_offset'], r['mem_offset'], r['power_limit'], r['id'])) is not None

    def recover_unfinished(self) -> None:
        runs = self.db.unfinished_runs(self.cfg.rig_name)
        if not runs:
            return
        boot = getattr(self.backend, 'boot_time', lambda: None)()
        if boot:
            stopped = [r for r in runs if iso_ts(r['started_at']) > boot + 60]
            stale = [r for r in runs if iso_ts(r['started_at']) < boot - 10800 and r not in stopped]
            for r in stale:
                self.db.finish_run(r['id'], note='незавершённый замер устарел')
            runs = [r for r in runs if r not in stale]
            for r in stopped:
                self.db.finish_run(r['id'], note='прервано перезапуском бота')
            if stopped:
                log.info('перезапуск бота: прервано замеров %s, отвалом не считаются', len(stopped))
            runs = [r for r in runs if r['id'] not in {x['id'] for x in stopped}]
            if not runs:
                return
        since = min((iso_ts(r['started_at']) for r in runs))
        events = self.read_xid_log(since)
        rig_uuids = {r['uuid'] for r in self.db.rig_gpus(self.cfg.rig_name)}
        involved = {r['gpu_uuid'] for r in runs}
        if len(involved) > 1 and len(rig_uuids) > 1 and (involved >= rig_uuids):
            for r in runs:
                self.db.finish_run(r['id'], status='crash', crash_cause='rig_wide', note='отвал всех карт рига сразу')
                if r['kind'] in ('verify', 'recheck'):
                    self.state.add_solo(r['gpu_uuid'])
            self.db.log_change(next(iter(involved)), self.cfg.algo, self.cfg.miner, None, None, 'пресеты не менялись, причина: общий отвал рига')
            self.notify(L(self.lang, f'Отвалились все карты рига {self.cfg.rig_name} сразу. Вероятная причина: питание или система. Пресеты не менялись.', f'All cards of rig {self.cfg.rig_name} crashed at once. Likely cause: power or the system. Presets were not changed.'))
            return
        if len(involved) > 1:
            for r in runs:
                self.db.finish_run(r['id'], status='suspect', note='неоднозначно: общий отвал при групповой проверке')
                self.state.add_solo(r['gpu_uuid'])
            self.notify(L(self.lang, 'Общий отвал во время групповой проверки: виновную карту определить нельзя, проверю карты по одной. Границы не менялись.', "A joint crash during a group verification: can't tell which card is at fault, will check the cards one at a time. Boundaries were not changed."))
            return
        r = runs[0]
        u = r['gpu_uuid']
        g = self.gpus.get(u)
        codes = [c for ts, b, c in events if g and b == bus_key(g.bus_id)]
        cause = self._cause_from_codes(g is not None, codes)
        p = Point(r['core_offset'], r['mem_offset'], r['power_limit'], r['fan'])
        if str(r['note'] or '').startswith('lockoff'):
            self.db.finish_run(r['id'], status='crash', crash_cause=cause, note='обнаружено после перезагрузки')
            try:
                b = int(str(r['note'])[7:])
            except ValueError:
                b = None
            e = self._lock_entry(u)
            if e is not None and b:
                e['lift_bad'] = b if e.get('lift_bad') is None else min(int(e['lift_bad']), b)
            self.state.data.get('lock_stage', {}).pop(u, None)
            self.state.save()
            self.notify(L(self.lang, f'Карта {self.label(u)}: риг перезагрузился во время подъёма оффсета при фиксации (+{b} МГц). Это граница подъёма, откачусь на {self.cfg.lock_lift_margin} МГц; пресет и фиксация не тронуты.', f'Card {self.label(u)}: the rig rebooted while raising the lock offset (+{b} MHz). This is the lift boundary, backing off by {self.cfg.lock_lift_margin} MHz; the preset and lock are untouched.'))
            if g:
                self.escalate(u, cause, stock=False, short=True, do_reboot=False)
            return
        if str(r['note'] or '').startswith('lock'):
            self.db.finish_run(r['id'], status='crash', crash_cause=cause, note='обнаружено после перезагрузки')
            st = (self.state.data.get('lock_stage') or {}).pop(u, None) or {}
            self._lock_set(u, None, None, f"карта упала при пробе фиксации ядро {st.get('core')}, память {st.get('mem')}")
            self.notify(L(self.lang, f"Карта {self.label(u)}: риг перезагрузился во время пробы фиксации частот (ядро {st.get('core')}, память {st.get('mem')}). Пресет не тронут, фиксация для этой карты отключена (повторить: /params {(self.gpus[u].slot if g else u)} 4).", f"Card {self.label(u)}: the rig rebooted while probing the clock lock (core {st.get('core')}, mem {st.get('mem')}). The preset is untouched, the lock is disabled for this card (retry: /params {(self.gpus[u].slot if g else u)} 4)."))
            if g:
                self.escalate(u, cause, stock=False, short=True, do_reboot=False)
            return
        if cause == 'unknown' and (not self._power_suspect_before(r)):
            self.db.finish_run(r['id'], status='crash', crash_cause='power', note='возможно отключение питания: повторю замер, границу не ставлю')
            self.notify(L(self.lang, f'Карта {self.label(u)}: после перезагрузки нет следов сбоя карты (Xid) на точке core {p.core}, mem {p.mem}, PL {p.pl}. Возможно, отключали питание: границу не ставлю, замер повторю. Если эта же точка упадёт снова без Xid, она станет границей.', f"Card {self.label(u)}: after the reboot there's no trace of a card fault (Xid) at point core {p.core}, mem {p.mem}, PL {p.pl}. Power may have been cut: not setting a boundary, re-running the measurement. If this same point crashes again without an Xid, it becomes the boundary."))
            return
        self.db.finish_run(r['id'], status='crash', crash_cause=cause, note='обнаружено после перезагрузки')
        if g:
            self.after_point_crash(u, p, cause, do_reboot=False)
        else:
            self.escalate(u, cause, stock=False, short=True, do_reboot=False)

    def on_work_drop(self, g, code: int) -> None:
        cause = 'bus_lost' if code == 79 else 'aggressive_oc'
        if self._drop_lock(g.uuid, f'Xid {code}'):
            self.escalate(g.uuid, cause, stock=False, short=cause == 'bus_lost')
            return
        prof = self.db.get_profile(g.uuid, self.cfg.algo, self.cfg.miner, self.cfg.miner_version, 'verified')
        if prof:
            self.db.start_run(gpu_uuid=g.uuid, rig=self.cfg.rig_name, slot=g.slot, algo=self.cfg.algo, miner=self.cfg.miner, miner_version=self.cfg.miner_version, driver_version=self.driver, vbios=g.vbios, core_offset=prof['core_offset'], mem_offset=prof['mem_offset'], power_limit=prof['power_limit'], fan=prof['fan'], kind='work', started_at=utcnow(), finished_at=utcnow(), status='crash', crash_cause=cause, note=f'Xid {code} в работе')
            self.db.set_profile_status(prof['id'], 'outdated')
            self.db.log_change(g.uuid, self.cfg.algo, self.cfg.miner, {'core': prof['core_offset'], 'mem': prof['mem_offset'], 'pl': prof['power_limit']}, None, f'отвал в работе (Xid {code}), профиль отправлен на перепроверку')
        self.escalate(g.uuid, cause, stock=False, short=cause == 'bus_lost')

    def _hive_cuda_events(self) -> list:
        from . import hivelog
        path = getattr(self.cfg, 'hive_agent_log', '')
        out, self._cuda_pending = (list(self._cuda_pending), [])
        if path:
            st = dict(self.state.data.get('hive_log') or {})
            before = dict(st)
            out += hivelog.read_new(path, st)
            if st != before:
                self.state.data['hive_log'] = st
                try:
                    self.state.save()
                except Exception:
                    pass
        return out

    def _drain_hive_cuda(self, measured: set) -> None:
        for ev in self._hive_cuda_events():
            if bus_key(ev['bus']) not in measured:
                self._cuda_pending.append(ev)

    def _bump_cuda_soft(self, u: str) -> int:
        now = self.clock.now()
        d = self.state.data.setdefault('cuda_soft', {})
        row = d.get(u) or {'n': 0, 'ts': 0}
        if now - row.get('ts', 0) > self.cfg.stable_reset_s:
            row = {'n': 0, 'ts': 0}
        row['n'] += 1
        row['ts'] = now
        d[u] = row
        try:
            self.state.save()
        except Exception:
            pass
        return row['n']

    def on_cuda_failure(self, g, hive_gpu_idx=None) -> None:
        u = g.uuid
        if u in self.pending or self.boost == u:
            return
        if self._drop_lock(u, 'ошибка CUDA'):
            return
        if hive_gpu_idx is not None and int(hive_gpu_idx) != g.slot:
            log.warning('карта %s: Hive называет её GPU %s, у нас GPU %s (PCI %s) — числа не совпадают, используется PCI-адрес как истина', u, hive_gpu_idx, g.slot, g.bus_id)
        prof = self._verified(u)
        if prof:
            self.db.start_run(gpu_uuid=u, rig=self.cfg.rig_name, slot=g.slot, algo=self.cfg.algo, miner=self.cfg.miner, miner_version=self.cfg.miner_version, driver_version=self.driver, vbios=g.vbios, core_offset=prof['core_offset'], mem_offset=prof['mem_offset'], power_limit=prof['power_limit'], fan=prof['fan'], kind='work', started_at=utcnow(), finished_at=utcnow(), status='crash', crash_cause='aggressive_oc', note='ошибка CUDA в работе (майнер справился сам)')
            self.db.set_profile_status(prof['id'], 'outdated')
            self.db.log_change(u, self.cfg.algo, self.cfg.miner, {'core': prof['core_offset'], 'mem': prof['mem_offset'], 'pl': prof['power_limit']}, None, 'ошибка CUDA в работе, профиль отправлен на перепроверку')
        count = self._bump_cuda_soft(u)
        tol = max(0, int(getattr(self.cfg, 'cuda_soft_tolerance', 2)))
        bus = g.bus_id or ''
        if count <= tol:
            self.notify(L(self.lang, f'Карта {self.label(u)} (PCI {bus}): майнер сообщил ошибку CUDA ({count} из {tol}) и справился сам. Риг не перезагружаю. ' + ('Пресет отправлен на перепроверку, точка записана границей.' if prof else 'Пресета ещё нет.'), f'Card {self.label(u)} (PCI {bus}): the miner reported a CUDA error ({count} of {tol}) and recovered on its own. Not rebooting the rig. ' + ('The preset was sent for re-verification, the point was recorded as a boundary.' if prof else 'No preset yet.')))
            return
        self.escalate(u, L(self.lang, f'повторная ошибка CUDA по данным Hive (PCI {bus})', f'repeated CUDA error reported by Hive (PCI {bus})'), stock=False, short=True)

    def _driver_hang_check(self) -> bool:
        n = getattr(self.backend, 'hang_count', 0)
        lim = self.cfg.hang_reboot_after
        if not lim or n < lim:
            return False
        culprit_uuid = self._hang_culprit_uuid()
        culprit = f' ({self.label(culprit_uuid)})' if culprit_uuid else ''
        self.backend.hang_count = 0
        if isinstance(getattr(self.backend, 'hang_counts', None), dict):
            self.backend.hang_counts.clear()
        self._mark_hang_culprit(culprit_uuid)
        self.notify(L(self.lang, f'nvidia-smi не ответил {n} раза подряд{culprit}: драйвер завис. Перезагружаю риг.', f"nvidia-smi didn't respond {n} times in a row{culprit}: the driver hung. Rebooting the rig."))
        self.reboot(L(self.lang, f'драйвер завис (nvidia-smi не отвечает {n} раза подряд{culprit})', f'driver hung (nvidia-smi not responding {n} times in a row{culprit})'))
        return True

    def _hang_culprit_uuid(self) -> Optional[str]:
        counts = getattr(self.backend, 'hang_counts', None) or {}
        counts = {k: v for k, v in counts.items() if v}
        if not counts:
            return None
        key = max(counts, key=lambda k: counts[k])
        if key.startswith('u') and counts[key] >= 2:
            uuid = key[1:]
            return uuid if uuid in self.gpus else None
        if key.startswith('i') and counts[key] >= 2:
            slot = key[1:]
            for g in self.backend.list_gpus():
                if str(g.index) == slot:
                    return g.uuid
            return None
        if key == 'ALL' and len(self.gpus) == 1:
            return next(iter(self.gpus))
        return None

    def _mark_hang_culprit(self, culprit: Optional[str]=None) -> None:
        runs = self.db.unfinished_runs(self.cfg.rig_name)
        if len(runs) == 1 and runs[0]['kind'] == 'search':
            self.db.finish_run(runs[0]['id'], status='crash', crash_cause='aggressive_oc', note='драйвер завис во время замера: точка записана как граница')
            return
        if runs or not culprit or culprit not in self.gpus:
            return
        v = self._verified(culprit)
        if not v:
            return
        g = self.gpus[culprit]
        now = self.clock.now()
        self.db.start_run(gpu_uuid=culprit, rig=self.cfg.rig_name, slot=g.slot, algo=self.cfg.algo, miner=self.cfg.miner, miner_version=self.cfg.miner_version, driver_version=self.driver, vbios=g.vbios, core_offset=v['core_offset'], mem_offset=v['mem_offset'], power_limit=v['power_limit'], fan=v['fan'], kind='work', started_at=utcnow(), finished_at=utcnow(), status='crash', crash_cause='aggressive_oc', note='драйвер завис на проверенном пресете (nvidia-smi не отвечал)')
        blame = [t for t in (self.state.data.get('hang_blame') or {}).get(culprit, []) if now - t < 86400]
        blame.append(now)
        self.state.data.setdefault('hang_blame', {})[culprit] = blame
        self.state.save()
        if len(blame) < 2:
            self.notify(L(self.lang, f"Карта {self.label(culprit)}: драйвер завис на проверенном пресете (core {v['core_offset']}, mem {v['mem_offset']}, PL {v['power_limit']}). Пресет пока оставляю; если зависание повторится в течение суток — сниму статус проверенного и подберу точку заново.", f"Card {self.label(culprit)}: the driver hung on the verified preset (core {v['core_offset']}, mem {v['mem_offset']}, PL {v['power_limit']}). Keeping it for now; if the hang repeats within 24h, I will strip its verified status and re-tune."))
            return
        self.db.set_profile_status(v['id'], 'outdated')
        self.state.data['hang_blame'][culprit] = []
        self.state.save()
        self.db.log_change(culprit, self.cfg.algo, self.cfg.miner, {'core': v['core_offset'], 'mem': v['mem_offset'], 'pl': v['power_limit']}, None, 'пресет дважды за сутки завесил драйвер, verified снят')
        self.notify(L(self.lang, f"Карта {self.label(culprit)}: проверенный пресет (core {v['core_offset']}, mem {v['mem_offset']}, PL {v['power_limit']}) второй раз за сутки завесил драйвер. Снимаю статус проверенного: после перезагрузки карта стартует с безопасной точки и пройдёт подбор заново, эта точка записана как граница.", f"Card {self.label(culprit)}: the verified preset (core {v['core_offset']}, mem {v['mem_offset']}, PL {v['power_limit']}) hung the driver twice within 24h. Stripping its verified status: after the reboot the card starts from a safe point and re-tunes; this point is recorded as a boundary."))

    def monitor_once(self) -> None:
        if self._driver_hang_check():
            return
        self._psu_watch()
        self._cpu_watch()
        self._hash_watch()
        new = self.poll_xids()
        visible = {x.uuid for x in self.backend.list_gpus()}
        expected = set(self.gpus)
        missing = {u for u in expected - visible if u not in self.paused}
        if len(expected) > 1 and missing == expected - self.paused and missing:
            self.notify(L(self.lang, f'Все карты рига {self.cfg.rig_name} пропали сразу: питание или система. Пресеты не меняю.', f'All cards of rig {self.cfg.rig_name} disappeared at once: power or the system. Not changing presets.'))
            return
        for u in missing:
            self.escalate(u, L(self.lang, 'карта не видна в nvidia-smi', 'card not visible in nvidia-smi'), stock=False, short=True)
        for u in self.gpus:
            if u in self.paused or u in missing:
                continue
            try:
                self._raw_pl(u)
            except BackendError as e:
                self.escalate(u, L(self.lang, f'не удалось прочитать лимиты питания через nvidia-smi: {e}', f'could not read power limits via nvidia-smi: {e}'), stock=True, short=False)
        by_bus = {bus_key(g.bus_id): g for g in self.gpus.values()}
        self._xid_work_react(new, by_bus, missing)
        for ev in self._hive_cuda_events():
            g = by_bus.get(bus_key(ev['bus']))
            if g and g.uuid not in self.paused and (g.uuid not in missing):
                self.on_cuda_failure(g, hive_gpu_idx=ev.get('gpu'))
        self._reset_stable()

    def _reset_stable(self) -> None:
        now = self.clock.now()
        for u in self.gpus:
            row = self.db.escalation(u)
            if row['reboot_attempts'] or row['delayed_done']:
                last = row['last_event_ts']
                if last and now - iso_ts(last) > self.cfg.stable_reset_s and (u not in self.paused):
                    escalation.reset(self.db, u)

    def seed_point(self, g) -> tuple:
        cfg, row = (self.cfg, self.db.gpu(g.uuid))
        own = self.db.latest_profile_any(g.uuid, cfg.algo, cfg.miner, rig=cfg.rig_name)
        if own:
            return (self._clamp(g.uuid, Point(own['core_offset'], own['mem_offset'], own['power_limit'], cfg.fan)), f"own:{own['id']}")
        if row['status'] == 'suspect':
            return (self.start_point(g.uuid), 'conservative')
        med = self.db.median_seed(g.model, row['mem_vendor'], cfg.algo, cfg.miner, g.uuid, g.vbios)
        if med:
            p = shift_safe(self._clamp(g.uuid, Point(med['core'], med['mem'], med['pl'], cfg.fan)), self.steps, self.bounds(g.uuid), cfg.safety_steps)
            return (p, f"median(n={med['n']})")
        cat = catalog.seed(self.db, g.model, row['mem_vendor'], cfg.algo, cfg.miner)
        if cat:
            p = shift_safe(self._clamp(g.uuid, Point(cat['core'], cat['mem'], cat['pl'], cfg.fan)), self.steps, self.bounds(g.uuid), cfg.safety_steps)
            return (p, f"catalog(n={cat['n']})")
        return (self.start_point(g.uuid), 'conservative')

    def _clamp(self, uuid: str, p: Point) -> Point:
        b = self.bounds(uuid)
        c = lambda v, k: max(b[k][0], min(b[k][1], v))
        return Point(c(p.core, 'core'), c(p.mem, 'mem'), c(p.pl, 'pl'), p.fan)

    def _scout(self, g, seed, src, hard, soft, hs_hist):
        cfg = self.cfg
        mult = max(2, cfg.fast_step_mult)
        coarse = {k: v * mult for k, v in self.steps.items()}

        def ev(p: Point) -> EvalResult:
            if g.uuid in self.restored:
                return EvalResult('unstable', boundary=False, abort=True)
            res = self._measure_search(g, p, cfg.fast_window_s, cfg.fast_warmup_s, 'scout')
            if res.status == 'ok':
                self._refresh_frozen(g.model)
            if res.status == 'crash':
                marked = self.after_point_crash(g.uuid, p, res.cause)
                return EvalResult('crash', boundary=res.boundary, abort=marked)
            if res.status == 'ok':
                self._note_extension(g.uuid, p)
            return EvalResult(res.status, res.eff, boundary=res.boundary, hashrate=res.hashrate)
        edges = {'core': cfg.core_range[1], 'mem': cfg.mem_range[1]} if cfg.auto_extend else {}
        sr = Searcher(ev, self.bounds(g.uuid), coarse, hard, soft, {}, 3, cfg.fast_max_points, cfg.min_gain, start_attempts=3 if src == 'conservative' else 4, edges=edges, hs_history={}, objective=self.obj_of(g.uuid)[0], tolerance=self.obj_of(g.uuid)[1], refine_points=0, frozen=self.insensitive_axes(self.obj_of(g.uuid)[0], g.model), axis_rank=self.axis_rank(self.obj_of(g.uuid)[0], g.model))
        self._searcher, self._searcher_uuid = (sr, g.uuid)
        try:
            out = sr.run(seed)
        finally:
            self._searcher = None
        if out.reason == 'aborted' or g.uuid in self.paused:
            return (None, None)
        if out.best is None:
            return (seed, src)
        start = shift_safe(out.best, self.steps, self.bounds(g.uuid), mult)
        self.notify(L(self.lang, f'Карта {self.label(g.uuid)}: быстрый проход завершён ({out.reason}, точек: {out.tested}), детальный поиск вокруг core {out.best.core}, mem {out.best.mem}, PL {out.best.pl}', f'Card {self.label(g.uuid)}: quick pass finished ({out.reason}, points: {out.tested}), detailed search around core {out.best.core}, mem {out.best.mem}, PL {out.best.pl}'))
        return (self._clamp(g.uuid, start), 'scout')

    def _passengers(self, exclude: str) -> list:
        out = []
        for u, c in self.pending.items():
            if c and u != exclude and (u in self.gpus) and (u not in self.paused) and (not self.state.is_solo(u)) and (self.pending_gen.get(u, self.mode_gen) == self.mode_gen):
                out.append((self.gpus[u], c[0][0]))
        return out

    def _measure_search(self, g, p: Point, duration: int, warmup=None, note=None):
        cfg = self.cfg
        if self.boost == g.uuid:
            self._shape_others(g.uuid, self._clamp(g.uuid, p).pl)
        pas = self._passengers(g.uuid) if cfg.verify_early else []
        if not pas:
            return self.measure_group([(g, p)], 'search', duration, warmup, note)[g.uuid]
        kinds = {x.uuid: 'verify' for x, _ in pas}
        results = self.measure_group([(g, p)] + pas, 'search', duration, warmup, note, kinds=kinds)
        warm = cfg.warmup_s if warmup is None else warmup
        for pg, pt in pas:
            self._note_verify_window(pg.uuid, pt, results.get(pg.uuid), duration, warm)
        return results[g.uuid]

    def _note_verify_window(self, u: str, pt: Point, res, duration: int, warm: int) -> None:
        if res is None or u not in self.pending:
            return
        if res.status != 'ok':
            self._verify_outcome(u, pt, res)
            return
        first = self.bg_progress.get(u, 0) == 0
        self.bg_progress[u] = self.bg_progress.get(u, 0) + duration + (0 if first else warm)
        if self.bg_progress[u] >= self.verify_seconds(u):
            self._verify_outcome(u, pt, res)

    def _verify_outcome(self, u: str, pt: Point, res) -> None:
        if u not in self.pending:
            return
        self.bg_progress.pop(u, None)
        if res.status == 'ok':
            self.save_verified(self.gpus[u], pt, res)
            self.pending.pop(u, None)
            escalation.reset(self.db, u)
            self.state.clear_solo(u)
            self.rounds.pop(u, None)
            return
        if res.status == 'crash' and self.after_point_crash(u, pt, res.cause):
            return
        rest = self.pending[u][1:]
        if res.status != 'ok' and res.boundary:
            rest = [c for c in rest if not dominated(c[0], [pt])]
        self.pending[u] = rest
        if not self.pending[u]:
            self._round_failed(self.gpus[u])

    def axis_effects(self) -> dict:
        cfg = self.cfg
        pts: dict = {}
        for u, c, m, p, h, e in self.db.hashrate_evidence(cfg.algo, cfg.miner, cfg.miner_version, self.driver):
            pts.setdefault((u, c, m, p), []).append((h, e))
        avg = {k: (sum((x[0] for x in v)) / len(v), sum((x[1] for x in v)) / len(v)) for k, v in pts.items()}
        out = {}
        for axis in cfg.freeze_axes:
            groups: dict = {}
            for (u, c, m, p), he in avg.items():
                key, val = ((u, p, m), c) if axis == 'core' else ((u, p, c), m)
                groups.setdefault(key, []).append((val, he))
            dh, de, cards = ([], [], set())
            span = cfg.freeze_min_span_steps * self.steps[axis]
            for key, lst in groups.items():
                lst.sort()
                for i, (v1, (h1, e1)) in enumerate(lst):
                    for v2, (h2, e2) in lst[i + 1:]:
                        if v2 - v1 >= span:
                            dh.append(abs(h2 - h1) / max(h1, h2) * 100)
                            de.append(abs(e2 - e1) / max(e1, e2) * 100)
                            cards.add(key[0])
            out[axis] = (dh, de, cards)
        return out
    PROBE_STEPS = {'core': 4, 'mem': 4, 'pl': 6}

    def probe_info(self, model: str='') -> dict:
        c = self.cfg
        return self.db.axis_probe_rows(c.algo, c.miner, c.miner_version, self.driver, model)

    def insensitive_axes(self, objective: Optional[str]=None, model: str='') -> set:
        cfg = self.cfg
        objective = objective or cfg.objective
        if not cfg.auto_freeze:
            return set()
        thr, res = (cfg.freeze_max_effect_pct, set())
        probe = self.probe_info(model) if cfg.axis_probe else {}
        for axis, (dh, de, cards) in self.axis_effects().items():
            series = [dh] if objective == 'hashrate' else [dh, de]
            if len(dh) >= cfg.freeze_min_pairs and len(cards) >= cfg.freeze_min_cards:
                if all((statistics.median(x) <= thr and statistics.fmean(x) <= 1.5 * thr for x in series)):
                    res.add(axis)
            elif axis in probe:
                p_dh, _, p_de, _ = probe[axis]
                vals = [abs(p_dh)] if objective == 'hashrate' else [abs(p_dh), abs(p_de or 0.0)]
                if all((v <= thr for v in vals)):
                    res.add(axis)
        return res

    def pl_flat(self) -> bool:
        if not self.cfg.axis_probe:
            return False
        rows = self.db.q("select d_hash from axis_probe where algo=? and miner=? and miner_version=? and driver_version=? and axis='pl'", (self.cfg.algo, self.cfg.miner, self.cfg.miner_version, self.driver or ''))
        return any((abs(r['d_hash']) <= self.cfg.freeze_max_effect_pct for r in rows))

    def axis_rank(self, objective: Optional[str]=None, model: str='') -> Optional[list]:
        info = self.probe_info(model) if self.cfg.axis_probe else {}
        if not info:
            return None
        obj = objective or self.cfg.objective
        frozen = self.insensitive_axes(obj, model)

        def score(a):
            dh, _, de, n = info.get(a, (0.0, 0.0, 0.0, 1.0))
            s = abs(dh) if obj == 'hashrate' else abs(de or 0.0) if obj == 'efficiency' else abs(dh) + abs(de or 0.0)
            return s / max(n, 1.0)
        return sorted(('core', 'mem', 'pl'), key=lambda a: (a in frozen, -score(a)))

    def _probe_axes(self, g) -> None:
        self.set_phase(L(self.lang, f'проба осей на карте {self.label(g.uuid)} (новый алгоритм: смотрю, что влияет на хешрейт)', f'probing axes on card {self.label(g.uuid)} (new algorithm: checking what affects hashrate)'))
        cfg, u = (self.cfg, g.uuid)
        base, bnd = (self.start_point(u), self.bounds(u))
        r0 = self._measure_search(g, base, cfg.window_s, note='probe')
        if r0.status != 'ok' or r0.hashrate <= 0:
            self.notify(L(self.lang, f'Карта {self.label(u)}: проба осей не удалась (базовая точка нестабильна), подбор пойдёт обычным порядком.', f'Card {self.label(u)}: axis probe failed (the base point is unstable), tuning will proceed normally.'))
            return
        found, bad = ({}, 0)
        for axis in ('pl', 'mem', 'core'):
            n = self.PROBE_STEPS[axis]
            d = {'core': base.core, 'mem': base.mem, 'pl': base.pl}
            d[axis] = min(bnd[axis][1], d[axis] + n * self.steps[axis])
            steps = (d[axis] - getattr(base, axis)) / self.steps[axis]
            if steps < 2:
                continue
            pt = Point(d['core'], d['mem'], d['pl'], cfg.fan)
            r = self._measure_search(g, pt, cfg.window_s, note='probe')
            if r.status == 'crash':
                bad += 1
                if self.after_point_crash(u, pt, r.cause) or bad >= cfg.extend_crash_limit:
                    break
                continue
            bad = 0
            if r.status != 'ok' or r.hashrate <= 0:
                continue
            dh = (r.hashrate / r0.hashrate - 1) * 100
            dp = (r.power / r0.power - 1) * 100 if r.power and r0.power else None
            de = (r.eff / r0.eff - 1) * 100 if r.eff and r0.eff else None
            self.db.save_axis_probe(cfg.algo, cfg.miner, cfg.miner_version, self.driver, axis, steps, dh, dp, de, g.model)
            found[axis] = (dh, dp, steps)
        if not found:
            return
        rank = self.axis_rank(model=g.model) or []
        frozen = self.insensitive_axes(model=g.model)
        names = {'core': 'core', 'mem': 'mem', 'pl': 'PL'}
        lang = self.lang
        if lang == 'en':
            parts = [f"{names[a]} +{found[a][2] * self.steps[a]:.0f}{(' W' if a == 'pl' else '')}: hashrate {found[a][0]:+.1f}%" + (f', power {found[a][1]:+.1f}%' if found[a][1] is not None else '') for a in ('core', 'mem', 'pl') if a in found]
            self.notify(f'New algorithm {cfg.algo}/{cfg.miner}: axis probe on card {self.label(u)}. ' + '; '.join(parts) + f". Tuning priority: {', '.join((names[a] for a in rank if a not in frozen))}" + (f". Have no effect on the target and are frozen: {', '.join((names[a] for a in sorted(frozen)))}" if frozen else '') + '.')
        else:
            parts = [f"{names[a]} +{found[a][2] * self.steps[a]:.0f}{(' Вт' if a == 'pl' else '')}: хешрейт {found[a][0]:+.1f}%" + (f', мощность {found[a][1]:+.1f}%' if found[a][1] is not None else '') for a in ('core', 'mem', 'pl') if a in found]
            self.notify(f'Новый алгоритм {cfg.algo}/{cfg.miner}: проба осей на карте {self.label(u)}. ' + '; '.join(parts) + f". Приоритет подбора: {', '.join((names[a] for a in rank if a not in frozen))}" + (f". Не влияют на цель и заморожены: {', '.join((names[a] for a in sorted(frozen)))}" if frozen else '') + '.')

    def _refresh_frozen(self, model: str='') -> None:
        fr = self.insensitive_axes(model=model)
        lang = self.lang
        for axis in sorted(fr - self.frozen_notified):
            dh, de, cards = self.axis_effects()[axis]
            self.frozen_notified.add(axis)
            if len(dh) < self.cfg.freeze_min_pairs:
                continue
            if lang == 'en':
                what = 'hashrate' if self.cfg.objective == 'hashrate' else 'hashrate and efficiency'
                self.notify(f"Algorithm {self.cfg.algo}: {axis} has no effect on {what} (median hashrate change {statistics.median(dh):.2f}% over {len(dh)} pairs, cards: {len(cards)}). Tuning on {axis} stopped: it stays at the value from the card's best point.")
            else:
                what = 'хешрейт' if self.cfg.objective == 'hashrate' else 'хешрейт и эффективность'
                self.notify(f'Алгоритм {self.cfg.algo}: {axis} не влияет на {what} (медиана изменения хешрейта {statistics.median(dh):.2f}% по {len(dh)} парам, карт: {len(cards)}). Подбор по {axis} остановлен: значение остаётся таким, как в лучшей точке карты.')
        if self._searcher is not None:
            self._searcher.frozen = set(fr)

    def search(self, g) -> None:
        self.set_phase(L(self.lang, f'подбор разгона карты {self.label(g.uuid)}', f'tuning overclock for card {self.label(g.uuid)}'))
        cfg = self.cfg
        if g.uuid in self.restored:
            return
        xv = getattr(self.backend, 'x_visible', None)
        if xv is not None and (not xv(g.uuid)):
            now = self.clock.now()
            if now - self._hidden_note.get(g.uuid, -1000000000.0) > 3600:
                self._hidden_note[g.uuid] = now
                msg = L(self.lang, f'Карта {self.label(g.uuid)}: X-сервер её не видит (nvidia-settings), разгон применить нельзя. Подбор отложен, карта не помечена. Если она подключена через Thunderbolt: python3 -m ocbot --config <конфиг> --fix-external-gpus и перезагрузка рига.', f"Card {self.label(g.uuid)}: the X server can't see it (nvidia-settings), overclocking can't be applied. Tuning postponed, the card is not marked. If it's connected via Thunderbolt: python3 -m ocbot --config <config> --fix-external-gpus and reboot the rig.")
                log.warning(msg)
                self.notify(msg)
            return
        key = (cfg.algo, cfg.miner, cfg.miner_version, g.model)
        if cfg.axis_probe and key not in self._probed and (not self.probe_info(g.model)) and (not self._has_data(g.model)):
            self._probed.add(key)
            self._probe_axes(g)
            if g.uuid in self.paused:
                return
        args = (g.uuid, cfg.algo, cfg.miner, cfg.miner_version, self.driver)
        hard = [Point(*t, cfg.fan) for t in self.db.crash_points(*args, same=True)]
        soft = [Point(*t, cfg.fan) for t in self.db.crash_points(*args, same=False)]
        b = self.bounds(g.uuid)
        hist = {Point(c, m, p, cfg.fan): e for c, m, p, _f, e in self.db.search_history(*args) if b['core'][0] <= c <= b['core'][1] and b['mem'][0] <= m <= b['mem'][1] and (b['pl'][0] <= p <= b['pl'][1])}
        hs_hist = {Point(c, m, p, cfg.fan): h for c, m, p, _f, h in self.db.search_hashrates(*args) if b['core'][0] <= c <= b['core'][1] and b['mem'][0] <= m <= b['mem'][1] and (b['pl'][0] <= p <= b['pl'][1])}
        seed, src = self.seed_point(g)
        self.seed_from[g.uuid] = src
        if cfg.fast_pass and (not hist) and (g.uuid not in self.scouted):
            self.scouted.add(g.uuid)
            seed, src = self._scout(g, seed, src, hard, soft, hs_hist)
            if seed is None:
                return
            self.seed_from[g.uuid] = src

        def evaluate(p: Point) -> EvalResult:
            if g.uuid in self.restored:
                return EvalResult('unstable', boundary=False, abort=True)
            res = self._measure_search(g, p, cfg.window_s)
            if res.status == 'ok':
                self._refresh_frozen(g.model)
            if res.status == 'crash':
                marked = self.after_point_crash(g.uuid, p, res.cause)
                return EvalResult('crash', boundary=res.boundary, abort=marked)
            if res.status == 'ok':
                self._note_extension(g.uuid, p)
            return EvalResult(res.status, res.eff, boundary=res.boundary, hashrate=res.hashrate)
        edges = {'core': cfg.core_range[1], 'mem': cfg.mem_range[1]} if cfg.auto_extend else {}
        sr = Searcher(evaluate, self.bounds(g.uuid), self.steps, hard, soft, hist, cfg.stale_after, cfg.max_points, cfg.min_gain, start_attempts=3 if src == 'conservative' else 4, edges=edges, hs_history=hs_hist, objective=self.obj_of(g.uuid)[0], tolerance=self.obj_of(g.uuid)[1], refine_points=cfg.refine_points, trim_tol=cfg.hash_trim_pct / 100, trim_points=cfg.hash_trim_points, frozen=self.insensitive_axes(self.obj_of(g.uuid)[0], g.model), axis_rank=self.axis_rank(self.obj_of(g.uuid)[0], g.model))
        self._searcher, self._searcher_uuid = (sr, g.uuid)
        try:
            out = sr.run(seed)
        finally:
            self._searcher = None
        self.notify(L(self.lang, f'Карта {self.label(g.uuid)}: поиск завершён ({out.reason}), точек: {out.tested}', f'Card {self.label(g.uuid)}: search finished ({out.reason}), points: {out.tested}'))
        if out.reason == 'no_stable_start':
            eff = self._check_stock(g)
            if eff and g.uuid not in self.paused:
                self.db.set_gpu_status(g.uuid, 'suspect', 'стабильна только на заводских настройках')
                self.pending[g.uuid] = [(self.safe_point(g.uuid), eff)]
                self.pending_gen[g.uuid] = self.mode_gen
                self.notify(L(self.lang, f'Карта {self.label(g.uuid)}: ни одна точка разгона не держится, но заводские настройки стабильны. Проверяю их как пресет этой карты.', f"Card {self.label(g.uuid)}: no overclock point holds, but the stock settings are stable. Verifying them as this card's preset."))
                return
        if out.reason == 'aborted' or g.uuid in self.paused:
            return
        cands, seen = ([], set())
        by_eff = sorted(out.ranking, key=lambda t: t[1], reverse=True)
        for p, e in out.ranking[:3] + by_eff[:3]:
            margin = cfg.safety_steps * (1 + self.rounds.get(g.uuid, 0))
            q = self._clamp(g.uuid, shift_safe(p, self.steps, self.bounds(g.uuid), margin))
            if q.key() not in seen and len(cands) < 5:
                seen.add(q.key())
                cands.append((q, e))
        self.pending[g.uuid] = cands
        self.pending_gen[g.uuid] = self.mode_gen
        self.bg_progress.pop(g.uuid, None)
        if not cands:
            self._round_failed(g)

    def _check_stock(self, g) -> Optional[float]:
        safe = self.safe_point(g.uuid)
        while g.uuid not in self.paused and (not self.halted):
            res = self.measure_group([(g, safe)], 'recheck', self.cfg.recheck_s)[g.uuid]
            if res.status == 'ok':
                return res.eff
            if res.status != 'crash' or self.after_point_crash(g.uuid, safe, res.cause):
                return None
        return None

    def _round_failed(self, g) -> None:
        n = self.rounds.get(g.uuid, 0) + 1
        self.rounds[g.uuid] = n
        self.pending.pop(g.uuid, None)
        if n >= self.cfg.max_search_rounds:
            self.mark_card(g.uuid, 'suspect', L(self.lang, 'не найден стабильный пресет за все раунды поиска', 'no stable preset found in all search rounds'))
        else:
            self.search(g)

    def run_verifications(self) -> None:
        if self.pending:
            names = ', '.join((self.label(u) for u in self.pending if u in self.gpus))
            self.set_phase(L(self.lang, 'двухчасовая проверка найденных настроек: ' + names, '2-hour check of the settings found: ' + names))
        for u in [u for u in self.pending if self.pending_gen.get(u, self.mode_gen) != self.mode_gen and u in self.gpus]:
            self.pending.pop(u, None)
            self.search(self.gpus[u])
        guard = 0
        while self.pending and guard < 100:
            guard += 1
            batch = {u: c[0] for u, c in self.pending.items() if c and (not self.state.is_solo(u))}
            groups = ([batch] if batch else []) + [{u: c[0]} for u, c in self.pending.items() if c and self.state.is_solo(u)]
            if not groups:
                break
            for grp in groups:
                items = [(self.gpus[u], pt) for u, (pt, _) in grp.items() if u in self.gpus]
                left = [self.verify_seconds(g.uuid) - self.bg_progress.get(g.uuid, 0) for g, _ in items]
                dur = max(300, min(left, default=self.cfg.verify_s))
                results = self.measure_group(items, 'verify', dur)
                for u, (pt, seff) in grp.items():
                    self._note_verify_window(u, pt, results.get(u), dur, self.cfg.warmup_s)
            self.pending = {u: c for u, c in self.pending.items() if c}

    def save_verified(self, g, p: Point, res: Result) -> None:
        if g.uuid in self.restored:
            return
        cfg, row = (self.cfg, self.db.gpu(g.uuid))
        prev = self.db.one('select * from profiles where gpu_uuid=? and algo=? and miner=? and rig is not null and rig != ? and efficiency is not null order by created_at desc, rowid desc', (g.uuid, cfg.algo, cfg.miner, cfg.rig_name))
        pid, ts = (uuidlib.uuid4().hex, utcnow())
        old = self.db.latest_profile_any(g.uuid, cfg.algo, cfg.miner)
        self.db.save_profile({'id': pid, 'gpu_uuid': g.uuid, 'algo': cfg.algo, 'miner': cfg.miner, 'miner_version': cfg.miner_version, 'driver_version': self.driver, 'vbios': g.vbios, 'core_offset': p.core, 'mem_offset': p.mem, 'power_limit': p.pl, 'fan': p.fan, 'hashrate': res.hashrate, 'power_w': res.power, 'efficiency': res.eff, 'status': 'verified', 'weak_card': int(row['status'] == 'suspect'), 'source': 'local', 'seed_from': self.seed_from.get(g.uuid), 'rig': cfg.rig_name, 'slot': g.slot, 'objective': self.obj_of(g.uuid)[0], 'temp_at_verify': res.tcore, 'created_at': ts, 'verified_at': ts})
        self._mirror_lock(g.uuid)
        self.db.log_change(g.uuid, cfg.algo, cfg.miner, {'core': old['core_offset'], 'mem': old['mem_offset'], 'pl': old['power_limit']} if old else None, {'core': p.core, 'mem': p.mem, 'pl': p.pl}, f'верификация {self.verify_seconds(g.uuid) // 60} мин пройдена')
        self.notify(L(self.lang, f'Карта {self.label(g.uuid)}: пресет проверен ({self.verify_seconds(g.uuid) // 60} мин): core {p.core}, mem {p.mem}, PL {p.pl}, хешрейт {res.hashrate:.1f}, эффективность {res.eff:.4f}', f'Card {self.label(g.uuid)}: preset verified ({self.verify_seconds(g.uuid) // 60} min): core {p.core}, mem {p.mem}, PL {p.pl}, hashrate {res.hashrate:.1f}, efficiency {res.eff:.4f}'))
        if prev:
            self.compare_places(g, prev['rig'], prev['slot'], prev['efficiency'], res.eff)
        self.on_verified(pid)

    def compare_places(self, g, old_rig, old_slot, old_eff: float, new_eff: float) -> None:
        thr, lang = (self.cfg.compare_threshold, self.lang)
        if lang == 'en':
            if old_eff and new_eff >= old_eff * (1 + thr):
                note = f'in {self.cfg.rig_name}/slot {g.slot} the card is more efficient ({new_eff:.4f} vs {old_eff:.4f}): check {old_rig}/slot {old_slot} (riser, power, cooling). Rig conditions can differ'
            elif old_eff and new_eff <= old_eff * (1 - thr):
                note = f'in {self.cfg.rig_name}/slot {g.slot} the card is worse ({new_eff:.4f} vs {old_eff:.4f}): check this spot. Rig conditions can differ'
            else:
                return
        elif old_eff and new_eff >= old_eff * (1 + thr):
            note = f'в {self.cfg.rig_name}/слот {g.slot} карта эффективнее ({new_eff:.4f} против {old_eff:.4f}): проверьте {old_rig}/слот {old_slot} (райзер, питание, охлаждение). Условия рига могут отличаться'
        elif old_eff and new_eff <= old_eff * (1 - thr):
            note = f'в {self.cfg.rig_name}/слот {g.slot} карта хуже ({new_eff:.4f} против {old_eff:.4f}): проверьте это место. Условия рига могут отличаться'
        else:
            return
        self.db.note_placement(g.uuid, note)
        self.notify(L(lang, f'Карта {self.label(g.uuid)}: {note}', f'Card {self.label(g.uuid)}: {note}'))

    def run_rechecks(self, items: list) -> None:
        if items:
            self.set_phase(L(self.lang, 'короткая перепроверка сохранённых пресетов', 'short re-check of saved presets'))
        if not items:
            return
        pts = [(g, self._clamp(g.uuid, Point(pr['core_offset'], pr['mem_offset'], pr['power_limit'], self.cfg.fan))) for g, pr in items]
        results = self.measure_group(pts, 'recheck', self.cfg.recheck_s)
        for (g, pr), (_, pt) in zip(items, pts):
            res = results[g.uuid]
            if res.status == 'ok':
                self.recheck_needed.discard(g.uuid)
                if pr['status'] == 'imported':
                    if pt.pl != pr['power_limit']:
                        self.db.x('update profiles set power_limit=? where id=?', (pt.pl, pr['id']))
                    self.db.promote(pr['id'], self.cfg.rig_name, g.slot)
                    self.on_verified(pr['id'])
                if pr['efficiency'] and pr['rig'] and (pr['rig'] != self.cfg.rig_name):
                    self.compare_places(g, pr['rig'], pr['slot'], pr['efficiency'], res.eff)
                elif pr['efficiency'] and res.eff >= pr['efficiency'] * (1 + self.cfg.compare_threshold):
                    self.compare_places(g, pr['rig'] or '?', pr['slot'], pr['efficiency'], res.eff)
                escalation.reset(self.db, g.uuid)
                self.apply(g.uuid, pt)
                continue
            self.db.set_profile_status(pr['id'], 'outdated')
            self.recheck_needed.discard(g.uuid)
            self.notify(L(self.lang, f'Карта {self.label(g.uuid)}: сохранённый пресет не прошёл проверку на этом месте, подбираю заново.', f'Card {self.label(g.uuid)}: the saved preset failed verification in this spot, re-tuning.'))
            if res.status == 'crash':
                self.after_point_crash(g.uuid, pt, res.cause)

    def verify_existing(self, uuids: list) -> None:
        self.set_phase(L(self.lang, 'повторная проверка готовых пресетов', 're-verifying ready presets'))
        items = []
        for u in uuids:
            v = self.db.get_profile(u, self.cfg.algo, self.cfg.miner, self.cfg.miner_version, 'verified')
            if v and u in self.gpus:
                items.append((self.gpus[u], Point(v['core_offset'], v['mem_offset'], v['power_limit'], self.cfg.fan), v))
        if not items:
            return
        results = self.measure_group([(g, p) for g, p, _ in items], 'verify', self.cfg.verify_s)
        for g, p, v in items:
            if results[g.uuid].status == 'ok':
                self.db.x('update profiles set verified_at=? where id=?', (utcnow(), v['id']))
                self.notify(L(self.lang, f'Карта {self.label(g.uuid)}: повторная проверка пройдена', f'Card {self.label(g.uuid)}: re-verification passed'))
            else:
                self.db.set_profile_status(v['id'], 'outdated')
                self.notify(L(self.lang, f'Карта {self.label(g.uuid)}: повторная проверка не пройдена, пресет отправлен на перепоиск', f'Card {self.label(g.uuid)}: re-verification failed, the preset was sent back for re-tuning'))
                if results[g.uuid].status == 'crash':
                    self.after_point_crash(g.uuid, p, results[g.uuid].cause)

    def _usable(self, u: str) -> bool:
        row = self.db.gpu(u)
        return bool(row) and row['status'] != 'faulty' and (u not in self.paused)

    def _pid(self, u: str):
        v = self._verified(u)
        return v['id'] if v else None

    def _verified(self, u: str):
        c = self.cfg
        return self.db.get_profile(u, c.algo, c.miner, c.miner_version, 'verified')

    def verify_seconds(self, u: str) -> int:
        base = self.cfg.verify_s
        try:
            since = (datetime.now(timezone.utc) - timedelta(hours=24)).isoformat(timespec='seconds')
            if self.db.work_crashes_since(u, since) >= 2:
                return base * max(1, self.cfg.verify_long_mult)
        except Exception:
            pass
        return base

    def _fresh_boot(self) -> bool:
        try:
            bt = self.backend.boot_time()
        except Exception:
            bt = None
        if not bt:
            return True
        return time.time() - bt < self.cfg.fresh_boot_s

    def _apply_preset_or_safe(self, u: str) -> None:
        v = self._verified(u)
        if v:
            self._apply_if_visible(u, Point(v['core_offset'], v['mem_offset'], v['power_limit'], self.cfg.fan))
        else:
            self.apply_safe(u)

    def _apply_if_visible(self, u: str, p) -> None:
        try:
            self.apply(u, p)
        except BackendError as e:
            if not self._card_hidden(e):
                raise
            now = self.clock.now()
            if now - self._hidden_note.get(u, -1000000000.0) > 3600:
                self._hidden_note[u] = now
                msg = L(self.lang, f'Карта {self.label(u)}: X-сервер её не видит (nvidia-settings), настройки пресета не применены. Нужен перезапуск X-сервера или рига.', f"Card {self.label(u)}: the X server can't see it (nvidia-settings), preset settings weren't applied. The X server or the rig needs a restart.")
                log.warning(msg)
                self.notify(msg)

    def _boost_others(self, x: str) -> list:
        grp = self.psu.group_of(self.gpus[x].slot)
        return [u for u in self.gpus if u != x and self.psu.group_of(self.gpus[u].slot) is grp]

    def _boost_ceiling(self, x: str) -> Optional[int]:
        grp = self.psu.group_of(self.gpus[x].slot)
        if grp is None:
            return None
        floor = sum((self.pl_lock(u) or self._raw_pl(u)[0] for u in self._boost_others(x)))
        return int((self.psu.budget(grp) - floor * self.cfg.psu_transient) / self.cfg.psu_transient)

    def _enter_boost(self, g) -> None:
        self.boost = g.uuid
        self._boost_pl = {}
        self._boost_x_pl = None

    def _exit_boost(self) -> None:
        x = self.boost
        self.boost, self._boost_pl, self._boost_x_pl = (None, {}, None)
        for u in sorted(self.gpus, key=lambda k: 0 if k == x else 1):
            try:
                self._apply_preset_or_safe(u)
            except BackendError as e:
                log.warning('не удалось вернуть пресет карты %s: %s', u, e)

    def _shape_others(self, x: str, pl: int) -> None:
        grp = self.psu.group_of(self.gpus[x].slot)
        if grp is None:
            return
        cfg, t = (self.cfg, self.cfg.psu_transient)
        budget = int(self.psu.budget(grp) / t)
        base, floor = ({}, {})
        for u in self._boost_others(x):
            v = self._verified(u)
            lo = self._raw_pl(u)[0]
            lock = self.pl_lock(u)
            ceil = self.pl_limits(u)[2]
            base[u] = lock or max(lo, min(ceil, int(v['power_limit']) if v else ceil))
            floor[u] = lock or lo
        x_pl = max(pl, self._boost_x_pl or 0)
        deficit = x_pl + sum(base.values()) - budget
        room = {u: base[u] - floor[u] for u in base}
        total_room = sum(room.values())
        for u in base:
            cut = 0
            if deficit > 0 and total_room > 0:
                cut = min(room[u], -(-deficit * room[u] // total_room))
            target = base[u] - cut
            if self._boost_pl.get(u) == target:
                continue
            v = self._verified(u)
            core, mem = (v['core_offset'], v['mem_offset']) if v else (0, 0)
            try:
                self.apply(u, Point(core, mem, target, cfg.fan))
                self._boost_pl[u] = target
            except BackendError as e:
                log.warning('не удалось изменить PL карты %s: %s', u, e)
        self._boost_x_pl = pl

    def _extend_ceiling(self, g, deep: bool=False) -> None:
        self.set_phase(L(self.lang, f'расширение потолка PL карты {self.label(g.uuid)}', f'extending PL ceiling for card {self.label(g.uuid)}'))
        cfg, u = (self.cfg, g.uuid)
        v = self._verified(u)
        if not v:
            return
        self._enter_boost(g)
        try:
            frozen = self.insensitive_axes(model=g.model)
            hard = [Point(*t, cfg.fan) for t in self.db.crash_points(u, cfg.algo, cfg.miner, cfg.miner_version, self.driver, same=True)]
            cur = {'core': int(v['core_offset']), 'pl': int(v['power_limit']), 'h': float(v['hashrate'] or 0)}
            mem0 = int(v['mem_offset'])
            spent, stop = ([0], [False])
            budget = cfg.refine_points * 3
            bad, tot = ([0], [0])
            start = dict(cur)

            def point(core, pl):
                return Point(core, mem0, pl, cfg.fan)

            def measure(pt):
                spent[0] += 1
                res = self._measure_search(g, pt, cfg.window_s, note='extend')
                bad[0] = bad[0] + 1 if res.status == 'crash' else 0
                tot[0] += res.status == 'crash'
                if (bad[0] >= cfg.extend_crash_limit or tot[0] >= cfg.extend_crash_total) and (not stop[0]):
                    stop[0] = True
                    self.notify(L(self.lang, f'Карта {self.label(u)}: {bad[0]} перезагрузок рига подряд ({tot[0]} за проход) при расширении потолка. Прекращаю и возвращаю последний хороший пресет.', f'Card {self.label(u)}: {bad[0]} rig reboots in a row ({tot[0]} this pass) while extending the ceiling. Stopping and restoring the last good preset.'))
                return res

            def climb(axis) -> bool:
                improved, k = (False, 1)
                while spent[0] < budget and (not stop[0]):
                    hi = self.bounds(u)[axis][1]
                    val = min(hi, cur[axis] + self.steps[axis] * k)
                    if val <= cur[axis]:
                        break
                    pt = point(val if axis == 'core' else cur['core'], val if axis == 'pl' else cur['pl'])
                    if dominated(pt, hard):
                        if k == 1:
                            break
                        k = 1
                        continue
                    res = measure(pt)
                    if res.status == 'ok':
                        if cur['h'] and res.hashrate < cur['h'] * (1 + cfg.min_gain):
                            if k == 1:
                                break
                            k = 1
                            continue
                        cur[axis], cur['h'], k, improved = (val, res.hashrate, min(k * 2, 8), True)
                    else:
                        if res.status == 'crash' and self.after_point_crash(u, pt, res.cause):
                            stop[0] = True
                        if k == 1:
                            break
                        k = 1
                return improved
            for _ in range(3):
                changed = climb('pl')
                if 'core' not in frozen and (not stop[0]):
                    changed = climb('core') or changed
                if not changed or stop[0]:
                    break
            if deep and (not stop[0]):
                self._deep_scan(g, cur, mem0, frozen, hard, measure, stop)
            gain = (cur['h'] / start['h'] - 1) * 100 if start['h'] else 0.0
            self.notify(L(self.lang, f"Карта {self.label(u)}: итог расширения потолка: PL {start['pl']} -> {cur['pl']} Вт, core {start['core']} -> {cur['core']}, хешрейт {start['h']:.1f} -> {cur['h']:.1f} ({gain:+.1f}%). Замерено точек {spent[0]}, перезагрузок рига {tot[0]}.", f"Card {self.label(u)}: ceiling extension result: PL {start['pl']} -> {cur['pl']} W, core {start['core']} -> {cur['core']}, hashrate {start['h']:.1f} -> {cur['h']:.1f} ({gain:+.1f}%). Points measured {spent[0]}, rig reboots {tot[0]}."))
        finally:
            self._exit_boost()

    def _deep_scan(self, g, cur: dict, mem0: int, frozen: set, hard: list, measure, stop: list) -> None:
        self.set_phase(L(self.lang, f'плотный перебор core x PL карты {self.label(g.uuid)}', f'dense core x PL scan for card {self.label(g.uuid)}'))
        cfg, u = (self.cfg, g.uuid)
        bnd = self.bounds(u)
        nc = 0 if 'core' in frozen else cfg.deep_core_steps
        known = {(c, m, p) for c, m, p, _h, _e in self.db.curve_points(u, cfg.algo, cfg.miner, cfg.miner_version, self.driver)}
        cells = []
        for i in range(-nc, nc + 1):
            for j in range(-cfg.deep_pl_steps, cfg.deep_pl_steps + 1):
                core, pl = (cur['core'] + i * self.steps['core'], cur['pl'] + j * self.steps['pl'])
                if bnd['core'][0] <= core <= bnd['core'][1] and bnd['pl'][0] <= pl <= bnd['pl'][1]:
                    cells.append((abs(i) + abs(j), core, pl))
        done = 0
        for _, core, pl in sorted(cells):
            pt = Point(core, mem0, pl, cfg.fan)
            if stop[0] or self.halted:
                break
            if (core, mem0, pl) in known or dominated(pt, hard):
                continue
            res = measure(pt)
            done += 1
            if res.status == 'ok' and res.hashrate > cur['h'] * (1 + cfg.min_gain):
                cur.update(core=core, pl=pl, h=res.hashrate)
            elif res.status == 'crash' and self.after_point_crash(u, pt, res.cause):
                stop[0] = True
        self.notify(L(self.lang, f'Карта {self.label(u)}: плотная сетка core x PL ' + ('прервана' if stop[0] else 'пройдена') + f', новых точек {done}.', f'Card {self.label(u)}: dense core x PL scan ' + ('interrupted' if stop[0] else 'finished') + f', new points {done}.'))

    def opt_gain(self) -> float:
        v = self.state.data.get('opt_min_gain')
        return float(v) if v is not None else self.cfg.opt_min_gain

    @staticmethod
    def _gain_ok(frac) -> bool:
        try:
            return 0.001 <= float(frac) <= 0.5
        except (TypeError, ValueError):
            return False

    def set_opt_gain(self, pct) -> None:
        lang = self.lang
        if pct in (None, 'show'):
            self.notify(L(lang, f'Порог выигрыша оптимизации по умолчанию: {self.opt_gain():.1%}. Сменить: /optimize gain 1.5 (в процентах, от 0,1 до 50).', f'Default optimization gain threshold: {self.opt_gain():.1%}. Change it: /optimize gain 1.5 (percent, 0.1 to 50).'))
            return
        try:
            frac = float(str(pct).rstrip('%').replace(',', '.')) / 100
        except ValueError:
            frac = -1.0
        if not self._gain_ok(frac):
            self.notify(L(lang, 'Порог должен быть числом процентов от 0,1 до 50, например /optimize gain 1.5', 'The threshold must be a percentage between 0.1 and 50, e.g. /optimize gain 1.5'))
            return
        self.state.data['opt_min_gain'] = frac
        self.state.save()
        self.notify(L(lang, f'Порог выигрыша оптимизации по умолчанию: {frac:.1%}. Новый пресет принимается, только если лучше прежнего больше чем на столько.', f'Default optimization gain threshold: {frac:.1%}. A new preset is accepted only if it beats the previous one by at least this much.'))

    def cmd_optimize(self, target: str='all', gain=None) -> None:
        lang = self.lang
        run_gain = None
        if gain is not None:
            try:
                run_gain = float(str(gain).rstrip('%').replace(',', '.')) / 100
            except ValueError:
                run_gain = -1.0
            if not self._gain_ok(run_gain):
                self.notify(L(lang, 'Порог должен быть числом процентов от 0,1 до 50, например /optimize 3 2', 'The threshold must be a percentage between 0.1 and 50, e.g. /optimize 3 2'))
                return
        if target in ('cancel', 'off', 'отмена'):
            self.state.data.pop('optimize', None)
            self.state.save()
            self.notify(L(lang, 'Очередь оптимизации очищена (карта, которую оптимизируют сейчас, дойдёт до конца своего шага).', 'Optimization queue cleared (the card currently being optimized will finish its step).'))
            return
        if target in (None, '', 'all'):
            cand = [u for u in sorted(self.gpus, key=lambda x: self.gpus[x].slot)]
        else:
            u = self.resolve(target)
            if not u:
                self.notify(self.not_found_msg(target))
                return
            cand = [u]
        queue, skipped = ([], [])
        if lang == 'en':
            for u in cand:
                if not self._usable(u):
                    skipped.append(f'{self.label(u)}: card disabled or paused')
                elif not self._verified(u):
                    skipped.append(f'{self.label(u)}: no ready preset yet, run regular tuning first')
                elif self._fragile(u):
                    skipped.append(f'{self.label(u)}: recently crashed the rig while extending, skipping for {self.cfg.balance_skip_crash_hours}h')
                else:
                    queue.append(u)
            if not queue:
                self.notify('Nothing to optimize.' + ('\n' + '\n'.join(skipped) if skipped else ''))
                return
        else:
            for u in cand:
                if not self._usable(u):
                    skipped.append(f'{self.label(u)}: карта отключена или на паузе')
                elif not self._verified(u):
                    skipped.append(f'{self.label(u)}: готового пресета ещё нет, сначала обычный подбор')
                elif self._fragile(u):
                    skipped.append(f'{self.label(u)}: недавно роняла риг при расширении, пропускаю на {self.cfg.balance_skip_crash_hours} ч')
                else:
                    queue.append(u)
            if not queue:
                self.notify(L(lang, 'Оптимизировать нечего.' + ('\n' + '\n'.join(skipped) if skipped else ''), 'Nothing to optimize.' + ('\n' + '\n'.join(skipped) if skipped else '')))
                return
        self.state.data['optimize'] = {'queue': queue, 'done': [], 'gain': run_gain}
        self.state.save()
        eff_gain = run_gain if run_gain is not None else self.opt_gain()
        if lang == 'en':
            self.notify(f"Optimization started, one card at a time: {', '.join((self.label(u) for u in queue))}. Each card: search near the preset, final long repeated measurements, a new preset is accepted only with a gain above {eff_gain:.1%} and a 2-hour verification. /stop interrupts, /optimize cancel clears the queue." + ('\nSkipped:\n' + '\n'.join(skipped) if skipped else ''))
        else:
            self.notify(f"Оптимизация запущена, по одной карте за раз: {', '.join((self.label(u) for u in queue))}. Каждая карта: поиск в окрестности пресета, финал с повторными длинными замерами, новый пресет принимается только при выигрыше больше {eff_gain:.1%} и 2-часовой проверке. /stop прервёт, /optimize cancel очистит очередь." + ('\nПропущены:\n' + '\n'.join(skipped) if skipped else ''))

    def _optimize_step(self) -> None:
        st = self.state.data.get('optimize')
        if not st or self.halted or self.pending:
            return
        while st['queue']:
            u = st['queue'].pop(0)
            self.state.save()
            if u in self.gpus and self._usable(u) and self._verified(u):
                self._gain_now = st.get('gain') if st.get('gain') is not None else self.opt_gain()
                try:
                    st['done'].append(self.optimize_card(self.gpus[u]))
                except Stopped:
                    self.state.data.pop('optimize', None)
                    self.state.save()
                    raise
                self.state.save()
                break
        if not st['queue']:
            rows = [r for r in st['done'] if r]
            self.state.data.pop('optimize', None)
            self.state.save()
            self.notify(L(self.lang, 'Оптимизация завершена.' + ('\n' + '\n'.join(rows) if rows else ''), 'Optimization finished.' + ('\n' + '\n'.join(rows) if rows else '')))

    def _opt_score(self, res, obj: str, tol: float, ref_eff: float):
        if res.status != 'ok' or not res.hashrate:
            return None
        if obj == 'hashrate':
            return res.hashrate
        if obj == 'efficiency':
            return res.eff or None
        return res.hashrate if res.eff and res.eff >= ref_eff * (1 - tol) else None

    def optimize_card(self, g) -> str:
        cfg, u = (self.cfg, g.uuid)
        v = self._verified(u)
        thr = self._gain_now if self._gain_now is not None else self.opt_gain()
        obj, tol = self.obj_of(u)
        frozen = self.insensitive_axes(obj, g.model)
        hard = [Point(*t, cfg.fan) for t in self.db.crash_points(u, cfg.algo, cfg.miner, cfg.miner_version, self.driver, same=True)]
        cur = Point(int(v['core_offset']), int(v['mem_offset']), int(v['power_limit']), cfg.fan)
        bnd, st = (self.bounds(u), self.steps)
        lock = self.pl_lock(u)
        cells = []
        for dc in range(-cfg.opt_core_steps, cfg.opt_core_steps + 1):
            for dm in range(-cfg.opt_mem_steps, cfg.opt_mem_steps + 1):
                for dp in range(-cfg.opt_pl_steps, cfg.opt_pl_steps + 1):
                    if (dc, dm, dp) == (0, 0, 0) or (dc and 'core' in frozen) or (dm and 'mem' in frozen) or (dp and (lock or 'pl' in frozen)):
                        continue
                    pt = Point(cur.core + dc * st['core'], cur.mem + dm * st['mem'], cur.pl + dp * st['pl'], cfg.fan)
                    if not (bnd['core'][0] <= pt.core <= bnd['core'][1] and bnd['mem'][0] <= pt.mem <= bnd['mem'][1] and (bnd['pl'][0] <= pt.pl <= bnd['pl'][1])) or dominated(pt, hard):
                        continue
                    cells.append((abs(dc) + abs(dm) + abs(dp), pt))
        cells.sort(key=lambda t: t[0])
        cells = [pt for _, pt in cells[:cfg.opt_max_points]]
        name = self.label(u)
        lang = self.lang
        if not cells:
            return L(lang, f'{name}: вокруг пресета нет точек для проверки (границы, замок или оси заморожены).', f'{name}: no points to check around the preset (bounds, lock, or frozen axes).')
        long_w = int(cfg.window_s * cfg.opt_window_mult)
        bad, tot, stop = ([0], [0], [False])
        spent = [0]
        old_id = self._pid(u)

        def measure(pt, dur):
            spent[0] += 1
            res = self._measure_search(g, pt, dur, note='extend')
            bad[0] = bad[0] + 1 if res.status == 'crash' else 0
            tot[0] += res.status == 'crash'
            if res.status == 'crash' and self.after_point_crash(u, pt, res.cause):
                stop[0] = True
            if (bad[0] >= cfg.extend_crash_limit or tot[0] >= cfg.extend_crash_total) and (not stop[0]):
                stop[0] = True
                self.notify(L(lang, f'Карта {name}: {bad[0]} перезагрузок рига подряд ({tot[0]} за проход) при оптимизации. Прекращаю, прежний пресет остаётся.', f'Card {name}: {bad[0]} rig reboots in a row ({tot[0]} this pass) during optimization. Stopping, the previous preset stays.'))
            return res
        self.notify(L(lang, f'Карта {name}: оптимизация, цель {obj}. Пресет core {cur.core}, mem {cur.mem}, PL {cur.pl}; проверяю до {len(cells)} точек вокруг него.', f'Card {name}: optimizing, target {obj}. Preset core {cur.core}, mem {cur.mem}, PL {cur.pl}; checking up to {len(cells)} points around it.'))
        self._enter_boost(g)
        try:
            self.set_phase(L(lang, f'оптимизация карты {name}: замер текущего пресета', f'optimizing card {name}: measuring the current preset'))
            base1 = measure(cur, long_w)
            if base1.status != 'ok' or stop[0]:
                return L(lang, f'{name}: прежний пресет не измерился ({base1.status}), оптимизация пропущена.', f"{name}: the previous preset didn't measure ({base1.status}), optimization skipped.")
            known_eff = [float(e) for *_, e in self.db.curve_points(u, cfg.algo, cfg.miner, cfg.miner_version, self.driver) if e]
            ref_eff = max([base1.eff or 0.0] + known_eff)
            b1 = self._opt_score(base1, obj, tol, ref_eff) or 0.0
            screened = []
            self.set_phase(L(lang, f'оптимизация карты {name}: проверяю точки вокруг пресета (до {len(cells)})', f'optimizing card {name}: checking points around the preset (up to {len(cells)})'))
            for pt in cells:
                if stop[0] or self.halted:
                    break
                res = measure(pt, cfg.window_s)
                sc = self._opt_score(res, obj, tol, ref_eff)
                if sc is not None and sc > b1 * (1 + thr / 2):
                    screened.append((sc, pt))
            screened.sort(key=lambda t: -t[0])
            finalists = [pt for _, pt in screened[:cfg.opt_top]]
            if not finalists or stop[0]:
                return L(lang, f'{name}: улучшений не найдено (замерено точек: {spent[0]}), пресет остаётся прежним.', f'{name}: no improvement found (points measured: {spent[0]}), the preset stays unchanged.')
            finals = []
            self.set_phase(L(lang, f'оптимизация карты {name}: финал, длинные замеры лучших точек', f'optimizing card {name}: final, long measurements of the best points'))
            for pt in finalists:
                if stop[0]:
                    break
                res = measure(pt, long_w)
                sc = self._opt_score(res, obj, tol, ref_eff)
                if sc is not None:
                    finals.append((sc, pt, res))
            base2 = measure(cur, long_w) if not stop[0] else None
            b2 = (self._opt_score(base2, obj, tol, ref_eff) if base2 and base2.status == 'ok' else None) or b1
            base_ref = (b1 + b2) / 2
            winners = sorted((t for t in finals if t[0] >= base_ref * (1 + thr)), key=lambda t: -t[0])
        finally:
            self._exit_boost()
        if not winners:
            best = max((t[0] for t in finals), default=0.0)
            return L(lang, f'{name}: в финале выигрыш меньше порога {thr:.1%} (лучшая точка {(best / base_ref - 1) * 100:+.1f}% при шуме замеров), пресет остаётся прежним.', f'{name}: the final gain is below the {thr:.1%} threshold (best point {(best / base_ref - 1) * 100:+.1f}% amid measurement noise), the preset stays unchanged.')
        top = winners[0]
        gain = (top[0] / base_ref - 1) * 100
        cands = [(self._clamp(u, t[1]), t[2].eff or 0.0) for t in winners[:cfg.opt_top]]
        cands.append((self._clamp(u, cur), float(v['efficiency'] or 0)))
        self.pending[u] = cands
        self.pending_gen[u] = self.mode_gen
        self.bg_progress.pop(u, None)
        self.notify(L(lang, f'Карта {name}: найдено лучше прежнего на {gain:+.1f}%: core {top[1].core}, mem {top[1].mem}, PL {top[1].pl} (было {cur.core}/{cur.mem}/{cur.pl}). Новый пресет проходит 2-часовую проверку.', f'Card {name}: found {gain:+.1f}% better than before: core {top[1].core}, mem {top[1].mem}, PL {top[1].pl} (was {cur.core}/{cur.mem}/{cur.pl}). The new preset is going through a 2-hour verification.'))
        self.run_verifications()
        new = self._verified(u)
        if new and new['id'] != old_id and ((new['core_offset'], new['mem_offset'], new['power_limit']) != (cur.core, cur.mem, cur.pl)):
            return L(lang, f"{name}: принят новый пресет core {new['core_offset']}, mem {new['mem_offset']}, PL {new['power_limit']}, хешрейт {float(new['hashrate'] or 0):.1f}, эффективность {float(new['efficiency'] or 0):.3f} (прежний {float(v['hashrate'] or 0):.1f} / {float(v['efficiency'] or 0):.3f}).", f"{name}: accepted the new preset core {new['core_offset']}, mem {new['mem_offset']}, PL {new['power_limit']}, hashrate {float(new['hashrate'] or 0):.1f}, efficiency {float(new['efficiency'] or 0):.3f} (previous {float(v['hashrate'] or 0):.1f} / {float(v['efficiency'] or 0):.3f}).")
        return L(lang, f'{name}: новый пресет проверку не прошёл, работает прежний.', f'{name}: the new preset failed verification, the previous one is running.')

    def params_of(self, u: str) -> int:
        if self.trial:
            return 2
        return 4 if (self.state.data.get('params') or {}).get(u) == 4 else 2

    def lock_key(self) -> str:
        c = self.cfg
        return f'{c.algo}|{c.miner}|{c.miner_version}'

    def _lock_entry(self, u: str):
        return ((self.state.data.get('locks') or {}).get(u) or {}).get(self.lock_key())

    def _lock_set(self, u: str, core, mem, note: str='', **extra) -> None:
        v = self._verified(u)
        e = {'core': core, 'mem': mem, 'note': note, 'at': utcnow(), 'off': [int(v['core_offset']), int(v['mem_offset'])] if v else None}
        e.update(extra)
        self.state.data.setdefault('locks', {}).setdefault(u, {})[self.lock_key()] = e
        self.state.save()
        self._mirror_lock(u)

    def _mirror_lock(self, u: str) -> None:
        v = self._verified(u)
        if not v:
            return
        sl = self.stored_lock(u)
        self.db.x('update profiles set core_lock=?, mem_lock=? where id=?', (sl[0] if sl else None, sl[1] if sl else None, v['id']))

    def _lock_valid(self, u: str, v=None) -> bool:
        v = v or self._verified(u)
        e = self._lock_entry(u)
        return bool(e and v and (e.get('off') == [int(v['core_offset']), int(v['mem_offset'])]))

    def stored_lock(self, u: str):
        if self.params_of(u) != 4 or not self._lock_valid(u):
            return None
        e = self._lock_entry(u)
        if not e.get('core') and (not e.get('mem')):
            return None
        return (e.get('core') or None, e.get('mem') or None)

    def _want_lock(self, u: str, p: Point):
        if u in self.lock_override:
            return self.lock_override[u]
        sl = self.stored_lock(u)
        v = self._verified(u)
        if sl and v and ((int(v['core_offset']), int(v['mem_offset'])) == (p.core, p.mem)):
            return sl
        return None

    def _sync_locks(self, u: str, p: Point) -> None:
        if not hasattr(self.backend, 'lock_clocks'):
            return
        want = self._want_lock(u, p)
        dirty = self.state.data.setdefault('lock_dirty', [])
        try:
            if want and (want[0] or want[1]):
                warn = self.backend.lock_clocks(u, want[0], want[1])
                if u not in dirty:
                    dirty.append(u)
                    self.state.save()
                if warn:
                    log.warning('карта %s: %s', u, warn)
            elif u in dirty:
                self.backend.unlock_clocks(u)
                dirty.remove(u)
                self.state.save()
        except BackendError as e:
            log.warning('фиксация частот карты %s: %s', u, e)

    def _drop_lock(self, u: str, why) -> bool:
        sl = self.stored_lock(u)
        if not sl or u in self.lock_override:
            return False
        self._lock_set(u, None, None, f'снята после сбоя ({why})')
        self.notify(L(self.lang, f"Карта {self.label(u)}: сбой ({why}) при зафиксированных частотах (ядро {sl[0] or '-'}, память {sl[1] or '-'}). Фиксация снята, пресет не тронут. Повторить подбор: /params {self.gpus[u].slot} 4.", f"Card {self.label(u)}: failure ({why}) with locked clocks (core {sl[0] or '-'}, memory {sl[1] or '-'}). Lock removed, preset untouched. Redo the search: /params {self.gpus[u].slot} 4."))
        return True

    def cmd_params(self, target: str='all', n=None) -> None:
        if self._trial_block('Режим «4 параметра»', '4-parameter mode'):
            return
        try:
            n = int(n)
        except (TypeError, ValueError):
            n = 0
        if n not in (2, 4):
            status = ', '.join((f'{self.label(u)}: {self.params_of(u)}' for u in sorted(self.gpus, key=lambda x: self.gpus[x].slot)))
            self.notify(L(self.lang, 'Формат: /params 3 4 (карта 3: 4 параметра) | /params all 4 | /params 3 2 (вернуть 2 параметра). Сейчас: ' + (status or 'карт нет'), 'Format: /params 3 4 (card 3: 4 parameters) | /params all 4 | /params 3 2 (back to 2 parameters). Now: ' + (status or 'no cards')))
            return
        if target in (None, '', 'all'):
            cand = list(self.gpus)
        else:
            u = self.resolve(target)
            if not u:
                self.notify(self.not_found_msg(target))
                return
            cand = [u]
        pm = self.state.data.setdefault('params', {})
        todo = self.state.data.setdefault('lock_todo', [])
        key = self.lock_key()
        for u in cand:
            (self.state.data.get('locks') or {}).get(u, {}).pop(key, None)
            self._mirror_lock(u)
            if n == 4:
                pm[u] = 4
                if u not in todo:
                    todo.append(u)
            else:
                pm.pop(u, None)
                if u in todo:
                    todo.remove(u)
        self.state.save()
        names = ', '.join((self.label(u) for u in cand))
        if n == 4:
            self.notify(L(self.lang, f'4 параметра для {names}: на готовом пресете бот подберёт фиксацию частоты ядра и памяти (по одной карте за раз, сравнение с пресетом без фиксации длинными замерами, принимается при выигрыше выше порога {self.opt_gain():.1%}). Для каждого алгоритма и майнера подбор отдельный.', f'4 parameters for {names}: on the finished preset the bot will search for a core/memory clock lock (one card at a time, compared against the unlocked preset with long measurements, accepted at a gain above {self.opt_gain():.1%}). The search is separate for each algo and miner.'))
        else:
            self.notify(L(self.lang, f'2 параметра для {names}: фиксация частот снимается, пресет остаётся как был.', f'2 parameters for {names}: the clock lock is removed, the preset stays as it was.'))

    def _lock_step(self) -> None:
        if self.halted or self.pending or (not hasattr(self.backend, 'lock_clocks')):
            return
        for u in list(self.state.data.get('lock_dirty') or []):
            if u in self.gpus and (not self.stored_lock(u)) and (u not in self.lock_override):
                try:
                    self.backend.unlock_clocks(u)
                    self.state.data['lock_dirty'].remove(u)
                    self.state.save()
                except BackendError as e:
                    log.warning('не удалось снять фиксацию частот %s: %s', u, e)
        todo = self.state.data.setdefault('lock_todo', [])
        for u in self.gpus:
            v = self._verified(u)
            if self.params_of(u) == 4 and v and (not self._lock_valid(u, v)) and (v['core_lock'] or v['mem_lock']):
                self._lock_set(u, v['core_lock'], v['mem_lock'], 'из базы')
            if self.params_of(u) == 4 and u not in todo and v and (not self._lock_valid(u, v)):
                todo.append(u)
        for u in list(todo):
            if u not in self.gpus or self.params_of(u) != 4:
                todo.remove(u)
                continue
            if not (self._usable(u) and self._verified(u)) or self._fragile(u):
                continue
            todo.remove(u)
            self.state.save()
            try:
                msg = self.lock_card(self.gpus[u])
            except Stopped:
                self.lock_override.pop(u, None)
                todo.insert(0, u)
                self.state.save()
                raise
            self.notify(msg)
            return
        for u in self.gpus:
            if not (self._lift_due(u) and self._usable(u) and (not self._fragile(u))):
                continue
            try:
                msg = self.lift_card(self.gpus[u])
            except Stopped:
                self.lock_override.pop(u, None)
                self.lift_override.pop(u, None)
                raise
            if msg:
                self.notify(msg)
            break

    def _lift_extra(self, u: str, p: Point) -> int:
        if u in self.lift_override:
            return int(self.lift_override[u])
        if u in self.lock_override:
            return 0
        sl, v = (self.stored_lock(u), self._verified(u))
        if sl and sl[0] and v and ((int(v['core_offset']), int(v['mem_offset'])) == (p.core, p.mem)):
            return int((self._lock_entry(u) or {}).get('lift') or 0)
        return 0

    def _lock_patch(self, u: str, **kv) -> None:
        e = self._lock_entry(u)
        if e is not None:
            e.update(kv)
            self.state.save()

    def _lift_due(self, u: str) -> bool:
        c = self.cfg
        if not c.lock_lift or 'rgminer' not in (c.miner or '').lower() or self.params_of(u) != 4:
            return False
        sl, e = (self.stored_lock(u), self._lock_entry(u))
        return bool(sl and sl[0] and e and (not e.get('lift_done')) and self._verified(u))

    def lift_card(self, g) -> str:
        cfg, u = (self.cfg, g.uuid)
        lang = self.lang
        v, name, step = (self._verified(u), self.label(u), max(1, cfg.lock_lift_step))
        sl, e = (self.stored_lock(u), self._lock_entry(u))
        if not (v and sl and sl[0] and e):
            return ''
        cur = Point(int(v['core_offset']), int(v['mem_offset']), int(v['power_limit']), cfg.fan)
        long_w = int(cfg.window_s * cfg.opt_window_mult)
        ref_eff = float(e.get('eff') or 0.0)
        ref_hr = float(e.get('hr') or 0.0)
        base_eff = ref_eff
        crashed = [False]

        def probe(b, dur):
            self.lock_override[u] = sl
            self.lift_override[u] = b
            self.state.data.setdefault('lock_stage', {})[u] = {'core': sl[0], 'mem': sl[1], 'lift': b}
            self.state.save()
            try:
                return self._measure_search(g, cur, dur, note=f'lockoff{b}')
            finally:
                self.lock_override.pop(u, None)
                self.lift_override.pop(u, None)
                self.state.data.get('lock_stage', {}).pop(u, None)

        def failed(b, res) -> None:
            e['lift_bad'] = b if e.get('lift_bad') is None else min(int(e['lift_bad']), b)
            self.state.save()
            self.apply_safe(u)
            if res.status == 'crash':
                crashed[0] = True
                self.escalate(u, res.cause, stock=False, short=res.cause == 'bus_lost')
        self.set_phase(L(lang, f'подъём оффсета при фиксации карты {name}', f'raising the offset with the lock on card {name}'))
        self.notify(L(lang, f'Карта {name}: подъём оффсета ядра при фиксации {sl[0]} МГц (шаг {step}, до +{cfg.lock_lift_max}); на сбое откат на {cfg.lock_lift_margin} МГц.', f'Card {name}: raising the core offset with a {sl[0]} MHz lock (step {step}, up to +{cfg.lock_lift_max}); on failure, rolling back by {cfg.lock_lift_margin} MHz.'))
        try:
            if e.get('lift_bad') is None:
                k = int(e.get('lift_ok', 0)) // step + 1
                while k * step <= cfg.lock_lift_max and (not self.halted):
                    b = k * step
                    res = probe(b, cfg.window_s)
                    good = bool(res.status == 'ok' and res.hashrate and (not ref_eff or not res.eff or res.eff >= ref_eff * 0.97) and (not ref_hr or res.hashrate >= ref_hr * 0.97))
                    if not good:
                        failed(b, res)
                        break
                    e['lift_ok'] = b
                    self.state.save()
                    if res.eff:
                        ref_eff = max(ref_eff, float(res.eff))
                    k += 1
            if crashed[0]:
                return L(lang, f'{name}: сбой на подъёме оффсета, карта восстанавливается; итог подберу после.', f"{name}: failure while raising the offset, the card is recovering; I'll settle the result later.")
            bad, ok_b = (e.get('lift_bad'), int(e.get('lift_ok', 0)))
            margin = cfg.lock_lift_margin if bad is not None else step
            cand = ok_b if bad is None else min(ok_b, int(bad) - margin)
            cand = max(0, cand // step * step)
            if cand <= 0:
                self._lock_patch(u, lift=0, lift_done=True)
                return L(lang, f'{name}: при фиксации {sl[0]} МГц подъём оффсета выше пресета ({cur.core}) запаса не дал, остаётся {cur.core}.', f'{name}: with the {sl[0]} MHz lock, raising the offset above the preset ({cur.core}) gained nothing, staying at {cur.core}.')
            res = probe(cand, long_w)
            ok = bool(res.status == 'ok' and res.hashrate and (not ref_hr or res.hashrate >= ref_hr * 0.99) and (not base_eff or not res.eff or res.eff >= base_eff * 0.99))
            if not ok:
                failed(cand, res)
                return L(lang, f'{name}: оффсет +{cand} не прошёл проверку длинным замером, повторю с меньшим.', f'{name}: offset +{cand} failed the long-measurement check, retrying with a smaller one.')
            self._lock_patch(u, lift=cand, lift_done=True, lift_hr=round(float(res.hashrate), 2), lift_eff=round(float(res.eff or 0.0), 4))
            try:
                self.apply(u, cur)
            except BackendError as exc:
                log.warning('не удалось применить оффсет при фиксации %s: %s', u, exc)
            return L(lang, f'{name}: оффсет при фиксации принят: core {cur.core} + {cand} = {cur.core + cand} при зафиксированном ядре {sl[0]} МГц, хешрейт {float(res.hashrate):.1f}, эффективность {float(res.eff or 0):.3f}. Упадёт карта с фиксацией, бот снимет и фиксацию, и этот оффсет.', f'{name}: offset accepted with the lock: core {cur.core} + {cand} = {cur.core + cand} with a locked core of {sl[0]} MHz, hashrate {float(res.hashrate):.1f}, efficiency {float(res.eff or 0):.3f}. If the card crashes with the lock, the bot will remove both the lock and this offset.')
        finally:
            self.lock_override.pop(u, None)
            self.lift_override.pop(u, None)

    def _lock_range(self, g) -> tuple:
        c = self.cfg
        if 'rgminer' in (c.miner or '').lower() and re.search('RTX\\s*30\\d\\d', g.model or ''):
            return (c.lock_rgminer_floor, c.lock_rgminer_span)
        return (c.lock_core_floor, c.lock_core_span)

    def lock_card(self, g) -> str:
        cfg, u = (self.cfg, g.uuid)
        lang = self.lang
        v = self._verified(u)
        name = self.label(u)
        if not v:
            return L(lang, f'{name}: пресета нет, фиксацию подберу после него.', f"{name}: no preset yet, I'll search for the lock after it.")
        thr = self.opt_gain()
        obj, tol = self.obj_of(u)
        frozen = self.insensitive_axes(obj, g.model)
        cur = Point(int(v['core_offset']), int(v['mem_offset']), int(v['power_limit']), cfg.fan)
        long_w = int(cfg.window_s * cfg.opt_window_mult)
        spent, stop = ([0], [False])

        def meas(core, mem, dur):
            spent[0] += 1
            self.lock_override[u] = (core, mem)
            self.state.data.setdefault('lock_stage', {})[u] = {'core': core, 'mem': mem}
            self.state.save()
            try:
                res = self._measure_search(g, cur, dur, note='lock')
            finally:
                self.lock_override.pop(u, None)
            if res.status == 'crash':
                stop[0] = True
                self._lock_set(u, None, None, f'карта упала при пробе фиксации ядро {core}, память {mem}')
                self.state.data.get('lock_stage', {}).pop(u, None)
                self.state.save()
                self.apply_safe(u)
                self.escalate(u, res.cause, stock=False, short=res.cause == 'bus_lost')
                self.notify(L(lang, f'Карта {name}: сбой при пробе фиксации (ядро {core}, память {mem}). Подбор фиксации прекращён, пресет остаётся без неё.', f'Card {name}: failure while probing the lock (core {core}, memory {mem}). Lock search stopped, the preset stays without it.'))
            else:
                self.state.data.get('lock_stage', {}).pop(u, None)
            return res
        self.notify(L(lang, f'Карта {name}: подбор фиксации частот на пресете core {cur.core}, mem {cur.mem}, PL {cur.pl} (цель {obj}).', f'Card {name}: searching for a clock lock on preset core {cur.core}, mem {cur.mem}, PL {cur.pl} (target {obj}).'))
        self._enter_boost(g)
        tried, outcome = ({}, None)
        try:
            self.set_phase(L(lang, f'подбор фиксации частот карты {name}: замер пресета без фиксации', f'searching clock lock for card {name}: measuring the preset unlocked'))
            base1 = meas(None, None, long_w)
            if base1.status != 'ok' or stop[0]:
                return L(lang, f'{name}: пресет не измерился ({base1.status}), подбор фиксации пропущен.', f"{name}: the preset didn't measure ({base1.status}), lock search skipped.")
            clk = self.backend.clocks(u)
            if not clk:
                return L(lang, f'{name}: не удалось прочитать текущие частоты карты, подбор фиксации пропущен.', f"{name}: couldn't read the card's current clocks, lock search skipped.")
            cur_gr, cur_mem = clk
            sup = self.backend.supported_clocks(u) or {}
            gr_opts = sup.get(cur_mem) or sorted({x for lst in sup.values() for x in lst})
            known_eff = [float(e) for *_, e in self.db.curve_points(u, cfg.algo, cfg.miner, cfg.miner_version, self.driver) if e]
            ref_eff = max([base1.eff or 0.0] + known_eff)
            b1 = self._opt_score(base1, obj, tol, ref_eff) or 0.0

            def trial(core, mem):
                res = meas(core, mem, cfg.window_s)
                sc = self._opt_score(res, obj, tol, ref_eff)
                tried[core, mem] = sc
                return sc
            best_core, best_sc = (None, b1)
            worse = 0
            self.set_phase(L(lang, f'подбор фиксации частот карты {name}: частота ядра', f'searching clock lock for card {name}: core frequency'))
            floor, span = self._lock_range(g)
            for c in clocklock.core_candidates(cur_gr, gr_opts, cfg.lock_core_step * cfg.lock_core_stride, span, floor):
                if stop[0] or self.halted or spent[0] >= cfg.lock_max_points:
                    break
                sc = trial(c, None)
                if sc is not None and sc > best_sc:
                    best_core, best_sc, worse = (c, sc, 0)
                else:
                    worse += 1
                    if worse >= 2:
                        break
            if best_core and (not stop[0]):
                for c in clocklock.refine_candidates(best_core, [k[0] for k in tried], gr_opts, cfg.lock_core_step, floor):
                    if stop[0] or spent[0] >= cfg.lock_max_points:
                        break
                    sc = trial(c, None)
                    if sc is not None and sc > best_sc:
                        best_core, best_sc = (c, sc)
            self.set_phase(L(lang, f'подбор фиксации частот карты {name}: частота памяти', f'searching clock lock for card {name}: memory frequency'))
            best_mem = None
            if sup and (not stop[0]):
                mems = clocklock.mem_candidates(cur_mem, sorted(sup), 'mem' not in frozen, cfg.lock_mem_count)
                if 'rgminer' in (cfg.miner or '').lower():
                    ref = clocklock.nearest(5000, sorted(sup))
                    if abs(ref - 5000) <= 100 and ref != cur_mem and (ref not in mems):
                        mems.append(ref)
                for m in mems:
                    if stop[0] or self.halted or spent[0] >= cfg.lock_max_points:
                        break
                    sc = trial(best_core, m)
                    if sc is not None and sc > best_sc:
                        best_mem, best_sc = (m, sc)
            finalists = sorted(((sc, k) for k, sc in tried.items() if sc is not None and sc > b1 * (1 + thr / 2)), key=lambda t: -t[0])[:2]
            finals = []
            if finalists and (not stop[0]):
                self.set_phase(L(lang, f'подбор фиксации частот карты {name}: финал, длинные замеры', f'searching clock lock for card {name}: final, long measurements'))
                for _, (c, m) in finalists:
                    if stop[0]:
                        break
                    res = meas(c, m, long_w)
                    sc = self._opt_score(res, obj, tol, ref_eff)
                    if sc is not None:
                        finals.append((sc, (c, m), res))
                base2 = meas(None, None, long_w) if not stop[0] else None
                b2 = (self._opt_score(base2, obj, tol, ref_eff) if base2 and base2.status == 'ok' else None) or b1
                base_ref = (b1 + b2) / 2
                winners = sorted((t for t in finals if t[0] >= base_ref * (1 + thr)), key=lambda t: -t[0])
                outcome = ('win', winners[0], base_ref) if winners else ('none', max((t[0] for t in finals), default=0.0), base_ref)
        finally:
            self.lock_override.pop(u, None)
            self._exit_boost()
        if stop[0]:
            return L(lang, f'{name}: подбор фиксации прерван сбоем, пресет остаётся без фиксации.', f'{name}: lock search interrupted by a failure, the preset stays unlocked.')
        if not outcome or outcome[0] == 'none':
            best = (outcome[1] / outcome[2] - 1) * 100 if outcome and outcome[2] else 0.0
            self._lock_set(u, None, None, 'выигрыша нет', cur_gr=cur_gr, cur_mem=cur_mem)
            return L(lang, f'{name}: фиксация частот выигрыша выше порога {thr:.1%} не дала (лучшая точка {best:+.1f}%, замеров {spent[0]}), пресет остаётся без фиксации (рабочая частота ядра {cur_gr}, памяти {cur_mem} МГц).', f'{name}: a clock lock gave no gain above the {thr:.1%} threshold (best point {best:+.1f}%, {spent[0]} points measured), the preset stays unlocked (current core {cur_gr}, memory {cur_mem} MHz).')
        sc, (c, m), res = outcome[1]
        gain = (outcome[1][0] / outcome[2] - 1) * 100
        self._lock_set(u, c, m, 'принята', hr=res.hashrate, eff=res.eff, gain=round(gain, 2), cur_gr=cur_gr, cur_mem=cur_mem)
        try:
            self.apply(u, cur)
        except BackendError as e:
            log.warning('не удалось применить фиксацию %s: %s', u, e)
        return L(lang, f"{name}: фиксация частот принята: ядро {c or 'без фиксации'}, память {m or 'без фиксации'} МГц (было {cur_gr}/{cur_mem}), цель {obj} лучше пресета на {gain:+.1f}%, хешрейт {float(res.hashrate or 0):.1f}, эффективность {float(res.eff or 0):.3f}. Если карта упадёт с фиксацией, бот её снимет.", f"{name}: clock lock accepted: core {c or 'unlocked'}, memory {m or 'unlocked'} MHz (was {cur_gr}/{cur_mem}), target {obj} beats the preset by {gain:+.1f}%, hashrate {float(res.hashrate or 0):.1f}, efficiency {float(res.eff or 0):.3f}. If the card crashes with the lock, the bot will remove it.")

    def _fragile(self, u: str) -> bool:
        c = self.cfg
        return self.db.recent_extend_crashes(u, c.algo, c.miner, c.miner_version, c.balance_skip_crash_hours) > 0

    def _has_data(self, model: str='') -> bool:
        c = self.cfg
        return self.db.one("select 1 from runs where algo=? and miner=? and miner_version=? and status='ok' and coalesce(note,'')!='probe' and gpu_uuid in (select uuid from gpus where model=?) limit 1", (c.algo, c.miner, c.miner_version, model)) is not None

    def _pl_limited(self, u: str) -> bool:
        v = self._verified(u)
        if not v or self.pl_lock(u):
            return False
        _, _, hi = self.pl_limits(u)
        return hi < self._raw_pl(u)[2] and v['power_limit'] >= hi - 2 * self.cfg.step_pl

    def _frontier(self, u: str) -> list:
        cfg = self.cfg
        args = (u, cfg.algo, cfg.miner, cfg.miner_version, self.driver)
        hard = [Point(*t, cfg.fan) for t in self.db.crash_points(*args, same=True)]
        lo, hi = (self._raw_pl(u)[0], self._raw_pl(u)[2]) if u in self.gpus else (0, 10 ** 6)
        opts = []
        for c, m, p, h, e in self.db.curve_points(*args):
            pt = Point(c, m, p, cfg.fan)
            if lo <= p <= hi and (not dominated(pt, hard)):
                opts.append((int(p), float(h), (pt, float(e or 0))))
        return balance.frontier(opts)

    def _plan(self, uuids: list, grp):
        cfg, opts = (self.cfg, {})
        for u in uuids:
            fr, lock, v = (self._frontier(u), self.pl_lock(u), self._verified(u))
            if lock:
                under = [o for o in fr if o[0] <= lock]
                if under:
                    pt, e = under[-1][2]
                    opts[u] = [(lock, under[-1][1], (replace(pt, pl=lock), e))]
                elif v:
                    opts[u] = [(lock, float(v['hashrate'] or 0), (Point(v['core_offset'], v['mem_offset'], lock, cfg.fan), 0.0))]
                else:
                    return None
            elif fr:
                opts[u] = fr
            elif v:
                opts[u] = [(int(v['power_limit']), float(v['hashrate'] or 0), (Point(v['core_offset'], v['mem_offset'], v['power_limit'], cfg.fan), float(v['efficiency'] or 0)))]
            else:
                return None
        budget = int(self.psu.budget(grp) / cfg.psu_transient)
        for u, g in self.gpus.items():
            if u not in uuids and self.psu.group_of(g.slot) is grp:
                v = self._verified(u)
                budget -= int(v['power_limit']) if v else self.pl_limits(u)[0]
        if budget <= 0:
            return None
        return (balance.allocate(opts, budget), opts, budget)

    def balance_report(self, unit: str='') -> str:
        lang = self.lang
        u_ = ' ' + unit if unit else ''
        rows = [r for r in self.db.q('select uuid, current_slot from gpus where current_rig=? order by current_slot', (self.cfg.rig_name,))]
        lines, tot_max, tot_now, has_untuned = ([], 0.0, 0.0, False)
        if lang == 'en':
            for r in rows:
                u = r['uuid']
                v, fr = (self._verified(u), self._frontier(u))
                if not v:
                    now_h = 0.0
                    try:
                        now_h = float(self.backend.sample(u).hashrate or 0) if u in self.gpus else 0.0
                    except Exception:
                        pass
                    tot_now += now_h
                    has_untuned = True
                    lines.append(f"{self.label_slot(u, r['current_slot'])}: no preset yet, now {now_h:.1f}{u_}")
                    continue
                now_h, now_pl = (float(v['hashrate'] or 0), int(v['power_limit']))
                top = fr[-1] if fr else (now_pl, now_h, None)
                top_h, top_pl = (max(top[1], now_h), top[0])
                tot_max, tot_now = (tot_max + top_h, tot_now + now_h)
                loss = (1 - now_h / top_h) * 100 if top_h else 0.0
                what = f'PL ceiling {self.pl_limits(u)[2]} W' if u in self.gpus else ''
                lines.append(f"{self.label_slot(u, r['current_slot'])}: max {top_h:.1f}{u_} at PL {top_pl} W, now {now_h:.1f}{u_} at PL {now_pl} W" + (f" (−{loss:.1f}%: hitting the power limit{(', ' + what if what else '')})" if loss >= 0.5 else ' (limit not a factor)'))
            if not lines:
                return 'No card data yet.'
            head = f"Card hashrate: max from measurements and how it's running now (target {self.cfg.objective})"
            if tot_max:
                lines.append(f"Total: max {tot_max:.1f}{u_}, now {tot_now:.1f}{u_} ({100 * tot_now / tot_max:.1f}%). Each card's max is only reachable if the PSU budget allows all of them at once." + (" (cards with no preset yet count toward 'now' but not toward 'max'.)" if has_untuned else ''))
            if self.psu.configured and len(self.gpus) > 1:
                for grp in self.psu.groups:
                    mem = [u for u in self._hash_cards(self.gpus) if self.psu.group_of(self.gpus[u].slot) is grp and self._usable(u)]
                    plan = self._plan(mem, grp) if len(mem) > 1 else None
                    if plan and plan[0]:
                        pred = sum((o[1] for o in plan[0].values()))
                        lines.append(f'{grp.name}: the best limit split {plan[2]} W gives {pred:.1f}{u_} by measurement.')
            if not self._hash_cards(self.gpus):
                lines.append('Power distribution by card potential works in hashrate mode (/mode hashrate, or per card /mode 3 hashrate).')
            return head + '\n' + '\n'.join(lines)
        for r in rows:
            u = r['uuid']
            v, fr = (self._verified(u), self._frontier(u))
            if not v:
                now_h = 0.0
                try:
                    now_h = float(self.backend.sample(u).hashrate or 0) if u in self.gpus else 0.0
                except Exception:
                    pass
                tot_now += now_h
                has_untuned = True
                lines.append(f"{self.label_slot(u, r['current_slot'])}: пресета пока нет, сейчас {now_h:.1f}{u_}")
                continue
            now_h, now_pl = (float(v['hashrate'] or 0), int(v['power_limit']))
            top = fr[-1] if fr else (now_pl, now_h, None)
            top_h, top_pl = (max(top[1], now_h), top[0])
            tot_max, tot_now = (tot_max + top_h, tot_now + now_h)
            loss = (1 - now_h / top_h) * 100 if top_h else 0.0
            what = f'потолок PL {self.pl_limits(u)[2]} Вт' if u in self.gpus else ''
            lines.append(f"{self.label_slot(u, r['current_slot'])}: максимум {top_h:.1f}{u_} при PL {top_pl} Вт, сейчас {now_h:.1f}{u_} при PL {now_pl} Вт" + (f" (−{loss:.1f}%: упирается в лимит мощности{(', ' + what if what else '')})" if loss >= 0.5 else ' (лимит не мешает)'))
        if not lines:
            return 'Пока нет данных по картам.'
        head = f'Хешрейт карт: максимум по замерам и как работает сейчас (цель {self.cfg.objective})'
        if tot_max:
            lines.append(f'Сумма: максимум {tot_max:.1f}{u_}, сейчас {tot_now:.1f}{u_} ({100 * tot_now / tot_max:.1f}%). Максимум каждой карты достижим только если лимит блока питания позволяет всем сразу.' + (' (карты без пресета учтены в «сейчас», но не в «максимум».)' if has_untuned else ''))
        if self.psu.configured and len(self.gpus) > 1:
            for grp in self.psu.groups:
                mem = [u for u in self._hash_cards(self.gpus) if self.psu.group_of(self.gpus[u].slot) is grp and self._usable(u)]
                plan = self._plan(mem, grp) if len(mem) > 1 else None
                if plan and plan[0]:
                    pred = sum((o[1] for o in plan[0].values()))
                    lines.append(f'{grp.name}: лучшее распределение лимита {plan[2]} Вт даёт по замерам {pred:.1f}{u_}.')
        if not self._hash_cards(self.gpus):
            lines.append('Распределение мощности по потенциалу карт работает в режиме hashrate (/mode hashrate, или для отдельных карт /mode 3 hashrate).')
        return head + '\n' + '\n'.join(lines)

    def start_balance(self, deep: bool=False) -> None:
        cfg, lang = (self.cfg, self.lang)
        if not (cfg.rig_balance and self.psu.configured):
            self.notify(L(lang, 'Распределение мощности выключено или не описан блок питания (psu_watts / psu_groups).', 'Power distribution is off, or no PSU is described (psu_watts / psu_groups).'))
        elif not self._hash_cards(self.gpus):
            self.notify(L(lang, 'Распределение мощности работает для карт в режиме hashrate: сначала /mode hashrate (или /mode 3 hashrate для одной карты).', 'Power distribution works for cards in hashrate mode: run /mode hashrate first (or /mode 3 hashrate for one card).'))
        elif self.pl_flat():
            self.notify(L(lang, 'Проба показала, что хешрейт этого алгоритма почти не зависит от PL: перераспределять мощность нечего.', "The probe showed this algorithm's hashrate barely depends on PL: nothing to redistribute."))
        else:
            self.state.data['balance'] = {'phase': 'pending', 'done': [], 'deep': bool(deep)}
            self.state.save()
            self.notify(L(lang, 'Распределение мощности запущено' + (' (плотный режим)' if deep else '') + ': когда у всех карт будут готовые пресеты, бот найдёт максимум каждой карты при свободном лимите и раздаст общий лимит так, чтобы суммарный хешрейт был наибольшим.', 'Power distribution started' + (' (deep mode)' if deep else '') + ": once every card has a ready preset, the bot will find each card's maximum at an unrestricted limit and split the total limit so total hashrate is highest."))

    def _balance_step(self, searched: bool) -> None:
        cfg = self.cfg
        bal = self.state.data.get('balance') or {}
        active = cfg.rig_balance and bool(self._hash_cards(self.gpus)) and self.psu.configured and (not self.pl_flat())
        if searched and active and (bal.get('phase') in (None, 'idle')):
            bal = self.state.data['balance'] = {'phase': 'pending', 'done': []}
            self.state.save()
        if bal.get('phase') not in ('pending', 'boost'):
            return
        if not active:
            self.state.data['balance'] = {'phase': 'idle', 'done': []}
            self.state.save()
            return
        cards = [u for u in self._hash_cards(self.gpus) if self._usable(u)]
        if self.pending or self.halted or (not cards) or any((self._verified(u) is None for u in cards)):
            return
        self._balance_run(cards, bal)

    def _balance_run(self, cards: list, bal: dict) -> None:
        lang = self.lang
        if bal['phase'] == 'pending':
            if not any((self._pl_limited(u) for u in cards)) and (not self.state.data.get('alloc')):
                self.state.data['balance'] = {'phase': 'idle', 'done': []}
                self.state.save()
                self.notify(L(lang, 'Лимит мощности не ограничивает ни одну карту (все работают ниже своей доли): перераспределять нечего.', "The power limit isn't constraining any card (all run below their share): nothing to redistribute."))
                return
            bal.update(phase='boost', done=[])
            self.state.save()
        todo = sorted((u for u in cards if u not in bal['done']), key=lambda u: -float((self._verified(u) or {'hashrate': 0})['hashrate'] or 0))
        for u in todo:
            if self.halted:
                return
            if self._pl_limited(u) and self._fragile(u):
                self.notify(L(lang, f'Карта {self.label(u)}: при расширении потолка уже роняла риг, повторно не мучаю (пробуем снова через {self.cfg.balance_skip_crash_hours} ч или после /newsearch).', f'Card {self.label(u)}: already crashed the rig while extending the ceiling, not retrying now (will try again in {self.cfg.balance_skip_crash_hours}h or after /newsearch).'))
            elif self._pl_limited(u):
                self.notify(L(lang, f'Карта {self.label(u)}: упирается в потолок PL. Расширяю потолок: поднимаю PL, пока хешрейт растёт; остальным карты PL снижается ровно настолько, чтобы уложиться в лимит блока питания.', f"Card {self.label(u)}: hitting the PL ceiling. Extending the ceiling: raising PL while hashrate keeps growing; other cards' PL is lowered just enough to fit the PSU budget."))
                self._extend_ceiling(self.gpus[u], deep=bool(bal.get('deep')))
            bal['done'].append(u)
            self.state.save()
        self._allocate_rig(cards)
        self.state.data['balance'] = {'phase': 'idle', 'done': []}
        self.state.save()

    def _allocate_rig(self, cards: list) -> None:
        lang = self.lang
        self.set_phase(L(lang, 'распределение мощности между картами', 'distributing power between cards'))
        cfg = self.cfg
        queued = False
        checks = []
        for grp in self.psu.groups:
            mem = [u for u in cards if self.psu.group_of(self.gpus[u].slot) is grp]
            if len(mem) < 2:
                continue
            plan = self._plan(mem, grp)
            if plan is None or plan[0] is None:
                self.notify(L(lang, f'{grp.name}: не удалось распределить лимит: нет данных по картам или они не помещаются в бюджет.', f"{grp.name}: couldn't distribute the limit: no card data, or they don't fit the budget."))
                continue
            pick, opts, budget = plan
            cur = sum((float((self._verified(u) or {'hashrate': 0})['hashrate'] or 0) for u in mem))
            pred = sum((o[1] for o in pick.values()))
            if cur > 0 and pred < cur * (1 + cfg.balance_min_gain):
                for u in mem:
                    (self.state.data.get('alloc') or {}).pop(u, None)
                self.state.save()
                self.notify(L(lang, f'{grp.name}: распределение по потенциалу карт не даёт заметного выигрыша (прогноз {pred:.1f} против текущих {cur:.1f}), пресеты оставлены.', f'{grp.name}: distributing by card potential gives no noticeable gain (forecast {pred:.1f} vs current {cur:.1f}), presets left unchanged.'))
                continue
            alloc = self.state.data.setdefault('alloc', {})
            for u in mem:
                alloc[u] = int(pick[u][0])
            self.state.save()
            lines = []
            for u in mem:
                v = self._verified(u)
                cur_hr = float(v['hashrate'] or 0) if v else 0.0
                lines.append(f"{self.label(u)}: PL {(int(v['power_limit']) if v else '?')} -> {pick[u][0]} Вт, хешрейт {cur_hr:.1f} -> {pick[u][1]:.1f}")
                pt, e = pick[u][2]
                main = self._clamp(u, shift_safe(pt, self.steps, self.bounds(u), cfg.safety_steps))
                cands, seen = ([(main, e)], {main.key()})
                alts = sorted((o for o in opts[u] if o[0] <= pick[u][0] and o is not pick[u]), key=lambda o: -o[1])
                for o in alts[:cfg.balance_fallbacks]:
                    q = self._clamp(u, shift_safe(o[2][0], self.steps, self.bounds(u), cfg.safety_steps))
                    if q.key() not in seen:
                        seen.add(q.key())
                        cands.append((q, o[2][1]))
                if v and int(v['power_limit']) <= pick[u][0]:
                    q = self._clamp(u, Point(v['core_offset'], v['mem_offset'], v['power_limit'], cfg.fan))
                    if q.key() not in seen:
                        cands.append((q, float(v['efficiency'] or 0)))
                self.pending[u] = cands
                self.pending_gen[u] = self.mode_gen
                self.bg_progress.pop(u, None)
            checks.append((grp, mem, cur, {u: self._pid(u) for u in mem}))
            self.notify(L(lang, f'{grp.name}: общий лимит {budget} Вт раздаю по потенциалу карт, прогноз суммарного хешрейта {pred:.1f} против {cur:.1f}. ' + '; '.join(lines) + '. Новые настройки проходят 2-часовую проверку на всех картах.', f'{grp.name}: distributing the {budget} W total limit by card potential, forecast total hashrate {pred:.1f} vs {cur:.1f}. ' + '; '.join(lines) + '. New settings are going through a 2-hour check on all cards.'))
            queued = True
        if queued:
            self.run_verifications()
            for grp, mem, before, ids in checks:
                now = sum((float((self._verified(u) or {'hashrate': 0})['hashrate'] or 0) for u in mem))
                if before > 0 and now < before * (1 - cfg.balance_rollback_tol):
                    changed = [u for u in mem if self._pid(u) != ids.get(u)]
                    self.notify(L(lang, f'{grp.name}: после проверки суммарный хешрейт {now:.1f} хуже прежнего {before:.1f}. Возвращаю прежние пресеты ({len(changed)} карт).', f'{grp.name}: after the check, total hashrate {now:.1f} is worse than the previous {before:.1f}. Restoring the previous presets ({len(changed)} cards).'))
                    for u in changed:
                        self.apply_restore(u)
                else:
                    self.notify(L(lang, f'{grp.name}: итог проверки: суммарный хешрейт {now:.1f} против {before:.1f} ({((now / before - 1) * 100 if before else 0):+.1f}%).', f'{grp.name}: check result: total hashrate {now:.1f} vs {before:.1f} ({((now / before - 1) * 100 if before else 0):+.1f}%).'))
            self.notify(L(lang, 'Распределение мощности завершено.\n', 'Power distribution finished.\n') + self.balance_report())

    def process_commands(self) -> None:
        self._poll_control()
        if self.retune_all:
            self.retune_all = False
            self.restored.clear()
            self.state.data['alloc'] = {}
            own = self.state.data.get('card_modes') or {}
            for x in self.gpus:
                if x in own:
                    continue
                self.db.x("update profiles set status='outdated' where gpu_uuid=? and algo=? and miner=? and status in ('verified','imported')", (x, self.cfg.algo, self.cfg.miner))
                self.pending.pop(x, None)
                self.bg_progress.pop(x, None)
        while True:
            try:
                cmd, *args = self.commands.get_nowait()
            except queue.Empty:
                return
            if cmd == 'stop':
                self.halted = True
                self.stop_flag.clear()
                for u in self.gpus:
                    self.apply_safe(u)
                self.notify(L(self.lang, 'Остановлено: безопасный профиль применён. /resume продолжит работу с сохранёнными пресетами, /tune <карта> запустит подбор заново.', 'Stopped: safe profile applied. /resume will continue with the saved presets, /tune <card> will restart the search.'))
            elif cmd == 'safe':
                for u in self.gpus:
                    self.apply_safe(u)
                self.halted = True
                self.notify(L(self.lang, 'Безопасный профиль применён на всех картах, автоматика на паузе (/resume продолжит, /tune запустит подбор заново).', 'Safe profile applied on all cards, automation paused (/resume will continue, /tune will restart the search).'))
            elif cmd == 'pl' and len(args) == 2:
                self.cmd_pl(args[0], str(args[1]))
            elif cmd == 'psu_edit' and args:
                self.psu_edit(list(args))
            elif cmd == 'psu_set' and len(args) >= 2:
                self.set_psu(int(args[0]), int(args[1]), int(args[2]) if len(args) > 2 and args[2] is not None else None)
            elif cmd == 'resume':
                self.halted = False
                self.stop_flag.clear()
                self.notify(L(self.lang, 'Автоматика возобновлена, сохранённые пресеты не сброшены.', 'Automation resumed, the saved presets were not reset.'))
            elif cmd == 'tune':
                self.halted = False
                self.stop_flag.clear()
                u = self.resolve(args[0]) if args else None
                for x in [u] if u else list(self.gpus):
                    self.paused.discard(x)
                    self.restored.discard(x)
                    (self.state.data.get('alloc') or {}).pop(x, None)
                    escalation.reset(self.db, x)
                    self.db.x("update profiles set status='outdated' where gpu_uuid=? and status in ('verified','imported')", (x,))
                    self.pending.pop(x, None)
                self.state.save()
                if u:
                    self.notify(L(self.lang, f'Подбор запущен заново: карта {self.label(u)}.', f'Search restarted for card {self.label(u)}.'))
                else:
                    self.notify(L(self.lang, f'Подбор запущен заново для всех карт (карта {args[0]} не распознана, /status покажет имена).', f'Search restarted for all cards (card {args[0]} not recognized, /status shows the names).'))
            elif cmd == 'update':
                self.cmd_update(str(args[0]) if args else '')
            elif cmd == 'uninstall':
                self.cmd_uninstall(bool(args and args[0]))
            elif cmd == 'balance':
                self.start_balance(bool(args and args[0] == 'deep'))
            elif cmd == 'optimize':
                self.cmd_optimize(str(args[0]) if args else 'all', args[1] if len(args) > 1 else None)
            elif cmd == 'params':
                self.cmd_params(str(args[0]) if args else 'all', args[1] if len(args) > 1 else None)
            elif cmd == 'optimize_gain':
                self.set_opt_gain(args[0] if args else None)
            elif cmd == 'verify':
                u = self.resolve(args[0]) if args else None
                self.force_verify |= {u} if u else set(self.gpus)
            elif cmd == 'faulty':
                u = self.resolve(args[0])
                if u:
                    if args[1]:
                        self.mark_card(u, 'faulty', L(self.lang, 'помечена неисправной вручную', 'marked faulty manually'))
                    else:
                        self.db.set_gpu_status(u, 'ok', L(self.lang, 'метка снята вручную', 'label removed manually'))
                        self.paused.discard(u)
                        escalation.reset(self.db, u)

    def _seed_xids(self) -> None:
        from .backend import system_boot_time
        boot = system_boot_time()
        if boot is None:
            return
        try:
            logged = len(self.read_xid_log(boot))
            self.xid_seen = min(logged, len(self.backend.xids()))
        except Exception as e:
            log.warning('не удалось продолжить чтение Xid с прежнего места: %s', e)

    def hive_mirror_on(self) -> bool:
        return bool(self.state.data.get('hive_mirror', getattr(self.cfg, 'hive_mirror', False)))

    def hive_mirror_tick(self) -> None:
        from . import hivelog
        path = getattr(self.cfg, 'hive_agent_log', '')
        if not path:
            return
        st = getattr(self, '_mirror_state', None)
        if st is None:
            st = self._mirror_state = {}
        lines = hivelog.read_lines(path, st)
        if lines and self.hive_mirror_on():
            for text in hivelog.classify(lines, st):
                self.notify(text)

    def _boot_notice(self) -> None:
        try:
            bt = self.backend.boot_time()
        except Exception:
            bt = None
        if not bt or time.time() - bt > self.cfg.fresh_boot_s:
            return
        last = max([0.0] + list(self.state.data.get('reboots') or []) + list(self.state.data.get('tuning_reboots') or []))
        ours = last > 0 and -120 <= bt - last <= 1200
        lang = self.lang
        why = ''
        if ours:
            rec = self.state.data.get('last_reboot') or {}
            if abs((rec.get('time') or 0) - last) < 2 and rec.get('reason'):
                why = L(lang, ' Причина: ', ' Reason: ') + str(rec['reason'])
        self.notify(L(lang, 'Риг перезагрузился (система загружена ' + time.strftime('%H:%M', time.localtime(bt)) + '). ' + ('Перезагрузку запросил бот.' + why if ours else 'Перезагрузка не по команде бота: вручную, из панели Hive или по питанию.'), 'The rig rebooted (system booted at ' + time.strftime('%H:%M', time.localtime(bt)) + '). ' + ('The bot requested the reboot.' + why if ours else 'Not requested by the bot: manual, from the Hive panel, or a power event.')))

    def startup(self) -> None:
        self._boot_notice()
        self._autofan_ensure()
        if getattr(self.cfg, 'kernel_panic_reboot', False):
            if backend_mod.ensure_kernel_panic(10):
                log.info('kernel.panic=10: при панике ядра риг перезагрузится сам')
        lang = self.lang
        self.set_phase(L(lang, 'запуск: применяю сохранённые пресеты', 'starting up: applying saved presets'))
        self._seed_xids()
        n = sum((getattr(q, 'restored', 0) for _, q in self._queues()))
        drop = [self._qtext(pre, it) + f' ({why})' for pre, q in self._queues() for it, why in getattr(q, 'dropped', [])]
        if n:
            self.notify(L(lang, f'После перезапуска восстановлено невыполненных команд: {n}, они будут выполнены.', f'After restart, {n} unfinished command(s) were restored and will be carried out.'))
        if drop:
            self.notify(L(lang, 'После перезапуска сброшены команды: ' + '; '.join(drop) + '. Если они ещё нужны, отправьте заново.', 'After restart, these commands were dropped: ' + '; '.join(drop) + '. Resend them if still needed.'))
        self.refresh_gpus()
        if not self.psu_guard_ok():
            self.recover_unfinished()
            return
        fresh = self._fresh_boot()
        for u in self.gpus:
            if not fresh and self._verified(u):
                self._apply_preset_or_safe(u)
            else:
                self.apply_safe(u)
        self.recover_unfinished()
        self.apply_pending_delay()

    def _update_check(self) -> None:
        now = self.clock.now()
        ts = self.state.data.get('update_check_ts', 0)
        interval = getattr(self.cfg, 'update_check_s', 86400)
        if now - ts < interval:
            return
        self.state.data['update_check_ts'] = now
        try:
            from . import selfupdate as su
            sha = su.available_update(su.workdir_of_code(), self.cfg.update_url, self.cfg.update_token, self.lang)
        except Exception:
            log.exception('не удалось проверить наличие новой версии бота')
            self.state.save()
            return
        if sha:
            if sha != self.state.data.get('update_notified_sha'):
                self.state.data['update_notified_sha'] = sha
                lang = self.lang
                if getattr(self.cfg, 'token', ''):
                    self.notify(L(lang, 'Вышла новая версия бота. Обновить одной командой прямо здесь: /update (конфиги, база и состояние не тронутся).', 'A new bot version is out. Update it right here with one command: /update (configs, database and state are untouched).'))
                else:
                    cfgname = os.path.basename(getattr(self.cfg, '_path', '') or 'config.json')
                    self.notify(L(lang, f'Вышла новая версия бота. Обновить (конфиги, база и состояние не тронутся): cd /root/ocbot && python3 -m ocbot --config {cfgname} --self-update', f'A new bot version is out. To update (configs, database and state are untouched): cd /root/ocbot && python3 -m ocbot --config {cfgname} --self-update'))
        else:
            self.state.data.pop('update_notified_sha', None)
        self.state.save()

    def cycle(self) -> None:
        self._update_check()
        self.process_commands()
        self.check_workload_change()
        if self.halted:
            self.set_phase(L(self.lang, 'автоматика на паузе (/resume продолжит)', 'automation paused (/resume to continue)'))
            return
        self.refresh_gpus()
        if not self.psu_guard_ok():
            return
        work, recheck, tune = ([], [], [])
        for u, g in self.gpus.items():
            row = self.db.gpu(u)
            if row['status'] == 'faulty' or u in self.paused:
                continue
            self.db.mark_stale(u, g.vbios, self.driver, self.cfg.profile_max_age_days)
            c = self.cfg
            v = self.db.get_profile(u, c.algo, c.miner, c.miner_version, 'verified')
            if v:
                lo, _, hi = self.pl_limits(u)
                if not lo <= v['power_limit'] <= hi:
                    self.db.set_profile_status(v['id'], 'outdated')
                    self.notify(L(self.lang, f"Карта {self.label(u)}: PL пресета ({v['power_limit']} Вт) вне допустимых {lo}..{hi} Вт (замок или бюджет БП), подбираю заново.", f"Card {self.label(u)}: preset PL ({v['power_limit']} W) is outside the allowed {lo}..{hi} W (a lock or PSU budget changed), searching again."))
                    v = None
            if v:
                (recheck if u in self.recheck_needed else work).append((g, v))
                continue
            imp = self.db.get_profile(u, c.algo, c.miner, c.miner_version, 'imported')
            (recheck if imp else tune).append((g, imp) if imp else g)
        for g, v in work:
            self._apply_if_visible(g.uuid, Point(v['core_offset'], v['mem_offset'], v['power_limit'], self.cfg.fan))
        self.run_rechecks(recheck)
        for g in tune:
            if g.uuid not in self.paused and (not self.halted):
                self.search(g)
        self.run_verifications()
        if self.force_verify:
            todo, self.force_verify = (list(self.force_verify), set())
            self.verify_existing(todo)
        self._balance_step(bool(tune))
        self._optimize_step()
        self._lock_step()

    @staticmethod
    def _dur(sec: float, lang: str='ru') -> str:
        sec = max(0, int(sec))
        if lang == 'en':
            if sec < 90:
                return f'{sec}s'
            m = sec // 60
            return f'{m}m' if m < 120 else f'{m // 60}h {m % 60}m'
        if sec < 90:
            return f'{sec} с'
        m = sec // 60
        return f'{m} мин' if m < 120 else f'{m // 60} ч {m % 60} мин'

    def _idle_text(self) -> str:
        n = len([u for u in self.gpus if self._verified(u)])
        return L(self.lang, f'мониторинг: все карты ({n}) работают на готовых пресетах, состояние проверяется каждые {self.cfg.cycle_idle_s} с' if n == len(self.gpus) else f'ожидание между циклами: на пресетах {n} из {len(self.gpus)}, остальные карты ждут подбора', f'monitoring: all cards ({n}) are running ready presets, checked every {self.cfg.cycle_idle_s}s' if n == len(self.gpus) else f'waiting between cycles: {n} of {len(self.gpus)} cards on presets, the rest are waiting to be tuned')
    MEASURE_KIND = {'search': 'поиск', 'verify': 'проверка', 'recheck': 'перепроверка'}
    MEASURE_NOTE = {'extend': 'расширение потолка / оптимизация', 'probe': 'проба осей', 'scout': 'быстрый проход', 'lock': 'подбор фиксации частот'}
    MEASURE_KIND_EN = {'search': 'search', 'verify': 'verification', 'recheck': 're-check'}
    MEASURE_NOTE_EN = {'extend': 'ceiling extension / optimization', 'probe': 'axis probe', 'scout': 'quick pass', 'lock': 'clock-lock search'}

    def _measure_what(self, kind: str, note) -> str:
        if self.lang == 'en':
            return self.MEASURE_NOTE_EN.get(note) or self.MEASURE_KIND_EN.get(kind, kind)
        return self.MEASURE_NOTE.get(note) or self.MEASURE_KIND.get(kind, kind)

    def card_state(self, u: str) -> str:
        cfg, row, lang = (self.cfg, self.db.gpu(u), self.lang)
        if row and row['status'] == 'faulty':
            return L(lang, 'помечена неисправной', 'marked faulty')
        if u in self.paused:
            return L(lang, 'на паузе', 'paused')
        m, now = (self.measuring, self.clock.now())
        if m and u in m['cards']:
            p = m['cards'][u]
            k = m['kinds'].get(u, m['kind'])
            what = self._measure_what(k, m['note'])
            left = max(0, m['t0'] + m['total'] - now)
            extra = ''
            if k == 'verify' and u in self.pending:
                extra = L(lang, f', проверка {self._dur(self.bg_progress.get(u, 0), lang)} из {self._dur(self.verify_seconds(u), lang)}', f', verification {self._dur(self.bg_progress.get(u, 0), lang)} of {self._dur(self.verify_seconds(u), lang)}')
            return L(lang, f'измеряется ({what}): core {p.core}, mem {p.mem}, PL {p.pl}, окно закончится через ~{self._dur(left, lang)}{extra}', f'measuring ({what}): core {p.core}, mem {p.mem}, PL {p.pl}, window ends in ~{self._dur(left, lang)}{extra}')
        if u in self.pending:
            c = self.pending[u]
            pt = c[0][0]
            return L(lang, f'проверка кандидата core {pt.core}, mem {pt.mem}, PL {pt.pl}: {self._dur(self.bg_progress.get(u, 0), lang)} из {self._dur(self.verify_seconds(u), lang)}, запасных {max(0, len(c) - 1)}', f'checking candidate core {pt.core}, mem {pt.mem}, PL {pt.pl}: {self._dur(self.bg_progress.get(u, 0), lang)} of {self._dur(self.verify_seconds(u), lang)}, {max(0, len(c) - 1)} spare(s)')
        v = self._verified(u)
        if v:
            sl = self.stored_lock(u)
            lf = int((self._lock_entry(u) or {}).get('lift') or 0) if sl else 0
            lk = L(lang, f", фиксация ядро {sl[0] or '-'} / память {sl[1] or '-'} МГц", f", clock lock core {sl[0] or '-'} / mem {sl[1] or '-'} MHz") + (f', оффсет при фиксации +{lf}' if lf and lang != 'en' else f', lock offset +{lf}' if lf else '') if sl else L(lang, ', 4 параметра: фиксация подбирается', ', 4 parameters: clock lock being searched') if self.params_of(u) == 4 else ''
            return L(lang, f"работает на пресете core {v['core_offset']}, mem {v['mem_offset']}, PL {v['power_limit']}{lk}", f"running preset core {v['core_offset']}, mem {v['mem_offset']}, PL {v['power_limit']}{lk}")
        return L(lang, 'пресета нет, ждёт подбора', 'no preset yet, waiting to be tuned')

    def status_text(self, unit: str='TH/s') -> str:
        cfg, now, lang = (self.cfg, self.clock.now(), self.lang)
        obj, tol = (cfg.objective, cfg.eff_tolerance)
        lines = [L(lang, f'Риг {cfg.rig_name}: {cfg.algo}/{cfg.miner} {cfg.miner_version} · цель {obj}', f'Rig {cfg.rig_name}: {cfg.algo}/{cfg.miner} {cfg.miner_version} · target {obj}') + (L(lang, f' (допуск {tol:.0%})', f' (tolerance {tol:.0%})') if obj == 'compromise' else '') + L(lang, ' · автоматика: ', ' · automation: ') + (L(lang, 'НА ПАУЗЕ (/resume продолжит)', 'PAUSED (/resume to continue)') if self.halted else L(lang, 'работает', 'running'))]
        text, since = self.phase
        age = now - self.beat
        alive = '' if age < 120 else L(lang, f' ⚠ главный цикл не подавал признаков жизни {self._dur(age)}: он занят долгой операцией или завис', f" ⚠ the main loop has shown no sign of life for {self._dur(age, lang)}: it's stuck on a long operation or has hung")
        lines.append(L(lang, f'Сейчас: {text} (уже {self._dur(now - since)}).{alive}', f'Now: {text} (for {self._dur(now - since, lang)}).{alive}'))
        m = self.measuring
        if m:
            what = self._measure_what(m['kind'], m['note'])
            left = max(0, m['t0'] + m['total'] - now)
            lines.append(L(lang, f"Окно измерения: {what}, карт {len(m['cards'])}, осталось ~{self._dur(left)} из {self._dur(m['total'])}.", f"Measurement window: {what}, {len(m['cards'])} card(s), ~{self._dur(left, lang)} left of {self._dur(m['total'], lang)}."))
        opt = self.state.data.get('optimize')
        if opt and opt.get('queue'):
            lines.append(L(lang, 'Очередь оптимизации: ', 'Optimization queue: ') + ', '.join((self.label(u) for u in opt['queue'] if u in self.gpus)))
        bal = (self.state.data.get('balance') or {}).get('phase')
        if bal in ('pending', 'boost'):
            lines.append(L(lang, 'Распределение мощности: ' + ('ждёт, пока у всех карт будут готовые пресеты' if bal == 'pending' else 'идёт расширение потолков карт'), 'Power distribution: ' + ('waiting for every card to have a ready preset' if bal == 'pending' else 'extending card ceilings')))
        cm = self._card_modes_text()
        if cm:
            lines.append(cm.lstrip('. ').rstrip('.'))
        ll = self.license_line()
        if ll:
            lines.append(ll)
        th, pw = (0.0, 0.0)
        cards = []
        unit_w = L(lang, 'Вт', 'W')
        for u in self.gpus:
            try:
                sm = self.backend.sample(u)
            except Exception:
                cards.append(L(lang, f'{self.card_full(u)}: не удалось прочитать датчики', f'{self.card_full(u)}: could not read sensors'))
                continue
            th, pw = (th + sm.hashrate, pw + sm.power_w)
            st = (self.db.gpu(u) or {'status': '?'})['status']
            cards.append(f'{self.card_full(u)} [{st}] {sm.temp_core:.0f}°C, {sm.hashrate:.2f} {unit}, {sm.power_w:.0f} {unit_w}\n    {self.card_state(u)}')
        lines.append(L(lang, f'Итого: {th:.1f} {unit}, {pw:.0f} Вт по картам.', f'Total: {th:.1f} {unit}, {pw:.0f} W across the cards.'))
        return '\n'.join(lines + cards)

    def table_rows(self) -> list:
        cfg, rows = (self.cfg, [])
        for u in sorted(self.gpus, key=lambda x: self.gpus[x].slot):
            pts = []
            for c, m, pl, h, e in self.db.curve_points(u, cfg.algo, cfg.miner, cfg.miner_version, self.driver):
                h, e = (float(h or 0), float(e or 0))
                pts.append({'core': int(c), 'mem': int(m), 'pl': int(pl), 'h': h, 'eff': e, 'w': h / e if e else 0.0})
            v = self._verified(u)
            now = None
            if v:
                e = float(v['efficiency'] or 0)
                now = {'core': int(v['core_offset']), 'mem': int(v['mem_offset']), 'pl': int(v['power_limit']), 'h': float(v['hashrate'] or 0), 'eff': e, 'w': float(v['power_w'] or 0)}
            crashes = self.db.one("select count(*) c from runs where gpu_uuid=? and algo=? and miner=? and miner_version=? and status='crash'", (u, cfg.algo, cfg.miner, cfg.miner_version))['c']
            rows.append({'slot': self.gpus[u].slot, 'name': self.card_full(u), 'objective': self.obj_of(u)[0], 'now': now, 'max': max(pts, key=lambda p: p['h']) if pts else None, 'min': min(pts, key=lambda p: p['h']) if pts else None, 'best_eff': max((p for p in pts if p['eff']), key=lambda p: p['eff'], default=None), 'points': len(pts), 'crashes': int(crashes)})
        return rows

    def table_text(self, unit: str='TH/s') -> str:
        lang = self.lang
        if lang == 'en':

            def fmt(p):
                return f"{p['h']:.2f} {unit}" + (f", {p['w']:.0f} W" if p['w'] else '') + (f", {p['eff']:.4f}/W" if p['eff'] else '') + f" at core {p['core']}, mem {p['mem']}, PL {p['pl']}"
            rows = self.table_rows()
            out = [f'Rig summary {self.cfg.rig_name}: {self.cfg.algo}/{self.cfg.miner} {self.cfg.miner_version}, target {self.cfg.objective}', f'Based on stable measurements for this algorithm, miner and driver. Hashrate in {unit}.']
            tot_now = tot_max = 0.0
            for r in rows:
                out.append('')
                out.append(f"{r['name']} (target {r['objective']})")
                out.append('  now: ' + (fmt(r['now']) if r['now'] else 'no preset'))
                if r['max']:
                    out.append('  max hashrate: ' + fmt(r['max']))
                    out.append('  min hashrate: ' + fmt(r['min']))
                    if r['best_eff']:
                        out.append('  best efficiency: ' + fmt(r['best_eff']))
                else:
                    out.append('  no measurements yet')
                out.append(f"  points measured: {r['points']}, crashes: {r['crashes']}")
                tot_now += r['now']['h'] if r['now'] else 0.0
                tot_max += r['max']['h'] if r['max'] else 0.0
            out.append('')
            out.append(f'Preset total: {tot_now:.1f} {unit}, sum of card maximums {tot_max:.1f} {unit}.')
            return '\n'.join(out)

        def fmt(p):
            return f"{p['h']:.2f} {unit}" + (f", {p['w']:.0f} Вт" if p['w'] else '') + (f", {p['eff']:.4f}/Вт" if p['eff'] else '') + f" при core {p['core']}, mem {p['mem']}, PL {p['pl']}"
        rows = self.table_rows()
        out = [f'Сводка по ригу {self.cfg.rig_name}: {self.cfg.algo}/{self.cfg.miner} {self.cfg.miner_version}, цель {self.cfg.objective}', f'По устойчивым замерам этого алгоритма, майнера и драйвера. Хешрейт в {unit}.']
        tot_now = tot_max = 0.0
        for r in rows:
            out.append('')
            out.append(f"{r['name']} (цель {r['objective']})")
            out.append('  сейчас: ' + (fmt(r['now']) if r['now'] else 'пресета нет'))
            if r['max']:
                out.append('  максимум хешрейта: ' + fmt(r['max']))
                out.append('  минимум хешрейта: ' + fmt(r['min']))
                if r['best_eff']:
                    out.append('  лучшая эффективность: ' + fmt(r['best_eff']))
            else:
                out.append('  замеров пока нет')
            out.append(f"  замерено точек: {r['points']}, падений: {r['crashes']}")
            tot_now += r['now']['h'] if r['now'] else 0.0
            tot_max += r['max']['h'] if r['max'] else 0.0
        out.append('')
        out.append(f'Итого по пресетам: {tot_now:.1f} {unit}, сумма максимумов карт {tot_max:.1f} {unit}.')
        return '\n'.join(out)

    def table_csv(self, unit: str='TH/s') -> str:
        import csv
        import io
        buf = io.StringIO()
        w = csv.writer(buf, delimiter=';')
        if self.lang == 'en':
            head = ['Slot', 'Card', 'Target']
            for k in ('Now', 'Max hashrate', 'Min hashrate', 'Best efficiency'):
                head += [f'{k}: hashrate {unit}', f'{k}: W', f'{k}: eff./W', f'{k}: core', f'{k}: mem', f'{k}: PL']
            w.writerow(head + ['Points', 'Crashes'])
            for r in self.table_rows():
                line = [r['slot'], r['name'], r['objective']]
                for key in ('now', 'max', 'min', 'best_eff'):
                    p = r[key]
                    line += [f"{p['h']:.2f}", f"{p['w']:.0f}", f"{p['eff']:.4f}", p['core'], p['mem'], p['pl']] if p else [''] * 6
                w.writerow(line + [r['points'], r['crashes']])
            return buf.getvalue()
        head = ['Слот', 'Карта', 'Цель']
        for k in ('Сейчас', 'Максимум хешрейта', 'Минимум хешрейта', 'Лучшая эффективность'):
            head += [f'{k}: хешрейт {unit}', f'{k}: Вт', f'{k}: эфф./Вт', f'{k}: core', f'{k}: mem', f'{k}: PL']
        w.writerow(head + ['Точек', 'Падений'])
        for r in self.table_rows():
            line = [r['slot'], r['name'], r['objective']]
            for key in ('now', 'max', 'min', 'best_eff'):
                p = r[key]
                line += [f"{p['h']:.2f}", f"{p['w']:.0f}", f"{p['eff']:.4f}", p['core'], p['mem'], p['pl']] if p else [''] * 6
            w.writerow(line + [r['points'], r['crashes']])
        return buf.getvalue()

    def license_line(self) -> str:
        if self.license_gate is None:
            return ''
        lang = self.lang
        if self._lic_msg:
            return L(lang, f'⚠ Лицензия не действует: {self._lic_msg}', f'⚠ License not valid: {self._lic_msg}')
        lc = getattr(self, 'lic', None)
        if lc is None:
            return ''
        kind = L(lang, 'пробный период', 'trial') if lc.trial else L(lang, 'лицензия', 'license')
        if lc.expiry:
            return L(lang, f'Лицензия: {kind}, действует до {lc.expiry}.', f'License: {kind}, valid until {lc.expiry}.')
        return L(lang, f'Лицензия: {kind}.', f'License: {kind}.')

    def _licensed(self) -> bool:
        if self.license_gate is None:
            return True
        ok, why = self.license_gate()
        if not ok and why != self._lic_msg:
            self.notify(L(self.lang, f"Лицензия не действует: {why}. Бот ничего не меняет в разгоне, майнер работает как работал. Идентификатор рига: {getattr(self, 'hwid', '')}", f"License not valid: {why}. The bot isn't changing overclock settings, the miner keeps running as-is. Rig ID: {getattr(self, 'hwid', '')}"))
        if ok and self._lic_msg:
            self.notify(L(self.lang, 'Лицензия действует, бот продолжает работу.', 'License valid, the bot is resuming work.'))
        self._lic_msg = None if ok else why
        if ok:
            self._sync_trial()
        self._license_events()
        return ok

    def _license_events(self) -> None:
        lc = getattr(self, 'lic', None)
        if lc is None:
            return
        try:
            ev = lc.tick()
        except Exception:
            log.exception('не удалось обработать сроки лицензии')
            return
        lang = self.lang
        site = getattr(self.cfg, 'site_url', '')
        where = L(lang, f' Продлить: {site}' if site else ' Продлить можно на сайте проекта, раздел «Продлить».', f' Renew: {site}' if site else ' You can renew on the project\'s site, under "Renew".')
        if ev['warn'] is not None:
            self.notify(L(lang, f"Лицензия закончится через {ev['warn']} дн. (до {lc.expiry}).{where} Новый срок бот подхватит сам.", f"The license expires in {ev['warn']} day(s) (until {lc.expiry}).{where} The bot will pick up the new term on its own."))
        if ev['expired_new']:
            days = getattr(self.cfg, 'expired_purge_days', 5)
            for u in list(self.gpus):
                self.apply_safe(u)
            self.notify(L(lang, f'Срок лицензии вышел ({lc.expiry}). Применены безопасные значения, подбор остановлен. Если не продлить, через {days} дн. код бота удалится с рига, а пресеты, база и конфиг останутся: после продления работа продолжится с того же места.{where}', f"The license has expired ({lc.expiry}). Safe values applied, tuning stopped. If not renewed, the bot's code will be removed from the rig in {days} day(s); presets, database and config stay in place, and work will resume from where it left off once renewed.{where}"))
        if ev['purge']:
            self.notify(L(lang, 'Срок лицензии не продлён: удаляю код бота с этого рига. Пресеты, база и конфиг сохранены; для возврата поставьте бота заново и введите ключ.', "The license was not renewed: removing the bot's code from this rig. Presets, database and config are kept; to come back, reinstall the bot and enter the key."))
            self._purge_self()

    def _purge_self(self) -> None:
        from . import selfupdate as su
        from .service import uninstall
        try:
            log.warning(uninstall(su.workdir_of_code(), keep_data=True))
        except Exception:
            log.exception('не удалось удалить код бота')

    def _wait_license_tick(self, seconds: float=5) -> None:
        self._touch_beat()
        self.clock.sleep(seconds)

    def run_forever(self) -> None:
        self.start_watchdog()
        while not self._licensed():
            self._wait_license_tick()
        self.startup()
        while True:
            if self.license_gate is not None and (not self._licensed()):
                self._wait_license_tick()
                continue
            try:
                self.cycle()
                self.monitor_once()
                self._drv_err_since = None
            except Stopped:
                self.halted = True
                self.stop_flag.clear()
                self.notify(L(self.lang, 'Работа остановлена командой /stop, безопасный профиль применён.', 'Stopped by the /stop command, safe profile applied.'))
            except PsuOverload as e:
                self.handle_overload(e)
            except Exception as e:
                log.exception('ошибка в рабочем цикле')
                hang = isinstance(e, (CommandTimeout, subprocess.TimeoutExpired))
                now = self.clock.now()
                if now - getattr(self, '_err_notified', -1000000000.0) > 600:
                    self._err_notified = now
                    self.notify(L(self.lang, f'Внутренняя ошибка бота ({type(e).__name__}: {str(e)[:200]}), цикл продолжается через минуту. Подробности в ocbot.log.', f'Internal bot error ({type(e).__name__}: {str(e)[:200]}), the cycle continues in a minute. Details in ocbot.log.'))
                if hang:
                    try:
                        self._driver_hang_check()
                    except Exception:
                        log.exception('не удалось обработать зависание драйвера')
                if not hang:
                    try:
                        self._driver_error_watch(e, now)
                    except Exception:
                        log.exception('не удалось обработать ошибку драйвера')
                    try:
                        self.recover_unfinished()
                    except Exception:
                        log.exception('не удалось закрыть незавершённые замеры')
                self.clock.sleep(60)
            self.set_phase(self._idle_text())
            self.clock.sleep(self.cfg.cycle_idle_s)
