from __future__ import annotations
import os
import re
import time
from typing import Callable, List, Optional
PATTERN = re.compile('CUDA GPU failure detected GPU (\\d+) PCI ([0-9a-fA-F:]+\\.[0-9a-fA-F])')
STAMP = re.compile('\\[(\\w{3} \\w{3} +\\d+ \\d+:\\d+:\\d+ [AP]M) \\w+ (\\d{4})\\]')
MAX_READ = 512 * 1024
MAX_AGE_S = 1800

def _parse_ts(line: str) -> Optional[float]:
    m = STAMP.search(line)
    if not m:
        return None
    try:
        return time.mktime(time.strptime(f'{m.group(1)} {m.group(2)}', '%a %b %d %I:%M:%S %p %Y'))
    except ValueError:
        return None

def read_new(path: str, state: dict, now: Optional[float]=None) -> List[dict]:
    now = time.time() if now is None else now
    try:
        st = os.stat(path)
    except OSError:
        return []
    cur = (state.get('ino'), state.get('off'))
    if cur[0] != st.st_ino or cur[1] is None or cur[1] > st.st_size:
        first = cur[1] is None
        state['ino'], state['off'] = (st.st_ino, st.st_size if first else 0)
        if first:
            return []
    start = state['off']
    if st.st_size - start > MAX_READ:
        start = st.st_size - MAX_READ
    try:
        with open(path, 'rb') as f:
            f.seek(start)
            data = f.read(st.st_size - start)
    except OSError:
        return []
    state['off'] = start + len(data)
    out: List[dict] = []
    for raw in data.decode('utf-8', 'replace').splitlines():
        m = PATTERN.search(raw)
        if not m:
            continue
        ts = _parse_ts(raw)
        if ts is not None and now - ts > MAX_AGE_S:
            continue
        ev = {'ts': ts if ts is not None else now, 'gpu': int(m.group(1)), 'bus': m.group(2)}
        if any((o['bus'] == ev['bus'] and abs(o['ts'] - ev['ts']) < 180 for o in out)):
            continue
        out.append(ev)
    return out
EVENTS = [('reboot', re.compile('(?i)(?:command|cmd|received)\\W+.*\\breboot\\b|\\brebooting\\b|\\bsystem is going down for reboot\\b'), 'Hive: риг получил команду перезагрузки.'), ('shutdown', re.compile('(?i)(?:command|cmd|received)\\W+.*\\bshutdown\\b|\\bpower ?off\\b'), 'Hive: риг получил команду выключения.'), ('oc_failed', re.compile('(?i)nvidia[- ]?oc.*(?:fail|error)|(?:fail|error).*nvidia[- ]?oc'), 'Hive: «NVIDIA OC failed», панель не смогла применить разгон. Проверьте настройки разгона в панели.'), ('config', re.compile('(?i)\\brig\\.?conf\\b.*(?:chang|updat|new)|(?:rig )?config(?:uration)? (?:chang|updat)|\\bwallet\\b.*\\b(?:chang|updat)'), 'Hive: конфиг рига изменён из панели.'), ('shell', re.compile('(?i)\\b(?:hive ?shell|hshell|shellinabox|ssh session|sshd?\\b.*accepted)\\b'), 'Hive: открыта сессия Hive Shell.'), ('miner', re.compile('(?i)\\bminer\\b.*\\b(?:restart|stop(?:ped)?|start(?:ed)?)\\b.*\\bcommand\\b|\\bcommand\\b.*\\bminer\\b.*\\b(?:restart|stop|start)\\b'), 'Hive: майнер перезапущен или остановлен командой из панели.')]
MIRROR_COOLDOWN_S = 600

def read_lines(path: str, state: dict) -> List[str]:
    try:
        st = os.stat(path)
    except OSError:
        return []
    if state.get('ino') != st.st_ino or state.get('off') is None or state['off'] > st.st_size:
        first = state.get('off') is None
        state['ino'], state['off'] = (st.st_ino, st.st_size if first else 0)
        if first:
            return []
    start = max(state['off'], st.st_size - MAX_READ)
    try:
        with open(path, 'rb') as f:
            f.seek(start)
            data = f.read(st.st_size - start)
    except OSError:
        return []
    state['off'] = start + len(data)
    return data.decode('utf-8', 'replace').splitlines()

def classify(lines: List[str], state: dict, now: Optional[float]=None) -> List[str]:
    now = time.time() if now is None else now
    last = state.setdefault('last', {})
    out: List[str] = []
    for raw in lines:
        if PATTERN.search(raw):
            continue
        for key, rx, text in EVENTS:
            if rx.search(raw):
                ts = _parse_ts(raw)
                if ts is not None and now - ts > MAX_AGE_S:
                    break
                if now - last.get(key, -1000000000.0) >= MIRROR_COOLDOWN_S:
                    last[key] = now
                    out.append(text)
                break
    return out
