from __future__ import annotations
from typing import Optional
from . import protocol
from .db import DB, utcnow
CODE_FOREIGN_SENDER = 'foreign_sender'
CODE_DECODE_ERROR = 'decode_error'
CODE_OUT_OF_BOUNDS = 'out_of_bounds'
CODE_DUPLICATE = 'duplicate'
CODE_ACCEPTED = 'accepted'

def preset_message(db: DB, profile_id: str) -> str:
    p = db.one('select * from profiles where id=?', (profile_id,))
    g = db.gpu(p['gpu_uuid'])
    return protocol.encode({'profile_id': p['id'], 'gpu_uuid': p['gpu_uuid'], 'model': g['model'], 'vbios': p['vbios'] or g['vbios'], 'mem_vendor': g['mem_vendor'], 'algo': p['algo'], 'miner': p['miner'], 'miner_version': p['miner_version'], 'driver': p['driver_version'], 'core': p['core_offset'], 'mem': p['mem_offset'], 'pl': p['power_limit'], 'fan': p['fan'], 'hashrate': p['hashrate'], 'power_w': p['power_w'], 'efficiency': p['efficiency'], 'verified_at': p['verified_at']}, label=g['label'] or '')

def import_preset(db: DB, cfg, text: str, from_user: int, lang: str='ru') -> tuple:
    L = protocol.L
    if from_user != cfg.owner_id:
        return (False, CODE_FOREIGN_SENDER, L(lang, 'чужой отправитель', 'foreign sender'))
    try:
        p = protocol.decode(text, lang)
    except protocol.ProtocolError as e:
        return (False, CODE_DECODE_ERROR, L(lang, f'отклонено: {e}', f'rejected: {e}'))
    problems = protocol.check_bounds(p, cfg.limits(), lang)
    if problems:
        db.record_import(p['msg_key'], p['profile_id'], from_user, False, '; '.join(problems))
        return (False, CODE_OUT_OF_BOUNDS, L(lang, 'значения вне границ: ', 'values out of bounds: ') + '; '.join(problems))
    if db.has_import(p['msg_key']) or db.one('select 1 from profiles where id=?', (p['profile_id'],)):
        return (False, CODE_DUPLICATE, L(lang, 'дубликат', 'duplicate'))
    if db.gpu(p['gpu_uuid']) is None:
        db.upsert_gpu(p['gpu_uuid'], p['model'], p['vbios'], p['mem_vendor'], None, None)
    db.save_profile({'id': p['profile_id'], 'gpu_uuid': p['gpu_uuid'], 'algo': p['algo'], 'miner': p['miner'], 'miner_version': p['miner_version'], 'driver_version': p['driver'], 'vbios': p['vbios'], 'core_offset': p['core'], 'mem_offset': p['mem'], 'power_limit': p['pl'], 'fan': p['fan'], 'hashrate': p['hashrate'], 'power_w': p['power_w'], 'efficiency': p['efficiency'], 'status': 'imported', 'source': 'imported', 'created_at': utcnow(), 'verified_at': p['verified_at']})
    db.record_import(p['msg_key'], p['profile_id'], from_user, True)
    return (True, CODE_ACCEPTED, L(lang, 'принят (статус imported, перед использованием будет проверен)', 'accepted (status: imported, will be verified before use)'))
