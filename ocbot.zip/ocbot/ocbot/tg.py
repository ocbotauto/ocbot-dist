from __future__ import annotations
import json
import socket
import urllib.parse
import urllib.request
import uuid

class TgError(RuntimeError):
    pass
_orig_getaddrinfo = socket.getaddrinfo

def _ipv4_for_telegram(host, port, family=0, *a, **kw):
    if isinstance(host, str) and host.endswith('telegram.org'):
        family = socket.AF_INET
    return _orig_getaddrinfo(host, port, family, *a, **kw)
socket.getaddrinfo = _ipv4_for_telegram

class TgClient:

    def __init__(self, token: str, proxy: str='', api_base: str=''):
        root = (api_base or 'https://api.telegram.org').rstrip('/')
        self.base = f'{root}/bot{token}'
        self.file_base = f'{root}/file/bot{token}'
        handlers = [urllib.request.ProxyHandler({'http': proxy, 'https': proxy})] if proxy else []
        self._open = urllib.request.build_opener(*handlers).open

    def _call(self, method: str, params: dict | None=None, timeout: int=60):
        data = urllib.parse.urlencode(params or {}).encode()
        with self._open(urllib.request.Request(f'{self.base}/{method}', data=data), timeout=timeout) as r:
            out = json.loads(r.read())
        if not out.get('ok'):
            raise TgError(str(out))
        return out['result']

    def get_me(self) -> dict:
        return self._call('getMe')

    def set_commands(self, commands) -> None:
        self._call('setMyCommands', {'commands': json.dumps([{'command': c, 'description': d} for c, d in commands], ensure_ascii=False)})

    def get_updates(self, offset: int, timeout: int=30) -> list:
        return self._call('getUpdates', {'offset': offset, 'timeout': timeout}, timeout=timeout + 15)

    def send(self, chat_id: int, text: str) -> None:
        for i in range(0, len(text) or 1, 3900):
            self._call('sendMessage', {'chat_id': chat_id, 'text': text[i:i + 3900]})

    def send_document(self, chat_id: int, filename: str, content: bytes) -> None:
        b = uuid.uuid4().hex
        body = f'--{b}\r\nContent-Disposition: form-data; name="chat_id"\r\n\r\n{chat_id}\r\n--{b}\r\nContent-Disposition: form-data; name="document"; filename="{filename}"\r\nContent-Type: text/plain\r\n\r\n'.encode() + content + f'\r\n--{b}--\r\n'.encode()
        req = urllib.request.Request(f'{self.base}/sendDocument', data=body, headers={'Content-Type': f'multipart/form-data; boundary={b}'})
        with self._open(req, timeout=60) as r:
            if not json.loads(r.read()).get('ok'):
                raise TgError('sendDocument')

    def download(self, file_id: str) -> bytes:
        path = self._call('getFile', {'file_id': file_id})['file_path']
        with self._open(f'{self.file_base}/{path}', timeout=60) as r:
            return r.read()
