from __future__ import annotations
import random
from typing import Optional
from .backend import BackendError, GpuInfo, Sample

class FakeClock:

    def __init__(self):
        self.t = 1000000.0

    def now(self) -> float:
        return self.t

    def sleep(self, s: float) -> None:
        self.t += s

class SimBackend:
    PL = (100, 220, 250)

    def __init__(self, clock: FakeClock, cards: list, seed: int=1):
        self.clock, self.rng = (clock, random.Random(seed))
        self.gpus = [GpuInfo(i, c['uuid'], c.get('model', 'RTX 3070'), c.get('vbios', '94.04.1E'), f'00000000:{i + 1:02x}:00.0', c.get('mem_vendor', 'Samsung'), c.get('mem_mb', 8192)) for i, c in enumerate(cards)]
        self.cards = {c['uuid']: dict(c) for c in cards}
        self.cur = {c['uuid']: (0, 0, self.PL[1], None) for c in cards}
        self.applied_at = {c['uuid']: clock.now() for c in cards}
        self.lost = set()
        self.disabled = set()
        self.invisible = set()
        self.reboots = 0
        self.xid_events: list = []
        self.applies: list = []
        self.miner_actions: list = []
        self.locks: dict = {}
        self.lock_log: list = []

    def list_gpus(self):
        return [g for g in self.gpus if g.uuid not in self.invisible]

    def driver_version(self):
        return '535.154'

    def power_limits(self, uuid):
        return self.PL

    def apply(self, uuid, core, mem, pl, fan):
        if mem > self.cards[uuid].get('apply_max_mem', 10 ** 9):
            raise BackendError('NVIDIA-SETTINGS: value out of range')
        self.cur[uuid] = (core, mem, pl, fan)
        self.applied_at[uuid] = self.clock.now()
        self.applies.append((uuid, core, mem, pl))
    NOMINAL_GR, NOMINAL_MEM = (1755, 810)

    def clocks(self, uuid):
        core, mem = self.locks.get(uuid, (None, None))
        return (core or self.NOMINAL_GR, mem or self.NOMINAL_MEM)

    def supported_clocks(self, uuid):
        return {810: list(range(900, 2010, 15)), 5001: list(range(900, 2010, 15)), 405: list(range(210, 1000, 15))}

    def lock_clocks(self, uuid, core, mem):
        self.locks[uuid] = (core or None, mem or None)
        self.lock_log.append((uuid, core, mem))
        return ''

    def unlock_clocks(self, uuid):
        self.locks.pop(uuid, None)
        self.lock_log.append((uuid, None, None))

    def _lock_factors(self, uuid):
        core, mem = self.locks.get(uuid, (None, None))
        r = min(1.0, (core or self.NOMINAL_GR) / self.NOMINAL_GR)
        return (r ** 0.6, r ** 2.5)

    def _draw(self, core, mem, base=120):
        return base + 0.02 * mem + 0.1 * core

    def model(self, core, mem, pl):
        draw = self._draw(core, mem)
        power = min(pl, draw)
        factor = max(0.0, min(1.0, (pl - 100) / max(draw - 100, 1e-06))) ** 0.5
        hs = 60 * (1 + mem / 3000) * (1 - 0.0001 * core) * factor
        return (hs, power)

    def model_for(self, uuid, core, mem, pl):
        c = self.cards.get(uuid, {})
        if 'scale' not in c and 'base' not in c:
            return self.model(core, mem, pl)
        draw = self._draw(core, mem, c.get('base', 120))
        factor = max(0.0, min(1.0, (pl - 100) / max(draw - 100, 1e-06))) ** 0.5
        return (60 * c.get('scale', 1.0) * (1 + mem / 3000) * (1 - 0.0001 * core) * factor, min(pl, draw))

    def sample(self, uuid):
        if uuid in self.invisible or uuid in self.lost:
            return Sample(lost=True)
        c = self.cards[uuid]
        core, mem, pl, _ = self.cur[uuid]
        age = self.clock.now() - self.applied_at[uuid]
        lim = c.get('lock_core_lim', c['core_lim']) if self.locks.get(uuid, (None, None))[0] else c['core_lim']
        if mem > c['mem_lim'] or core > lim or pl < c.get('pl_min_ok', 0) or (mem > c.get('late_mem_lim', 10 ** 9) and age > 3600):
            self.lost.add(uuid)
            self.xid_events.append({'bus': self.gpus[[g.uuid for g in self.gpus].index(uuid)].bus_id, 'code': 13, 'line': 'sim xid 13'})
            return Sample(lost=True)
        hs, power = self.model_for(uuid, core, mem, pl)
        fh, fp = self._lock_factors(uuid)
        hs, power = (hs * fh, power * fp)
        if self.locks.get(uuid, (None, None))[0]:
            power *= max(0.5, 1 - c.get('lift_gain', 0.0) * max(0, core - c.get('lift_from', 0)))
        hs *= 1 + self.rng.uniform(-0.001, 0.001)
        if core > c.get('zero_core_lim', 10 ** 9) or mem > c.get('zero_mem_lim', 10 ** 9):
            self.disabled.add(uuid)
        if uuid in self.disabled:
            hs, power = (0.0, 31.0)
        if core > c.get('dip_core_lim', 10 ** 9) and c.get('dip_from', 0) <= age < c.get('dip_to', 0):
            hs, power = (0.0, 40.0)
        tcore = 60 + power * 0.1 + c.get('core_heat', 0.0) * max(core, 0) / 100
        tmem = c.get('mem_temp_base', 80.0) + c.get('mem_heat', 0.0) * max(mem, 0) / 1000
        up = float(age)
        if c.get('dip_core_lim') is not None and core > c['dip_core_lim'] and (age >= c.get('dip_to', 0) > 0):
            up = float(age - c['dip_to'])
        return Sample(hs, power, tcore, tmem, False, 0.1, uptime_s=up)

    def power_draws(self):
        out = {}
        for g in self.list_gpus():
            core, mem, pl, _ = self.cur[g.uuid]
            out[g.uuid] = self.model_for(g.uuid, core, mem, pl)[1]
        return out

    def xids(self):
        return list(self.xid_events)

    def miner(self, action):
        self.miner_actions.append(action)
        if action == 'start':
            self.disabled.clear()

    def reboot(self):
        self.reboots += 1
        self.lost.clear()
        self.locks.clear()
        for u in self.cur:
            self.cur[u] = (0, 0, self.PL[1], None)
            self.applied_at[u] = self.clock.now()
