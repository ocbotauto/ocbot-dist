from __future__ import annotations
import base64
import hashlib
import json
import logging
import threading
import time
import urllib.error
import urllib.request
from typing import Optional
from . import catalog
from .db import utcnow
log = logging.getLogger('ocbot')
API = 'https://api.github.com'

def source_name(cfg) -> str:
    return cfg.publish_name or hashlib.sha1(cfg.rig_name.encode('utf-8')).hexdigest()[:8]

def configured(cfg) -> bool:
    return bool(cfg.github_repo and cfg.github_token)

def _request(cfg, method: str, url: str, body: Optional[dict]=None, opener=None):
    req = urllib.request.Request(url, method=method, data=json.dumps(body).encode('utf-8') if body is not None else None)
    req.add_header('Authorization', 'Bearer ' + cfg.github_token)
    req.add_header('Accept', 'application/vnd.github+json')
    req.add_header('X-GitHub-Api-Version', '2022-11-28')
    req.add_header('User-Agent', 'ocbot')
    if body is not None:
        req.add_header('Content-Type', 'application/json')
    op = opener or urllib.request.build_opener()
    with op.open(req, timeout=30) as r:
        return json.loads(r.read().decode('utf-8') or '{}')

def merge(existing: list, mine: list, source: str) -> list:
    out = [e for e in existing if isinstance(e, dict) and e.get('source') != source]
    out += [dict(e, source=source) for e in mine]
    out.sort(key=lambda e: (e.get('model', ''), e.get('algo', ''), e.get('miner', ''), e.get('source', '')))
    return out

def publish(cfg, db, request=None) -> str:
    if not configured(cfg):
        return 'GitHub не настроен: сначала --github-set РЕПОЗИТОРИЙ ТОКЕН'
    request = request or (lambda m, u, b=None: _request(cfg, m, u, b))
    mine = catalog.build(db)
    if not mine:
        return 'Каталог пуст: нужен хотя бы один проверенный пресет.'
    url = f'{API}/repos/{cfg.github_repo}/contents/{cfg.github_path}'
    try:
        sha, existing = (None, [])
        try:
            cur = request('GET', f'{url}?ref={cfg.github_branch}')
            sha = cur['sha']
            doc = json.loads(base64.b64decode(cur['content']).decode('utf-8'))
            existing = doc.get('entries', []) if isinstance(doc, dict) else []
        except urllib.error.HTTPError as e:
            if e.code != 404:
                raise
        entries = merge(existing, mine, source_name(cfg))
        text = json.dumps({'format': catalog.FORMAT, 'version': catalog.VERSION, 'created_at': utcnow(), 'crc32': catalog._crc(entries), 'entries': entries}, ensure_ascii=False, indent=1)
        body = {'message': 'Каталог пресетов: обновление', 'branch': cfg.github_branch, 'content': base64.b64encode(text.encode('utf-8')).decode('ascii')}
        if sha:
            body['sha'] = sha
        request('PUT', url, body)
    except urllib.error.HTTPError as e:
        if e.code in (401, 403):
            return 'GitHub не принял токен: нужен токен с правом Contents: Read and write на этот репозиторий'
        if e.code == 404:
            return 'GitHub не нашёл репозиторий или ветку: проверьте имя вида владелец/репозиторий и ветку в github_branch'
        if e.code == 409 or e.code == 422:
            return 'Файл на GitHub изменился в этот момент, повтор будет при следующем обновлении'
        return f'GitHub ответил ошибкой {e.code}'
    except (urllib.error.URLError, OSError) as e:
        return f'Риг не достучался до GitHub ({e})'
    except Exception as e:
        return f'Не удалось обновить каталог: {e}'
    return f'Каталог обновлён: записей этого рига {len(mine)}, файл {cfg.github_repo}/{cfg.github_path}'

class Publisher:

    def __init__(self, cfg, db, notify=None, request=None, delay_s: float=60.0):
        self.cfg, self.db, self.notify, self.request, self.delay_s = (cfg, db, notify, request, delay_s)
        self.event = threading.Event()
        self.last_ok = None

    def poke(self, *_a) -> None:
        if configured(self.cfg):
            self.event.set()

    def run_once(self) -> str:
        msg = publish(self.cfg, self.db, self.request)
        ok = msg.startswith('Каталог обновлён')
        log.info('публикация каталога: %s', msg)
        if self.notify and ok != self.last_ok:
            self.notify(('Сайт: ' if ok else 'Сайт не обновлён: ') + msg)
        self.last_ok = ok
        return msg

    def loop(self) -> None:
        while True:
            self.event.wait()
            time.sleep(self.delay_s)
            self.event.clear()
            try:
                self.run_once()
            except Exception as e:
                log.warning('публикация каталога: %s', e)

def set_config(path: str, repo: str, token: str, name: str='') -> None:
    import os
    with open(path, encoding='utf-8') as f:
        raw = json.load(f)
    raw['github_repo'], raw['github_token'] = (repo.strip().strip('/'), token.strip())
    if name:
        raw['publish_name'] = name
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(raw, f, ensure_ascii=False, indent=2)
    os.chmod(tmp, 384)
    os.replace(tmp, path)
