from __future__ import annotations
import json
import statistics
import zlib
from typing import Optional
from .db import DB, utcnow
from .protocol import L
FORMAT = 'ocbot-catalog'
VERSION = 1
_KEY = ('model', 'mem_vendor', 'algo', 'miner', 'miner_version', 'objective')

def _crc(entries: list) -> str:
    raw = json.dumps(entries, sort_keys=True, ensure_ascii=False, separators=(',', ':'))
    return format(zlib.crc32(raw.encode('utf-8')) & 4294967295, '08x')

def _med(rows, col) -> int:
    return int(statistics.median((r[col] for r in rows)))

def build(db: DB, model: Optional[str]=None) -> list:
    rows = db.q("select p.*, g.model as model, coalesce(g.mem_vendor,'') as mv from profiles p join gpus g on g.uuid=p.gpu_uuid where p.status='verified' and coalesce(p.weak_card,0)=0")
    groups: dict = {}
    for r in rows:
        k = (r['model'], r['mv'], r['algo'], r['miner'], r['miner_version'], r['objective'] or '')
        groups.setdefault(k, []).append(r)
    out = []
    for k, rs in groups.items():
        score = (lambda r: r['hashrate'] or 0) if k[5] == 'hashrate' else lambda r: r['efficiency'] or 0
        best = max(rs, key=score)
        out.append({'model': k[0], 'mem_vendor': k[1], 'algo': k[2], 'miner': k[3], 'miner_version': k[4], 'objective': k[5], 'cards': len(rs), 'best': dict({'core': best['core_offset'], 'mem': best['mem_offset'], 'pl': best['power_limit']}, **{'core_lock': best['core_lock']} if best['core_lock'] else {}, **{'mem_lock': best['mem_lock']} if best['mem_lock'] else {}), 'median': {'core': _med(rs, 'core_offset'), 'mem': _med(rs, 'mem_offset'), 'pl': _med(rs, 'power_limit')}, 'hashrate': round(statistics.mean((r['hashrate'] for r in rs if r['hashrate'])), 3) if any((r['hashrate'] for r in rs)) else None, 'power_w': round(statistics.mean((r['power_w'] for r in rs if r['power_w'])), 1) if any((r['power_w'] for r in rs)) else None, 'efficiency': round(statistics.mean((r['efficiency'] for r in rs if r['efficiency'])), 5) if any((r['efficiency'] for r in rs)) else None, 'updated_at': max((r['verified_at'] or r['created_at'] for r in rs))})
    out.sort(key=lambda e: (e['model'], e['algo'], e['miner'], e['objective']))
    return out

def imported(db: DB, model: Optional[str]=None) -> list:
    rows = db.q('select * from model_catalog_imported' + (' where lower(model) like ?' if model else '') + ' order by model, algo, miner', (f'%{model.lower()}%',) if model else ())
    return [{'model': r['model'], 'mem_vendor': r['mem_vendor'], 'algo': r['algo'], 'miner': r['miner'], 'miner_version': r['miner_version'], 'objective': r['objective'], 'cards': r['cards'], 'best': {'core': r['best_core'], 'mem': r['best_mem'], 'pl': r['best_pl']}, 'median': {'core': r['med_core'], 'mem': r['med_mem'], 'pl': r['med_pl']}, 'hashrate': r['hashrate'], 'power_w': r['power_w'], 'efficiency': r['efficiency'], 'updated_at': r['updated_at'], 'source': 'imported'} for r in rows]

def lookup(db: DB, model: str) -> list:
    q = (model or '').lower().replace(' ', '')
    return [dict(e, source=e.get('source', 'local')) for e in build(db) + imported(db) if not q or q in e['model'].lower().replace(' ', '')]

def format_table(entries: list, unit: str='', lang: str='ru') -> str:
    if not entries:
        return L(lang, 'В каталоге пока ничего нет: записи появятся после первой проверенной карты.', 'The catalog is empty so far: entries appear after the first verified card.')
    unit_w = L(lang, 'Вт', 'W')
    lines = []
    for e in entries:
        b, m = (e['best'], e['median'])
        eff = f", {e['efficiency']:.4f}/{unit_w}" if e.get('efficiency') else ''
        hr = f", {e['hashrate']:.1f}{(' ' + unit if unit else '')}" if e.get('hashrate') else ''
        src = L(lang, ' [чужой]', ' [other]') if e.get('source') == 'imported' else ''
        if b.get('core_lock') or b.get('mem_lock'):
            lk = L(lang, f", фиксация ядро {b.get('core_lock') or '-'} / память {b.get('mem_lock') or '-'} МГц", f", lock core {b.get('core_lock') or '-'} / memory {b.get('mem_lock') or '-'} MHz")
        else:
            lk = ''
        mem_unknown = L(lang, 'память ?', 'memory ?')
        best_word = L(lang, 'лучший', 'best')
        typical = L(lang, 'типичный (медиана по {n} шт.)', 'typical (median of {n})').format(n=e['cards'])
        lines.append(f"{e['model']} ({e['mem_vendor'] or mem_unknown}) {e['algo']}/{e['miner']} {e['miner_version']}{(' ' + e['objective'] if e['objective'] else '')}{src}\n  {best_word}: core {b['core']}, mem {b['mem']}, PL {b['pl']}{lk}; {typical}: core {m['core']}, mem {m['mem']}, PL {m['pl']}{hr}{eff}")
    return '\n'.join(lines)

def export_text(db: DB) -> str:
    entries = build(db)
    return json.dumps({'format': FORMAT, 'version': VERSION, 'created_at': utcnow(), 'crc32': _crc(entries), 'entries': entries}, ensure_ascii=False, indent=1)

def looks_like_catalog(text: str) -> bool:
    return text.lstrip().startswith('{') and f'"{FORMAT}"' in text[:300]

def import_text(db: DB, cfg, text: str, lang: str='ru') -> tuple:
    try:
        d = json.loads(text)
        entries = d['entries']
        if d.get('format') != FORMAT or int(d.get('version', 0)) != VERSION or (not isinstance(entries, list)):
            raise ValueError(L(lang, 'не файл каталога', 'not a catalog file'))
        if d.get('crc32') != _crc(entries):
            return (0, 0, [L(lang, 'контрольная сумма не сходится: файл изменён или повреждён', 'checksum mismatch: the file was changed or corrupted')])
    except (ValueError, KeyError, TypeError) as e:
        return (0, 0, [L(lang, f'файл не разобран: {e}', f'could not parse the file: {e}')])
    lim, ok, bad, notes = (cfg.limits(), 0, 0, [])
    for e in entries:
        try:
            for k in _KEY[:5]:
                if not isinstance(e[k], str) or len(e[k]) > 80 or '\n' in e[k]:
                    raise ValueError(L(lang, f'поле {k}', f'field {k}'))
            obj = e.get('objective') or ''
            if obj not in ('', 'efficiency', 'compromise', 'hashrate'):
                raise ValueError(L(lang, 'цель', 'objective'))
            vals = {}
            for part in ('best', 'median'):
                for ax in ('core', 'mem', 'pl'):
                    v = int(e[part][ax])
                    lo, hi = lim[ax]
                    if not lo <= v <= hi:
                        raise ValueError(L(lang, f'{part}.{ax}={v} вне диапазона {lo}..{hi}', f'{part}.{ax}={v} out of range {lo}..{hi}'))
                    vals[f'{part}_{ax}'] = v
            n = max(1, int(e.get('cards', 1)))
            old = db.one('select cards from model_catalog_imported where model=? and mem_vendor=? and algo=? and miner=? and miner_version=? and objective=?', tuple((e[k] if k != 'objective' else obj for k in _KEY)))
            if old and old['cards'] > n:
                notes.append(L(lang, f"{e['model']}: уже есть запись по большему числу карт ({old['cards']}), оставлена она", f"{e['model']}: a record with more cards already exists ({old['cards']}), keeping it"))
                continue
            db.x('insert or replace into model_catalog_imported(model, mem_vendor, algo, miner, miner_version, objective, cards, best_core, best_mem, best_pl, med_core, med_mem, med_pl, hashrate, power_w, efficiency, updated_at, imported_at) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)', (e['model'], e['mem_vendor'], e['algo'], e['miner'], e['miner_version'], obj, n, vals['best_core'], vals['best_mem'], vals['best_pl'], vals['median_core'], vals['median_mem'], vals['median_pl'], e.get('hashrate'), e.get('power_w'), e.get('efficiency'), str(e.get('updated_at') or ''), utcnow()))
            ok += 1
        except (KeyError, TypeError, ValueError) as err:
            bad += 1
            model = e.get('model', '?') if isinstance(e, dict) else '?'
            notes.append(L(lang, f'{model}: отклонено ({err})', f'{model}: rejected ({err})'))
    return (ok, bad, notes)

def seed(db: DB, model: str, mem_vendor, algo: str, miner: str) -> Optional[dict]:
    rows = db.q("select * from model_catalog_imported where model=? and algo=? and miner=? order by (coalesce(mem_vendor,'')=coalesce(?,'')) desc, cards desc, updated_at desc", (model, algo, miner, mem_vendor))
    if not rows:
        return None
    r = rows[0]
    return {'core': r['med_core'], 'mem': r['med_mem'], 'pl': r['med_pl'], 'n': r['cards']}
