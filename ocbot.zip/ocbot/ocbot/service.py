from __future__ import annotations
import os
import shlex
import subprocess
import sys
UNIT_NAME = 'ocbot'
UNIT_PATH = f'/etc/systemd/system/{UNIT_NAME}.service'

def render_unit(workdir: str, config_path: str, python: str='python3', log_path: str='') -> str:
    log_path = log_path or os.path.join(workdir, 'ocbot.log')
    cmd = f'exec {shlex.quote(python)} -m ocbot --config {shlex.quote(config_path)} >> {shlex.quote(log_path)} 2>&1'
    return f'[Unit]\nDescription=HiveOS OC bot (авто-подбор разгона)\nDefaultDependencies=no\nStartLimitIntervalSec=0\n\n[Service]\nType=simple\nExecStartPre=/bin/sleep 60\nWorkingDirectory={workdir}\nExecStart=/bin/sh -c {shlex.quote(cmd)}\nRestart=always\nRestartSec=30\n\n[Install]\nWantedBy=multi-user.target\n'
CRON_TAG = '# ocbot-autostart'
CRON_LINE = f'@reboot sleep 90 && systemctl is-enabled --quiet {UNIT_NAME} && systemctl start {UNIT_NAME} {CRON_TAG}'

def _cron_get() -> str:
    r = subprocess.run(['crontab', '-l'], capture_output=True, text=True)
    return r.stdout if r.returncode == 0 else ''

def _cron_set(text: str) -> None:
    subprocess.run(['crontab', '-'], input=text, text=True, capture_output=True)

def cron_update(add: bool, get=_cron_get, put=_cron_set) -> None:
    try:
        lines = [l for l in get().splitlines() if CRON_TAG not in l]
        if add:
            lines.append(CRON_LINE)
        put('\n'.join(lines) + '\n' if lines else '')
    except (OSError, ValueError):
        pass

def _ctl(*args: str) -> subprocess.CompletedProcess:
    return subprocess.run(['systemctl', *args], capture_output=True, text=True)

def run_action(action: str, workdir: str, config_path: str, unit_path: str=UNIT_PATH, ctl=_ctl, cron=None) -> str:
    cron = cron or cron_update
    if action == 'install':
        with open(unit_path, 'w', encoding='utf-8') as f:
            f.write(render_unit(workdir, os.path.abspath(config_path), sys.executable or 'python3'))
        ctl('daemon-reload')
        cron(True)
        r = ctl('enable', '--now', UNIT_NAME)
        return ('Автозапуск установлен, бот запущен.' if r.returncode == 0 else f'Не удалось включить: {r.stderr.strip() or r.stdout.strip()}') + f" Лог: {os.path.join(workdir, 'ocbot.log')}"
    if action == 'start':
        r = ctl('enable', '--now', UNIT_NAME)
        return 'Бот запущен, автозапуск после перезагрузки включён.' if r.returncode == 0 else f'Не удалось: {r.stderr.strip()} (сначала: --service install)'
    if action == 'stop':
        r = ctl('disable', '--now', UNIT_NAME)
        return 'Бот остановлен, после перезагрузки он НЕ запустится (вернуть: --service start).' if r.returncode == 0 else f'Не удалось: {r.stderr.strip()}'
    if action == 'restart':
        r = ctl('restart', UNIT_NAME)
        return 'Бот перезапущен.' if r.returncode == 0 else f'Не удалось: {r.stderr.strip()}'
    if action == 'remove':
        cron(False)
        ctl('disable', '--now', UNIT_NAME)
        try:
            os.remove(unit_path)
        except OSError:
            pass
        ctl('daemon-reload')
        return 'Автозапуск удалён.'
    if action == 'status':
        active = ctl('is-active', UNIT_NAME).stdout.strip() or 'нет юнита'
        enabled = ctl('is-enabled', UNIT_NAME).stdout.strip() or 'нет юнита'
        return f"Сейчас: {active}. После перезагрузки: {('запустится' if enabled == 'enabled' else 'не запустится')} ({enabled})."
    raise ValueError(action)

def uninstall(workdir: str, keep_data: bool=False, unit_path: str=UNIT_PATH, ctl=_ctl, cron=None) -> str:
    import glob
    import shutil
    cron = cron or cron_update
    workdir = os.path.realpath(workdir)
    if not os.path.isdir(os.path.join(workdir, 'ocbot')) or workdir in ('/', os.path.expanduser('~'), '/root'):
        return f'Отказ: {workdir} не похоже на каталог бота (нет подкаталога ocbot), ничего не удалено.'
    cron(False)
    ctl('disable', '--now', UNIT_NAME)
    try:
        os.remove(unit_path)
    except OSError:
        pass
    ctl('daemon-reload')
    out = ['Служба остановлена, автозапуск и юнит удалены.']
    if keep_data:
        for name in ('ocbot', 'tests', 'tools', 'site'):
            shutil.rmtree(os.path.join(workdir, name), ignore_errors=True)
        for f in glob.glob(os.path.join(workdir, '*.md')) + glob.glob(os.path.join(workdir, '*.sh')) + glob.glob(os.path.join(workdir, 'config.example.json')):
            try:
                os.remove(f)
            except OSError:
                pass
        out.append(f'Код удалён, конфиги, база и лог оставлены в {workdir}.')
    else:
        shutil.rmtree(workdir, ignore_errors=True)
        out.append(f'Каталог {workdir} удалён целиком (код, база пресетов, конфиги, лог).')
    zips = glob.glob(os.path.join(os.path.dirname(workdir), 'ocbot*.zip')) + glob.glob(os.path.join(os.path.dirname(workdir), 'hive-oc-bot*.zip'))
    for z in zips:
        try:
            os.remove(z)
            out.append(f'Удалён архив {z}.')
        except OSError:
            pass
    out.append('Настройки разгона, уже применённые к картам, сбросятся при перезагрузке рига; Hive-разгон из панели бот не менял.')
    return ' '.join(out)
