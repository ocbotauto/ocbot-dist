from __future__ import annotations
import json
import os
import time
from typing import Callable
VERSION = 1
DEFAULT_URL_RU = 'https://ocbotauto.github.io/ocbot-site/guide.ru.html#terms'
DEFAULT_URL_EN = 'https://ocbotauto.github.io/ocbot-site/guide.html#terms'
DEFAULT_URL = DEFAULT_URL_RU

def path_of(cfg) -> str:
    return os.path.join(os.path.dirname(os.path.abspath(getattr(cfg, 'license_path', 'license.json'))), 'terms_accepted.json')

def _lang(cfg) -> str:
    try:
        with open(getattr(cfg, 'state_path', 'ocbot_state.json'), encoding='utf-8') as f:
            data = json.load(f)
        lang = data.get('lang') or data.get('lang_detected')
        return 'en' if lang == 'en' else 'ru'
    except (OSError, ValueError, TypeError, AttributeError):
        return 'ru'

def accepted(cfg) -> bool:
    try:
        with open(path_of(cfg), encoding='utf-8') as f:
            return int(json.load(f).get('v', 0)) >= VERSION
    except (OSError, ValueError, TypeError, AttributeError):
        return False

def record(cfg) -> None:
    p = path_of(cfg)
    tmp = p + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump({'v': VERSION, 'date': time.strftime('%Y-%m-%d')}, f)
    os.replace(tmp, p)

def url_of(cfg) -> str:
    site = (getattr(cfg, 'site_url', '') or '').rstrip('/')
    suffix = '/guide.html#terms' if _lang(cfg) == 'en' else '/guide.ru.html#terms'
    return site + suffix if site else DEFAULT_URL_EN if _lang(cfg) == 'en' else DEFAULT_URL_RU

def text(cfg) -> str:
    return 'Перед началом прочитайте условия и отказ от ответственности:\n  ' + url_of(cfg) + '\n(тот же текст лежит в файле DISCLAIMER.md рядом с ботом).\nКоротко: бот меняет частоты и лимиты мощности и сам перезагружает риг, все риски на вас; на пробном периоде проверенные пресеты (без имени рига и UUID карт) обязательно уходят в общий каталог, с ключом это можно отключить.'

def ensure(cfg, inp: Callable[[str], str]=input, out: Callable[[str], None]=print, assume_yes: bool=False) -> bool:
    if accepted(cfg):
        return True
    out(text(cfg))
    if not assume_yes:
        try:
            ans = inp('Вы прочитали условия и согласны с ними? Введите «да» (или yes): ').strip().lower()
        except (EOFError, OSError):
            ans = ''
        if ans not in ('да', 'д', 'yes', 'y'):
            out('Без согласия продолжить нельзя. Повторите команду, когда прочтёте условия (в скрипте: добавьте --accept-terms, это означает, что вы прочитали и согласны).')
            return False
    record(cfg)
    return True
