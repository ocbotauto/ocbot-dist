from __future__ import annotations
import zlib
from typing import Optional
PREFIX = 'OCP1'
FIELDS = ['profile_id', 'gpu_uuid', 'model', 'vbios', 'mem_vendor', 'algo', 'miner', 'miner_version', 'driver', 'core', 'mem', 'pl', 'fan', 'hashrate', 'power_w', 'efficiency', 'verified_at']
_REQUIRED = {'profile_id', 'gpu_uuid', 'model', 'algo', 'miner', 'miner_version', 'core', 'mem', 'pl', 'verified_at'}
_INT = {'core', 'mem', 'pl', 'fan'}
_FLOAT = {'hashrate', 'power_w', 'efficiency'}

def L(lang: str, ru: str, en: str) -> str:
    return en if lang == 'en' else ru

class ProtocolError(ValueError):
    pass

def _crc(body: str) -> str:
    return format(zlib.crc32(body.encode('utf-8')) & 4294967295, '08x')

def _s(v) -> str:
    if v is None:
        return ''
    s = str(v)
    if '|' in s or '\n' in s:
        raise ProtocolError(f'недопустимый символ в значении: {s!r}')
    return s

def encode(p: dict, label: str='') -> str:
    parts = [PREFIX] + [_s(p.get(f)) for f in FIELDS]
    body = '|'.join(parts)
    line = f'{body}|{_crc(body)}'
    eff = p.get('efficiency')
    human = f"Карта {label or str(p['gpu_uuid'])[-8:]} ({p['model']}, {p.get('mem_vendor') or '?'}): {p['algo']}/{p['miner']} {p['miner_version']}, core {p['core']}, mem {p['mem']}, PL {p['pl']} Вт, fan {(p['fan'] if p.get('fan') is not None else 'авто')}" + (f', {float(eff):.4f} H/W' if eff is not None else '')
    return f'{line}\n{human}'

def find_line(text: str) -> Optional[str]:
    for ln in text.splitlines():
        ln = ln.strip()
        if ln.startswith(PREFIX + '|'):
            return ln
    return None

def decode(text: str, lang: str='ru') -> dict:
    line = find_line(text)
    if line is None:
        raise ProtocolError(L(lang, 'нет строки OCP1', 'no OCP1 line found'))
    parts = line.split('|')
    if len(parts) != len(FIELDS) + 2:
        raise ProtocolError(L(lang, f'неверное число полей: {len(parts)}', f'wrong field count: {len(parts)}'))
    body, crc = ('|'.join(parts[:-1]), parts[-1])
    if _crc(body) != crc.lower():
        raise ProtocolError(L(lang, 'контрольная сумма не сходится', 'checksum mismatch'))
    out: dict = {}
    for name, raw in zip(FIELDS, parts[1:-1]):
        if raw == '':
            if name in _REQUIRED:
                raise ProtocolError(L(lang, f'пустое обязательное поле: {name}', f'empty required field: {name}'))
            out[name] = None
            continue
        try:
            out[name] = int(raw) if name in _INT else float(raw) if name in _FLOAT else raw
        except ValueError:
            raise ProtocolError(L(lang, f'поле {name}: ожидалось число, получено {raw!r}', f'field {name}: expected a number, got {raw!r}'))
    out['msg_key'] = f"{out['profile_id']}:{crc.lower()}"
    return out

def check_bounds(p: dict, limits: dict, lang: str='ru') -> list:
    problems = []
    for key in ('core', 'mem', 'pl'):
        lo, hi = limits[key]
        if not lo <= p[key] <= hi:
            problems.append(L(lang, f'{key}={p[key]} вне диапазона {lo}..{hi}', f'{key}={p[key]} out of range {lo}..{hi}'))
    if p.get('fan') is not None and (not 0 <= p['fan'] <= 100):
        problems.append(L(lang, f"fan={p['fan']} вне диапазона 0..100", f"fan={p['fan']} out of range 0..100"))
    return problems
