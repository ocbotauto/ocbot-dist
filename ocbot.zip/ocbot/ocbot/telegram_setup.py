from __future__ import annotations
import json
import os
import urllib.error
from .config import Config

def set_config(path: str, token: str, owner_id: int) -> None:
    with open(path, encoding='utf-8') as f:
        raw = json.load(f)
    raw['token'], raw['owner_id'] = (token.strip(), int(owner_id))
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(raw, f, ensure_ascii=False, indent=2)
    os.chmod(tmp, 384)
    os.replace(tmp, path)

def check(cfg: Config, client_cls=None) -> str:
    if client_cls is None:
        from .tg import TgClient as client_cls
    if not cfg.token or not cfg.owner_id:
        return 'В конфиге нет токена или ID владельца: сначала --telegram-set ТОКЕН ID'
    try:
        tg = client_cls(cfg.token, cfg.tg_proxy, cfg.tg_api_base)
        me = tg.get_me()
    except urllib.error.HTTPError as e:
        if e.code in (401, 404):
            return 'Telegram не принял токен: проверьте, что он скопирован целиком из @BotFather'
        return f'Telegram ответил ошибкой {e.code}'
    except (urllib.error.URLError, OSError) as e:
        return f'Риг не достучался до api.telegram.org ({e}). Возможно, Telegram блокируется провайдером: нужен прокси: --telegram-proxy http://хост:порт'
    except Exception as e:
        return f'Не удалось связаться с Telegram: {e}'
    try:
        tg.send(cfg.owner_id, f'Бот рига {cfg.rig_name} подключён. Команды: /help')
    except Exception as e:
        return f"Бот @{me.get('username')} найден, но написать вам не может ({e}). Откройте его в Telegram и нажмите Start, затем повторите проверку"
    return f"Готово: бот @{me.get('username')} написал вам в Telegram"
