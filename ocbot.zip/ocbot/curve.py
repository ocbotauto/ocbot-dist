from __future__ import annotations
import hashlib
from .db import BOUNDARY_CAUSES
MAX_POINTS_PER_SET = 600
MAX_POINTS_TOTAL = 4000

def card_token(uuid: str) -> str:
    return hashlib.sha256(('ocbot-card:' + uuid).encode('utf-8')).hexdigest()[:32]
_SQL = f"\nselect r.gpu_uuid u, g.model model, coalesce(g.mem_vendor,'') mv, coalesce(g.board,'') board, r.algo algo, r.miner miner, r.miner_version mver,\n       r.core_offset c, r.mem_offset m, r.power_limit pl,\n       sum(case when r.status='ok' and r.hashrate_median > 0 then 1 else 0 end) okn,\n       avg(case when r.status='ok' and r.hashrate_median > 0 then r.hashrate_median end) h,\n       avg(case when r.status='ok' and r.hashrate_median > 0 then r.power_w end) p,\n       sum(case when r.status in ('crash','unstable') and r.crash_cause in ('aggressive_oc','unknown') then 1 else 0 end) crash,\n       sum(case when r.status in ('crash','unstable') and r.crash_cause = 'overheat' then 1 else 0 end) heat,\n       max(r.id) last_id\nfrom runs r join gpus g on g.uuid = r.gpu_uuid\nwhere r.kind in ('search','verify','recheck')\n  and r.finished_at is not null\n  and coalesce(r.note,'') != 'scout'\n  and coalesce(r.note,'') not like 'lock%'\n  and coalesce(r.note,'') not like '%No targets match%'\n  and coalesce(r.note,'') not like '%Error resolving target%'\ngroup by r.gpu_uuid, r.algo, r.miner, r.miner_version, r.core_offset, r.mem_offset, r.power_limit\nhaving okn > 0 or crash > 0 or heat > 0\n"
assert set(BOUNDARY_CAUSES) == {'aggressive_oc', 'unknown', 'overheat'}, 'причины отвала поменялись: обновите _SQL'

def pl_not_applied(pts: list) -> set:
    ok = [(i, p) for i, p in enumerate(pts) if p[5] and p[3]]
    bad = {i for i, p in ok if p[4] is not None and p[4] > p[2] * 1.05 + 5}
    ref = [(i, p) for i, p in ok if i not in bad]
    for i, p in ref:
        c, m, pl, h = p[:4]
        for j, q in ref:
            dc = c - q[0]
            if j != i and q[1] == m and (-50 <= dc <= 100) and (q[2] <= pl) and (q[3] > h * 1.06):
                bad.add(i)
                break
    return bad

def _drop_bad(pts: list) -> list:
    bad = pl_not_applied(pts)
    out = []
    for i, p in enumerate(pts):
        if i not in bad:
            out.append(p)
        elif p[6] or p[7]:
            out.append([p[0], p[1], p[2], None, None, 0, p[6], p[7]])
    return out

def build(db) -> list:
    sets: dict = {}
    for r in db.q(_SQL):
        k = (r['u'], r['model'], r['mv'], r['algo'], r['miner'], r['mver'])
        sets.setdefault(k, []).append(r)
    out, total = ([], 0)
    for k, rows in sorted(sets.items(), key=lambda kv: -max((r['last_id'] for r in kv[1]))):
        rows = sorted(rows, key=lambda r: -r['last_id'])[:MAX_POINTS_PER_SET]
        if total + len(rows) > MAX_POINTS_TOTAL:
            rows = rows[:MAX_POINTS_TOTAL - total]
        if not rows:
            break
        total += len(rows)
        pts = [[int(r['c']), int(r['m']), int(r['pl']), round(r['h'], 3) if r['h'] is not None else None, round(r['p'], 1) if r['p'] is not None else None, int(r['okn']), int(r['crash']), int(r['heat'])] for r in sorted(rows, key=lambda r: (r['c'], r['m'], r['pl']))]
        pts = _drop_bad(pts)
        if not pts:
            continue
        doc = {'card': card_token(k[0]), 'model': k[1], 'mem_vendor': k[2], 'algo': k[3], 'miner': k[4], 'miner_version': k[5], 'pts': pts}
        if rows[0]['board']:
            doc['board'] = rows[0]['board']
        out.append(doc)
    return out

def demote_foreign_pl(db) -> int:
    sets: dict = {}
    for r in db.q(_SQL):
        sets.setdefault((r['u'], r['algo'], r['miner'], r['mver']), []).append(r)
    n = 0
    for (u, algo, miner, mver), rows in sets.items():
        pts = [[int(r['c']), int(r['m']), int(r['pl']), r['h'], r['p'], int(r['okn']), int(r['crash']), int(r['heat'])] for r in rows]
        for i in pl_not_applied(pts):
            c, m, pl = pts[i][:3]
            n += db.x("update runs set status=null, note='лимит не применился (найдено по истории замеров)' where gpu_uuid=? and algo=? and miner=? and miner_version=? and core_offset=? and mem_offset=? and power_limit=? and status='ok' and kind in ('search','verify','recheck')", (u, algo, miner, mver, c, m, pl)).rowcount
    return n
