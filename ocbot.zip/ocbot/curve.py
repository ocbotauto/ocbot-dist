from __future__ import annotations
import hashlib
from .db import BOUNDARY_CAUSES
MAX_POINTS_PER_SET = 600
MAX_POINTS_TOTAL = 4000

def card_token(uuid: str) -> str:
    return hashlib.sha256(('ocbot-card:' + uuid).encode('utf-8')).hexdigest()[:32]
_SQL = f"\nselect r.gpu_uuid u, g.model model, coalesce(g.mem_vendor,'') mv, r.algo algo, r.miner miner, r.miner_version mver,\n       r.core_offset c, r.mem_offset m, r.power_limit pl,\n       sum(case when r.status='ok' and r.hashrate_median > 0 then 1 else 0 end) okn,\n       avg(case when r.status='ok' and r.hashrate_median > 0 then r.hashrate_median end) h,\n       avg(case when r.status='ok' and r.hashrate_median > 0 then r.power_w end) p,\n       sum(case when r.status in ('crash','unstable') and r.crash_cause in ('aggressive_oc','unknown') then 1 else 0 end) crash,\n       sum(case when r.status in ('crash','unstable') and r.crash_cause = 'overheat' then 1 else 0 end) heat,\n       max(r.id) last_id\nfrom runs r join gpus g on g.uuid = r.gpu_uuid\nwhere r.kind in ('search','verify','recheck')\n  and r.finished_at is not null\n  and coalesce(r.note,'') != 'scout'\n  and coalesce(r.note,'') not like 'lock%'\n  and coalesce(r.note,'') not like '%No targets match%'\n  and coalesce(r.note,'') not like '%Error resolving target%'\ngroup by r.gpu_uuid, r.algo, r.miner, r.miner_version, r.core_offset, r.mem_offset, r.power_limit\nhaving okn > 0 or crash > 0 or heat > 0\n"
assert set(BOUNDARY_CAUSES) == {'aggressive_oc', 'unknown', 'overheat'}, 'причины отвала поменялись: обновите _SQL'

def build(db) -> list:
    sets: dict = {}
    for r in db.q(_SQL):
        k = (r['u'], r['model'], r['mv'], r['algo'], r['miner'], r['mver'])
        sets.setdefault(k, []).append(r)
    out, total = ([], 0)
    for k, rows in sorted(sets.items(), key=lambda kv: -max((r['last_id'] for r in kv[1]))):
        rows = sorted(rows, key=lambda r: -r['last_id'])[:MAX_POINTS_PER_SET]
        if total + len(rows) > MAX_POINTS_TOTAL:
            rows = rows[:MAX_POINTS_TOTAL - total]
        if not rows:
            break
        total += len(rows)
        pts = [[int(r['c']), int(r['m']), int(r['pl']), round(r['h'], 3) if r['h'] is not None else None, round(r['p'], 1) if r['p'] is not None else None, int(r['okn']), int(r['crash']), int(r['heat'])] for r in sorted(rows, key=lambda r: (r['c'], r['m'], r['pl']))]
        out.append({'card': card_token(k[0]), 'model': k[1], 'mem_vendor': k[2], 'algo': k[3], 'miner': k[4], 'miner_version': k[5], 'pts': pts})
    return out
