from __future__ import annotations
import getpass
import json
import os
import re
import socket
import statistics
import subprocess
from typing import Callable, Dict, List, Optional
OBJECTIVES = {'1': ('compromise', 'компромисс: максимум хешрейта при эффективности не хуже лучшей на 3%'), '2': ('efficiency', 'эффективность: максимум хешрейта на ватт, меньше счёт за электричество'), '3': ('hashrate', 'хешрейт: максимум хешрейта, мощность и тепло выше')}

def _run(cmd: List[str], timeout: int=20) -> str:
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout).stdout
    except (OSError, subprocess.SubprocessError):
        return ''

def detect_gpus(run: Callable=_run) -> List[dict]:
    out = run(['nvidia-smi', '--query-gpu=index,uuid,name,power.min_limit,power.max_limit', '--format=csv,noheader,nounits'])
    gpus = []
    for ln in out.strip().splitlines():
        p = [x.strip() for x in ln.split(',')]
        if len(p) < 5:
            continue
        try:
            gpus.append({'slot': int(p[0]), 'uuid': p[1], 'name': p[2].replace('NVIDIA GeForce ', ''), 'pl_min': float(p[3]), 'pl_max': float(p[4])})
        except ValueError:
            continue
    return gpus

def _read_file(path: str) -> str:
    try:
        with open(path, encoding='utf-8', errors='ignore') as f:
            return f.read()
    except OSError:
        return ''

def detect_rig_name(read: Optional[Callable[[str], str]]=None) -> str:
    read = read or _read_file
    text = read('/hive-config/rig.conf')
    m = re.search('^WORKER_NAME=["\\\']?([^"\\\'\\n]+)', text, re.M)
    return m.group(1).strip() if m else ''

def detect_miner(read: Optional[Callable[[str], str]]=None) -> tuple:
    read = read or _read_file
    text = read('/hive-config/wallet.conf')
    name = ver = algo = ''
    for key, target in (('CUSTOM_MINER', 'n'), ('CUSTOM_NAME', 'n'), ('MINER', 'n'), ('CUSTOM_VERSION', 'v'), ('MINER_VERSION', 'v'), ('CUSTOM_ALGO', 'a'), ('ALGO', 'a'), ('MAIN_ALGO', 'a')):
        m = re.search(f"""^{key}=["\\']?([^"\\'\\n]+)""", text, re.M)
        if m:
            val = m.group(1).strip()
            if target == 'n' and (not name):
                name = val
            if target == 'v' and (not ver):
                ver = val
            if target == 'a' and (not algo):
                algo = val
    if not ver and name:
        m = re.match('^(.+?)[-_ ]v?(\\d[\\w.\\-]*)$', name)
        if m:
            name, ver = (m.group(1), m.group(2))
    return (name, ver, algo)
UNIT_SCALE = {'H/s': 1.0, 'KH/s': 1000.0, 'MH/s': 1000000.0, 'GH/s': 1000000000.0, 'TH/s': 1000000000000.0, 'PH/s': 1000000000000000.0}

def detect_unit(workdir: str, run: Callable=_run) -> str:
    out = run(['python3', os.path.join(workdir, 'tools', 'rgminer_stats.py'), '--unit', 'H/s'])
    try:
        data = json.loads(out)
    except ValueError:
        return ''
    vals = [v.get('hashrate') for v in data.values() if isinstance(v, dict) and v.get('hashrate')]
    if not vals:
        return ''
    typical = statistics.median(vals)
    best = min(UNIT_SCALE, key=lambda u: abs(typical / UNIT_SCALE[u] - 50))
    return best

def box(rows: List[tuple], title: str='') -> str:
    w1 = max((len(a) for a, _ in rows))
    inner = max(w1 + 3 + max((len(str(b)) for _, b in rows)), len(title))
    line = '+' + '-' * (inner + 2) + '+'
    out = [line]
    if title:
        out += ['| ' + title.ljust(inner) + ' |', line]
    for a, b in rows:
        out.append('| ' + (a.ljust(w1) + ' : ' + str(b)).ljust(inner) + ' |')
    out.append(line)
    return '\n'.join(out)

def build_config(a: Dict) -> dict:
    return {'rig_name': a['rig_name'], 'db_path': 'ocbot.db', 'state_path': 'ocbot_state.json', 'xid_log_path': 'ocbot_xid.log', 'owner_id': a.get('owner_id', 0), 'token': a.get('token', ''), 'tg_proxy': a.get('tg_proxy', ''), 'algo': a['algo'], 'miner': a['miner'], 'miner_version': a['miner_version'], 'stats_cmd': f"python3 {a['workdir']}/tools/rgminer_stats.py --unit {a['unit']} --window 300", 'psu_required': True, 'psu_watts': a['psu_watts'], 'pl_total_max': a['pl_total_max'], 'objective': a['objective'], 'catalog_share': bool(a.get('catalog_share', False))}

def _lic_site() -> str:
    try:
        from .config import Config
        return Config().site_url
    except Exception:
        return ''

def _detect_owner_id(token: str) -> int:
    from .telegram_setup import detect_owner_id
    return detect_owner_id(token)

def _start_trial(path: str) -> str:
    from .config import Config
    from . import license as lic
    return lic.start_trial(Config.load(path))

def run_setup(workdir: str, inp: Callable[[str], str]=input, secret: Callable[[str], str]=getpass.getpass, out: Callable[[str], None]=print, detect: Callable[[], List[dict]]=detect_gpus, miner_info: Callable[[], tuple]=detect_miner, unit_info: Callable[[str], str]=detect_unit, rig_name_info: Callable[[], str]=detect_rig_name, owner_info: Callable[[str], int]=_detect_owner_id, install: Optional[Callable[[str, str], str]]=None, telegram_check: Optional[Callable[[str], str]]=None, start_trial: Optional[Callable[[str], str]]=None) -> Optional[str]:

    def ask(prompt: str, default: str='') -> str:
        v = inp(f'{prompt}' + (f' [{default}]' if default else '') + ': ').strip()
        return v or default

    def ask_int(prompt: str, default: int=0, lo: int=1, hi: int=100000) -> int:
        while True:
            v = ask(prompt, str(default) if default else '')
            try:
                n = int(float(v.replace(',', '.')))
                if lo <= n <= hi:
                    return n
            except ValueError:
                pass
            out(f'  нужно число от {lo} до {hi}')
    out('\n=== Установка бота авто-подбора разгона ===\n')
    from . import license as _lic
    if _lic.REQUIRED:
        from . import consent
        from types import SimpleNamespace
        _c = SimpleNamespace(license_path=os.path.join(workdir, 'license.json'), site_url=_lic_site())
        if not consent.ensure(_c, inp=inp, out=out):
            return None
    gpus = detect()
    if not gpus:
        out('Карты NVIDIA не найдены (nvidia-smi ничего не вернул). Установку прерываю.')
        return None
    out(box([(f"слот {g['slot']}", f"{g['name']}  PL {g['pl_min']:.0f}..{g['pl_max']:.0f} Вт  {g['uuid'][-8:]}") for g in gpus], f'Найдено карт: {len(gpus)}'))
    mname, mver, malgo = miner_info()
    detected_unit = unit_info(workdir)
    out('\n--- Рига ---')
    rig_default = rig_name_info() or re.sub('[^\\w.-]', '_', socket.gethostname()) or 'rig'
    rig = ask('Имя рига', rig_default)
    auto_bits = []
    if malgo:
        algo = malgo
        auto_bits.append(f'алгоритм {algo}')
    else:
        algo = ask('Алгоритм', 'pearl')
    if mname:
        miner = mname
        auto_bits.append(f'майнер {miner}')
    else:
        miner = ask('Майнер', 'rgminer')
    if mver:
        ver = mver
        auto_bits.append(f'версия {ver}')
    else:
        ver = ask('Версия майнера', '1.1.3b')
    if detected_unit:
        unit = detected_unit
        auto_bits.append(f'единица хешрейта {unit}')
    else:
        unit = ask('Единица хешрейта в статистике майнера (H/s, MH/s, GH/s, TH/s)', 'TH/s')
    if auto_bits:
        out('  Из полётного листа HiveOS и показаний майнера определены: ' + ', '.join(auto_bits) + '.')
    out('\n--- Блок питания (бот не даст сумме мощности карт превысить лимит) ---')
    total_pl = sum((g['pl_max'] for g in gpus))
    out(f'  Карты суммарно могут тянуть до {total_pl:.0f} Вт на максимуме.')
    psu_default = max(300, int(round(total_pl / 0.8 / 50)) * 50) if total_pl else 1600
    psu = ask_int('Мощность блока питания, Вт', psu_default, 300, 10000)
    cap = ask_int('Лимит суммарной мощности карт, Вт (по умолчанию 80% блока)', int(psu * 0.8 / 10) * 10, 100, psu)
    if total_pl <= cap:
        out(f'  (сумма максимумов PL всех карт {total_pl:.0f} Вт, лимит не будет мешать)')
    out('\n--- Цель подбора (потом меняется командой /mode) ---')
    for k, (_, d) in OBJECTIVES.items():
        out(f'  {k}) {d}')
    obj = OBJECTIVES.get(ask('Выберите 1, 2 или 3', '1'), OBJECTIVES['1'])[0]
    prev_cfg = {}
    try:
        with open(os.path.join(workdir, f'config.{rig}.json'), encoding='utf-8') as f:
            prev_cfg = json.load(f)
    except (OSError, ValueError):
        pass
    if _lic.REQUIRED:
        share = True
        out('\n--- Общий каталог пресетов ---')
        out('  На пробном периоде проверенные пресеты анонимно уходят в общий каталог (модель карты, core/mem/PL, хешрейт,')
        out('  потребление; без имени рига, UUID и IP). С ключом это можно отключить командой /share off в Telegram.')
    elif 'catalog_share' in prev_cfg:
        share = bool(prev_cfg['catalog_share'])
        out('\n--- Общий каталог пресетов: оставляю прежний выбор (' + ('делюсь анонимно' if share else 'не делюсь') + ') ---')
    else:
        out('\n--- Общий каталог пресетов ---')
        out('  Бот может анонимно отправлять в общий каталог на сайте лучшие проверенные пресеты:')
        out('  модель карты, core/mem/PL, хешрейт и потребление. Без UUID карт, имени рига и IP.')
        out('  Это добровольно, отключается в любой момент (catalog_share в конфиге).')
        share = ask('Делиться пресетами с общим каталогом (y/n)', 'n').lower() in ('y', 'yes', 'д', 'да')
        if share:
            out('  Спасибо! Бот будет анонимно отправлять проверенные пресеты.')
        else:
            out('  Хорошо, пресеты никуда не отправляются. Передумаете: поставьте catalog_share: true в конфиге и перезапустите службу.')
    out('\n--- Telegram (можно пропустить, Enter) ---')
    token = secret('Токен бота от @BotFather (ввод скрыт): ').strip()
    owner = 0
    if token:
        out('  Откройте этого бота в Telegram и отправьте ему что угодно (например /start) —')
        out('  ID подхватим сами, вводить вручную не придётся.')
        ans = ask('Написали боту? Enter — найду сам, или сразу введите ID (узнать: @userinfobot)', '')
        if ans.strip().lstrip('-').isdigit():
            owner = int(ans)
        else:
            owner = owner_info(token)
            if owner:
                out(f'  Нашёл: ваш Telegram ID {owner}.')
            else:
                out('  Не нашёл сообщений от вас этому боту (рано или бот недоступен).')
                owner = ask_int('Ваш числовой Telegram ID (узнать: @userinfobot)', 0, 1, 10 ** 14)
    proxy = ask('HTTP-прокси для Telegram, если он закрыт у провайдера (Enter = не нужен)', '') if token else ''
    answers = {'rig_name': rig, 'algo': algo, 'miner': miner, 'miner_version': ver, 'unit': unit, 'workdir': workdir, 'psu_watts': psu, 'pl_total_max': cap, 'objective': obj, 'owner_id': owner, 'token': token, 'tg_proxy': proxy, 'catalog_share': share}
    out('\n' + box([('Риг', rig), ('Карт', len(gpus)), ('Алгоритм / майнер', f'{algo} / {miner} {ver}'), ('Блок питания', f'{psu} Вт, на карты до {cap} Вт'), ('Цель', obj), ('Общий каталог', 'делюсь анонимно' if share else 'не делюсь'), ('Telegram', 'подключён' if token else 'не подключён')], 'Итог'))
    if ask('Всё верно? Записать конфиг и запустить бота (y/n)', 'y').lower() not in ('y', 'yes', 'д', 'да'):
        out('Отменено, ничего не записано.')
        return None
    path = os.path.join(workdir, f'config.{rig}.json')
    raw = build_config(answers)
    if os.path.exists(path):
        try:
            with open(path, encoding='utf-8') as f:
                old = json.load(f)
            old.update(raw)
            raw = old
        except (OSError, ValueError):
            pass
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(raw, f, ensure_ascii=False, indent=2)
    os.chmod(tmp, 384)
    os.replace(tmp, path)
    out(f'Конфиг записан: {path}')
    if _lic.REQUIRED and (not os.path.exists(os.path.join(workdir, 'license.json'))):
        out('\n--- Пробный период ---')
        out((start_trial or _start_trial)(path))
    if install:
        out(install(workdir, path))
    if token and telegram_check:
        out(telegram_check(path))
    out('\nГотово. Статус: python3 -m ocbot --config ' + os.path.basename(path) + ' --service status')
    return path
