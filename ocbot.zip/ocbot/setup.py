from __future__ import annotations
import getpass
import json
import os
import random
import re
import socket
import statistics
import subprocess
import time
from typing import Callable, Dict, List, Optional
OBJECTIVES_RU = {'1': ('compromise', 'компромисс: максимум хешрейта при эффективности не хуже лучшей на 3%'), '2': ('efficiency', 'эффективность: максимум хешрейта на ватт, меньше счёт за электричество'), '3': ('hashrate', 'хешрейт: максимум хешрейта, мощность и тепло выше')}
OBJECTIVES_EN = {'1': ('compromise', 'compromise: max hashrate with efficiency no more than 3% below the best'), '2': ('efficiency', 'efficiency: max hashrate per watt, lower electricity bill'), '3': ('hashrate', 'hashrate: max hashrate, higher power draw and heat')}
OBJECTIVES = OBJECTIVES_RU

def _run(cmd: List[str], timeout: int=20) -> str:
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout).stdout
    except (OSError, subprocess.SubprocessError):
        return ''

def detect_gpus(run: Callable=_run) -> List[dict]:
    out = run(['nvidia-smi', '--query-gpu=index,uuid,name,power.min_limit,power.max_limit', '--format=csv,noheader,nounits'])
    gpus = []
    for ln in out.strip().splitlines():
        p = [x.strip() for x in ln.split(',')]
        if len(p) < 5:
            continue
        try:
            gpus.append({'slot': int(p[0]), 'uuid': p[1], 'name': p[2].replace('NVIDIA GeForce ', ''), 'pl_min': float(p[3]), 'pl_max': float(p[4])})
        except ValueError:
            continue
    return gpus

def _read_file(path: str) -> str:
    try:
        with open(path, encoding='utf-8', errors='ignore') as f:
            return f.read()
    except OSError:
        return ''

def detect_rig_name(read: Optional[Callable[[str], str]]=None) -> str:
    read = read or _read_file
    text = read('/hive-config/rig.conf')
    m = re.search('^WORKER_NAME=["\\\']?([^"\\\'\\n]+)', text, re.M)
    return m.group(1).strip() if m else ''

def detect_miner(read: Optional[Callable[[str], str]]=None) -> tuple:
    read = read or _read_file
    text = read('/hive-config/wallet.conf')
    name = ver = algo = ''
    for key, target in (('CUSTOM_MINER', 'n'), ('CUSTOM_NAME', 'n'), ('MINER', 'n'), ('CUSTOM_VERSION', 'v'), ('MINER_VERSION', 'v'), ('CUSTOM_ALGO', 'a'), ('ALGO', 'a'), ('MAIN_ALGO', 'a')):
        m = re.search(f"""^{key}=["\\']?([^"\\'\\n]+)""", text, re.M)
        if m:
            val = m.group(1).strip()
            if target == 'n' and (not name):
                name = val
            if target == 'v' and (not ver):
                ver = val
            if target == 'a' and (not algo):
                algo = val
    if not ver and name:
        m = re.match('^(.+?)[-_ ]v?(\\d[\\w.\\-]*)$', name)
        if m:
            name, ver = (m.group(1), m.group(2))
    return (name, ver, algo)
PORT_FLAGS = ('--metrics-port', '--api-port', '--http-port', '--port', '--api-bind')
DEFAULT_API_PORTS = (9200, 9900)
API_PATHS = ('/hive-stats', '/metrics')

def miner_ports(read: Optional[Callable[[str], str]]=None, pids: Optional[List[str]]=None) -> List[int]:
    read = read or _read_file
    ports = []
    if pids is None:
        try:
            pids = [p for p in os.listdir('/proc') if p.isdigit()]
        except OSError:
            return ports
    for pid in pids:
        raw = read(f'/proc/{pid}/cmdline').replace('\x00', '\n')
        args = raw.split('\n')
        for i, arg in enumerate(args):
            for fl in PORT_FLAGS:
                if arg == fl and i + 1 < len(args) and args[i + 1].isdigit():
                    ports.append(int(args[i + 1]))
                elif arg.startswith(fl + '=') and arg.split('=', 1)[1].isdigit():
                    ports.append(int(arg.split('=', 1)[1]))
    return ports

def probe_api(url: str, timeout: float=1.5, fetch: Optional[Callable[[str, float], str]]=None) -> Optional[dict]:
    if fetch is None:

        def fetch(u: str, t: float) -> str:
            import urllib.request
            with urllib.request.urlopen(u, timeout=t) as r:
                return r.read().decode('utf-8', 'replace')
    try:
        text = fetch(url, timeout)
        data = json.loads(text)
    except (OSError, ValueError):
        return None
    if not isinstance(data, dict) or not data:
        return None
    if isinstance(data.get('hs'), list):
        return {'kind': 'hive-stats', 'algo': str(data.get('algo') or ''), 'ver': str(data.get('ver') or '')}
    if any((isinstance(data.get(k), list) for k in ('miners', 'devices', 'gpus'))):
        return {'kind': 'metrics', 'algo': '', 'ver': ''}
    return None

def detect_miner_api(ports: Optional[List[int]]=None, fetch: Optional[Callable[[str, float], str]]=None) -> tuple:
    ports = ports if ports is not None else miner_ports()
    for port in list(dict.fromkeys(list(ports) + list(DEFAULT_API_PORTS))):
        for path in API_PATHS:
            url = f'http://127.0.0.1:{port}{path}'
            info = probe_api(url, fetch=fetch)
            if info:
                return (url, info['algo'], info['ver'])
    return ('', '', '')
LAST_STAT = '/run/hive/last_stat.json'

def _is_last_stat(data) -> bool:
    return isinstance(data, dict) and data.get('method') == 'stats' and isinstance(data.get('params'), dict) and isinstance(data['params'].get('miner_stats'), dict)

def detect_stats_file(globber: Optional[Callable[[str], list]]=None, reader: Optional[Callable[[str], str]]=None, mtimes: Optional[Dict[str, float]]=None, now: Optional[float]=None, max_age: float=120.0) -> str:
    import glob as _glob
    globber = globber or _glob.glob
    reader = reader or _read_file
    now = time.time() if now is None else now

    def mt(p: str) -> float:
        if mtimes is not None:
            return mtimes.get(p, 0.0)
        try:
            return os.path.getmtime(p)
        except OSError:
            return 0.0
    paths = set(globber('/run/hive/miners/*/stats.json')) | set(globber('/run/hive/miners/*.json'))
    if mt(LAST_STAT) > 0:
        paths.add(LAST_STAT)
    cands = sorted(paths, key=mt, reverse=True)
    for p in cands:
        if now - mt(p) > max_age:
            continue
        try:
            data = json.loads(reader(p))
        except ValueError:
            continue
        if isinstance(data, dict) and (isinstance(data.get('hs'), list) or _is_last_stat(data) or any((isinstance(data.get(k), list) for k in ('gpus', 'devices', 'miners')))):
            return p
    return ''

def detect_last_stat(reader: Optional[Callable[[str], str]]=None, mtimes: Optional[Dict[str, float]]=None, now: Optional[float]=None, max_age: float=120.0) -> dict:
    reader = reader or _read_file
    now = time.time() if now is None else now
    if mtimes is not None:
        mt = mtimes.get(LAST_STAT, 0.0)
    else:
        try:
            mt = os.path.getmtime(LAST_STAT)
        except OSError:
            return {}
    if mt <= 0 or now - mt > max_age:
        return {}
    try:
        data = json.loads(reader(LAST_STAT))
    except ValueError:
        return {}
    if not _is_last_stat(data):
        return {}
    p = data['params']
    ms = p['miner_stats']
    meta = p.get('meta') or {}
    return {'algo': str(ms.get('algo') or ''), 'ver': str(ms.get('ver') or ''), 'fs_id': str(meta.get('fs_id') or ''), 'miner': str(p.get('miner') or '')}
UNIT_SCALE = {'H/s': 1.0, 'KH/s': 1000.0, 'MH/s': 1000000.0, 'GH/s': 1000000000.0, 'TH/s': 1000000000000.0, 'PH/s': 1000000000000000.0}

def detect_unit(workdir: str, run: Callable=_run) -> str:
    out = run(['python3', os.path.join(workdir, 'tools', 'rgminer_stats.py'), '--unit', 'H/s'])
    try:
        data = json.loads(out)
    except ValueError:
        return ''
    vals = [v.get('hashrate') for v in data.values() if isinstance(v, dict) and v.get('hashrate')]
    if not vals:
        return ''
    typical = statistics.median(vals)
    best = min(UNIT_SCALE, key=lambda u: abs(typical / UNIT_SCALE[u] - 50))
    return best

def box(rows: List[tuple], title: str='') -> str:
    w1 = max((len(a) for a, _ in rows))
    inner = max(w1 + 3 + max((len(str(b)) for _, b in rows)), len(title))
    line = '+' + '-' * (inner + 2) + '+'
    out = [line]
    if title:
        out += ['| ' + title.ljust(inner) + ' |', line]
    for a, b in rows:
        out.append('| ' + (a.ljust(w1) + ' : ' + str(b)).ljust(inner) + ' |')
    out.append(line)
    return '\n'.join(out)

def build_config(a: Dict) -> dict:
    return {'rig_name': a['rig_name'], 'db_path': 'ocbot.db', 'state_path': 'ocbot_state.json', 'xid_log_path': 'ocbot_xid.log', 'owner_id': a.get('owner_id', 0), 'token': a.get('token', ''), 'tg_proxy': a.get('tg_proxy', ''), 'algo': a['algo'], 'miner': a['miner'], 'miner_version': a['miner_version'], 'stats_cmd': f"python3 {a['workdir']}/tools/rgminer_stats.py --unit {a['unit']} --window 300", 'psu_required': True, 'psu_watts': a['psu_watts'], 'pl_total_max': a['pl_total_max'], 'objective': a['objective'], 'catalog_share': bool(a.get('catalog_share', False))}

def _lic_site() -> str:
    try:
        from .config import Config
        return Config().site_url
    except Exception:
        return ''

def _detect_owner_id(token: str) -> int:
    from .telegram_setup import detect_owner_id
    return detect_owner_id(token)

def _detect_max_chat(token: str) -> str:
    from . import notifyhub
    return notifyhub.detect_max_chat_id(token)

def _start_trial(path: str) -> str:
    from .config import Config
    from . import license as lic
    return lic.start_trial(Config.load(path))

def _detect_lang_default(workdir: str) -> str:
    try:
        with open(os.path.join(workdir, 'ocbot_state.json'), encoding='utf-8') as f:
            data = json.load(f)
        return 'en' if (data.get('lang') or data.get('lang_detected')) == 'en' else 'ru'
    except (OSError, ValueError):
        return 'ru'

def run_setup(workdir: str, inp: Callable[[str], str]=input, secret: Callable[[str], str]=getpass.getpass, out: Callable[[str], None]=print, detect: Callable[[], List[dict]]=detect_gpus, miner_info: Callable[[], tuple]=detect_miner, unit_info: Callable[[str], str]=detect_unit, rig_name_info: Callable[[], str]=detect_rig_name, owner_info: Callable[[str], int]=_detect_owner_id, max_detect: Callable[[str], str]=_detect_max_chat, install: Optional[Callable[[str, str], str]]=None, telegram_check: Optional[Callable[[str, str], str]]=None, start_trial: Optional[Callable[[str], str]]=None) -> Optional[str]:

    def ask(prompt: str, default: str='') -> str:
        v = inp(f'{prompt}' + (f' [{default}]' if default else '') + ': ').strip()
        return v or default

    def ask_int(prompt: str, default: int=0, lo: int=1, hi: int=100000) -> int:
        while True:
            v = ask(prompt, str(default) if default else '')
            try:
                n = int(float(v.replace(',', '.')))
                if lo <= n <= hi:
                    return n
            except ValueError:
                pass
            out(L(f'  нужно число от {lo} до {hi}', f'  needs a number from {lo} to {hi}'))

    def L(ru: str, en: str) -> str:
        return en if lang == 'en' else ru
    lang_default = _detect_lang_default(workdir)
    out('Choose the bot language for the buyer / Выберите язык бота для покупателя:')
    out('  1) Русский')
    out('  2) English')
    v = ask('1/2', '2' if lang_default == 'en' else '1').strip().lower()
    lang = 'en' if v in ('2', 'en', 'english', 'англ', 'английский') else 'ru'
    out(L('\n=== Установка бота авто-подбора разгона ===\n', '\n=== Auto-overclock bot setup ===\n'))
    from . import license as _lic
    if _lic.REQUIRED:
        from . import consent
        from types import SimpleNamespace
        _c = SimpleNamespace(license_path=os.path.join(workdir, 'license.json'), site_url=_lic_site())
        if not consent.ensure(_c, inp=inp, out=out, lang=lang):
            return None
    gpus = detect()
    if not gpus:
        out(L('Карты NVIDIA не найдены (nvidia-smi ничего не вернул). Установку прерываю.', 'No NVIDIA cards found (nvidia-smi returned nothing). Aborting setup.'))
        return None
    slot_word = L('слот', 'slot')
    found_title = L(f'Найдено карт: {len(gpus)}', f'Cards found: {len(gpus)}')
    out(box([(f"{slot_word} {g['slot']}", f"{g['name']}  PL {g['pl_min']:.0f}..{g['pl_max']:.0f} {L('Вт', 'W')}  {g['uuid'][-8:]}") for g in gpus], found_title))
    mname, mver, malgo = miner_info()
    detected_unit = unit_info(workdir)
    out(L('\n--- Рига ---', '\n--- Rig ---'))
    rig_default = rig_name_info() or re.sub('[^\\w.-]', '_', socket.gethostname()) or 'rig'
    rig = ask(L('Имя рига', 'Rig name'), rig_default)
    auto_bits = []
    if malgo:
        algo = malgo
        auto_bits.append(L(f'алгоритм {algo}', f'algorithm {algo}'))
    else:
        algo = ask(L('Алгоритм', 'Algorithm'), 'pearl')
    if mname:
        miner = mname
        auto_bits.append(L(f'майнер {miner}', f'miner {miner}'))
    else:
        miner = ask(L('Майнер', 'Miner'), 'rgminer')
    if mver:
        ver = mver
        auto_bits.append(L(f'версия {ver}', f'version {ver}'))
    else:
        ver = ask(L('Версия майнера', 'Miner version'), '1.1.3b')
    if detected_unit:
        unit = detected_unit
        auto_bits.append(L(f'единица хешрейта {unit}', f'hashrate unit {unit}'))
    else:
        unit = ask(L('Единица хешрейта в статистике майнера (H/s, MH/s, GH/s, TH/s)', 'Hashrate unit in the miner stats (H/s, MH/s, GH/s, TH/s)'), 'TH/s')
    if auto_bits:
        out(L('  Из полётного листа HiveOS и показаний майнера определены: ', '  Detected from the HiveOS flight sheet and the miner readout: ') + ', '.join(auto_bits) + '.')
    out(L('\n--- Блок питания (бот не даст сумме мощности карт превысить лимит) ---', "\n--- Power supply (the bot will not let the cards' combined power exceed the limit) ---"))
    total_pl = sum((g['pl_max'] for g in gpus))
    out(L(f'  Карты суммарно могут тянуть до {total_pl:.0f} Вт на максимуме.', f'  The cards combined can draw up to {total_pl:.0f} W at maximum.'))
    psu_default = max(300, int(round(total_pl / 0.8 / 50)) * 50) if total_pl else 1600
    psu = ask_int(L('Мощность блока питания, Вт', 'PSU wattage, W'), psu_default, 300, 10000)
    cap = ask_int(L('Лимит суммарной мощности карт, Вт (по умолчанию 80% блока)', 'Total power limit for the cards, W (default 80% of the PSU)'), int(psu * 0.8 / 10) * 10, 100, psu)
    if total_pl <= cap:
        out(L(f'  (сумма максимумов PL всех карт {total_pl:.0f} Вт, лимит не будет мешать)', f"  (the sum of all cards' max PL is {total_pl:.0f} W, the limit will not get in the way)"))
    out(L('\n--- Цель подбора (потом меняется командой /mode) ---', '\n--- Tuning target (changeable later with /mode) ---'))
    objs = OBJECTIVES_EN if lang == 'en' else OBJECTIVES_RU
    for k, (_, d) in objs.items():
        out(f'  {k}) {d}')
    obj = objs.get(ask(L('Выберите 1, 2 или 3', 'Choose 1, 2 or 3'), '1'), objs['1'])[0]
    prev_cfg = {}
    try:
        with open(os.path.join(workdir, f'config.{rig}.json'), encoding='utf-8') as f:
            prev_cfg = json.load(f)
    except (OSError, ValueError):
        pass
    if _lic.REQUIRED:
        share = True
        out(L('\n--- Общий каталог пресетов ---', '\n--- Shared preset catalog ---'))
        out(L('  На пробном периоде проверенные пресеты анонимно уходят в общий каталог (модель карты, core/mem/PL, хешрейт,', '  During the trial, verified presets are always sent anonymously to the shared catalog (card model, core/mem/PL, hashrate,'))
        out(L('  потребление; без имени рига, UUID и IP). С ключом это можно отключить командой /share off в Telegram.', '  power draw; no rig name, card UUIDs or IP). With a license key this can be turned off with /share off in Telegram.'))
    elif 'catalog_share' in prev_cfg:
        share = bool(prev_cfg['catalog_share'])
        out(L('\n--- Общий каталог пресетов: оставляю прежний выбор (' + ('делюсь анонимно' if share else 'не делюсь') + ') ---', '\n--- Shared preset catalog: keeping the previous choice (' + ('sharing anonymously' if share else 'not sharing') + ') ---'))
    else:
        out(L('\n--- Общий каталог пресетов ---', '\n--- Shared preset catalog ---'))
        out(L('  Бот может анонимно отправлять в общий каталог на сайте лучшие проверенные пресеты:', '  The bot can anonymously send the best verified presets to the catalog on the site:'))
        out(L('  модель карты, core/mem/PL, хешрейт и потребление. Без UUID карт, имени рига и IP.', '  card model, core/mem/PL, hashrate and power draw. No card UUIDs, rig name or IP.'))
        out(L('  Это добровольно, отключается в любой момент (catalog_share в конфиге).', '  It is voluntary and can be turned off any time (catalog_share in the config).'))
        share = ask(L('Делиться пресетами с общим каталогом (y/n)', 'Share presets with the shared catalog (y/n)'), 'n').lower() in ('y', 'yes', 'д', 'да')
        if share:
            out(L('  Спасибо! Бот будет анонимно отправлять проверенные пресеты.', '  Thank you! The bot will anonymously send verified presets.'))
        else:
            out(L('  Хорошо, пресеты никуда не отправляются. Передумаете: поставьте catalog_share: true в конфиге и перезапустите службу.', '  OK, no presets will be sent anywhere. If you change your mind: set catalog_share: true in the config and restart the service.'))
    out(L('\n--- Канал связи (уведомления и команды) ---', '\n--- Messaging channel (notifications and commands) ---'))
    out(L('  1) Telegram — по умолчанию (Enter)', '  1) Telegram — the default (Enter)'))
    out(L('  2) ntfy — без регистрации вообще: приложение на телефон + имя темы, и готово', '  2) ntfy — no registration at all: an app on your phone + a topic name, done'))
    out(L('  3) MAX — российский мессенджер; нужен бот с business.max.ru (ИП/юрлицо/самозанятый)', '  3) MAX — Russian messenger; needs a bot from business.max.ru (sole trader/company/self-employed)'))
    out(L('  0) Пропустить — бот будет работать, команды отдавать через Hive Shell/SSH', '  0) Skip — the bot still runs; give commands via Hive Shell/SSH'))
    chan = ask(L('Выберите 1, 2, 3 или 0', 'Choose 1, 2, 3 or 0'), '1')
    token, owner, proxy = ('', 0, '')
    channel_name, channel_url = ('', '')
    if chan == '2':
        channel_name = 'ntfy'
        out(L('  Установите приложение ntfy (ntfy.sh) на телефон и подпишитесь на тему из следующего шага.', '  Install the ntfy app (ntfy.sh) on your phone and subscribe to the topic from the next step.'))
        server = ask(L('Сервер ntfy', 'ntfy server'), 'https://ntfy.sh').rstrip('/')
        default_topic = 'ocbot-' + ''.join((random.choice('abcdefghijklmnopqrstuvwxyz0123456789') for _ in range(8)))
        out(L('  Имя темы — это пароль: кто его знает, тот может писать боту команды.', '  The topic name is the password: whoever knows it can send commands to the bot.'))
        topic = ask(L('Имя темы (Enter — случайное)', 'Topic name (Enter — a random one)'), default_topic)
        ntfy_token = secret(L('Токен доступа темы (необязательно, Enter — открытая тема): ', 'Topic access token (optional, Enter — open topic): ')).strip()
        channel_url = f'{server}/{topic}' + (f'?token={ntfy_token}' if ntfy_token else '')
        out(L(f'  Подпишитесь в приложении на тему: {topic}', f'  Subscribe to this topic in the app: {topic}'))
    elif chan == '3':
        channel_name = 'max'
        out(L('  Нужен свой бот в MAX: business.max.ru → Чат-боты (профиль ИП/юрлица/самозанятого).', '  You need your own bot in MAX: business.max.ru → Chat bots (sole trader/company/self-employed profile).'))
        max_token = secret(L('Токен бота MAX (ввод скрыт): ', 'MAX bot token (hidden input): ')).strip()
        if max_token:
            out(L('  Напишите этому боту что угодно в MAX — chat_id подхватим сами, как у Telegram.', '  Write anything to this bot in MAX — we will pick up the chat_id ourselves, like Telegram.'))
            ans = ask(L('Написали боту? Enter — найду сам, или сразу введите chat_id', 'Did you message the bot? Enter — I will find it myself, or type the chat_id directly'), '')
            if ans.strip().lstrip('-').isdigit():
                max_chat = ans.strip().lstrip('-')
            else:
                max_chat = max_detect(max_token)
                if max_chat:
                    out(L(f'  Нашёл: chat_id {max_chat}.', f'  Found it: chat_id {max_chat}.'))
                else:
                    out(L('  Не нашёл сообщений (рано или бот недоступен).', '  Could not find any messages (too early, or the bot is unreachable).'))
                    max_chat = ask(L('chat_id чата (в MAX его подскажет встроенный бот «Узнать ID»)', 'Chat id (the built-in "Get ID" bot in MAX tells you)'), '').strip().lstrip('-')
            if max_chat:
                channel_name = 'max'
                channel_url = f'max://{max_chat}?token={max_token}'
            else:
                out(L('  Без chat_id канал MAX не подключаю.', '  Without a chat_id the MAX channel is not connected.'))
        else:
            out(L('  Токена нет — канал MAX пропущен.', '  No token — the MAX channel is skipped.'))
    elif chan != '0':
        out(L('\n--- Telegram (можно пропустить, Enter) ---', '\n--- Telegram (optional, press Enter to skip) ---'))
        token = secret(L('Токен бота от @BotFather (ввод скрыт): ', 'Bot token from @BotFather (hidden input): ')).strip()
        if token:
            out(L('  Откройте этого бота в Telegram и отправьте ему что угодно (например /start) —', '  Open this bot in Telegram and send it anything (for example /start) —'))
            out(L('  ID подхватим сами, вводить вручную не придётся.', '  we will pick up the ID ourselves, no need to type it in.'))
            ans = ask(L('Написали боту? Enter — найду сам, или сразу введите ID (узнать: @userinfobot)', "Did you message the bot? Enter — I'll find it myself, or type the ID directly (find it via @userinfobot)"), '')
            if ans.strip().lstrip('-').isdigit():
                owner = int(ans)
            else:
                owner = owner_info(token)
                if owner:
                    out(L(f'  Нашёл: ваш Telegram ID {owner}.', f'  Found it: your Telegram ID is {owner}.'))
                else:
                    out(L('  Не нашёл сообщений от вас этому боту (рано или бот недоступен).', '  Could not find any messages from you to this bot (too early, or the bot is unreachable).'))
                    owner = ask_int(L('Ваш числовой Telegram ID (узнать: @userinfobot)', 'Your numeric Telegram ID (find it via @userinfobot)'), 0, 1, 10 ** 14)
        proxy = ask(L('HTTP-прокси для Telegram, если он закрыт у провайдера (Enter = не нужен)', 'HTTP proxy for Telegram, if it is blocked by your provider (Enter = not needed)'), '') if token else ''
    answers = {'rig_name': rig, 'algo': algo, 'miner': miner, 'miner_version': ver, 'unit': unit, 'workdir': workdir, 'psu_watts': psu, 'pl_total_max': cap, 'objective': obj, 'owner_id': owner, 'token': token, 'tg_proxy': proxy, 'catalog_share': share}
    chosen = channel_name or ('Telegram' if token else L('нет', 'none'))
    summary_rows = [(L('Риг', 'Rig'), rig), (L('Карт', 'Cards'), len(gpus)), (L('Алгоритм / майнер', 'Algorithm / miner'), f'{algo} / {miner} {ver}'), (L('Блок питания', 'PSU'), L(f'{psu} Вт, на карты до {cap} Вт', f'{psu} W, up to {cap} W for the cards')), (L('Цель', 'Target'), obj), (L('Общий каталог', 'Shared catalog'), L('делюсь анонимно' if share else 'не делюсь', 'sharing anonymously' if share else 'not sharing')), (L('Канал', 'Channel'), chosen)]
    out('\n' + box(summary_rows, L('Итог', 'Summary')))
    if ask(L('Всё верно? Записать конфиг и запустить бота (y/n)', 'Is this all correct? Write the config and start the bot (y/n)'), 'y').lower() not in ('y', 'yes', 'д', 'да'):
        out(L('Отменено, ничего не записано.', 'Cancelled, nothing was written.'))
        return None
    path = os.path.join(workdir, f'config.{rig}.json')
    raw = build_config(answers)
    if os.path.exists(path):
        try:
            with open(path, encoding='utf-8') as f:
                old = json.load(f)
            old.update(raw)
            raw = old
        except (OSError, ValueError):
            pass
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(raw, f, ensure_ascii=False, indent=2)
    os.chmod(tmp, 384)
    os.replace(tmp, path)
    out(L(f'Конфиг записан: {path}', f'Config written: {path}'))
    from .state import State
    st = State(os.path.join(workdir, raw.get('state_path', 'ocbot_state.json')))
    st.data['lang'] = lang
    if channel_url:
        st.data.setdefault('notify_channels', {})[channel_name] = {'url': channel_url}
    st.save()
    if _lic.REQUIRED and (not os.path.exists(os.path.join(workdir, 'license.json'))):
        out(L('\n--- Пробный период ---', '\n--- Trial period ---'))
        out((start_trial or _start_trial)(path))
    if install:
        out(install(workdir, path))
    if token and telegram_check:
        from collections import Counter
        counts = Counter((g['name'] for g in gpus))
        cards_line = ', '.join((f'{n}× {name}' if n > 1 else name for name, n in counts.items()))
        out(telegram_check(path, L(f'Карты рига ({len(gpus)}): {cards_line}', f'Rig cards ({len(gpus)}): {cards_line}')))
    out(L('\nГотово. Статус: python3 -m ocbot --config ' + os.path.basename(path) + ' --service status', '\nDone. Status: python3 -m ocbot --config ' + os.path.basename(path) + ' --service status'))
    return path
