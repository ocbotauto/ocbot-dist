from __future__ import annotations
import argparse
import logging
import threading
from .agent import Agent
from .config import Config
from .db import DB
from .state import State

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument('--config', default='config.json')
    ap.add_argument('--sim', action='store_true', help='демо на симуляторе, без железа и Telegram')
    ap.add_argument('--mode', choices=['efficiency', 'compromise', 'hashrate', 'show', 'rig'], help='сменить цель поиска у работающего бота (или show: показать текущую) и выйти')
    ap.add_argument('--card', metavar='КАРТА', help='применить --mode только к одной карте (слот, метка, конец UUID); --mode rig вернёт её под общую цель')
    ap.add_argument('--tolerance', type=float, help='допуск эффективности в процентах для compromise (по умолчанию 3)')
    ap.add_argument('--restore', nargs='?', const='all', metavar='КАРТА', help='вернуть прежний проверенный пресет без нового подбора: --restore (все карты) или --restore 3 (слот, метка, конец UUID); можно вместе с --mode (тогда пресеты не переделываются)')
    ap.add_argument('--balance', nargs='?', const='run', choices=['run', 'show', 'deep'], help='распределение мощности по потенциалу карт (режим hashrate, ограниченный PL): run запустить, show показать максимум хешрейта карт и как они работают из-за лимита, deep то же с плотной сеткой core x PL')
    ap.add_argument('--optimize', nargs='?', const='all', metavar='КАРТА', help='подробный поиск лучшего вокруг готового пресета: --optimize (все карты по очереди) или --optimize 3')
    ap.add_argument('--params', nargs=2, metavar=('КАРТА', '2|4'), help='режим карты: --params 3 4 (плюс подбор фиксации частот ядра и памяти), --params all 2 (как раньше)')
    ap.add_argument('--table', action='store_true', help='сводная таблица по ригу: максимум, минимум и лучшая эффективность каждой карты с разгоном')
    ap.add_argument('--opt-gain', type=float, metavar='ПРОЦЕНТ', help='порог выигрыша оптимизации в процентах: вместе с --optimize на один запуск, отдельно как значение по умолчанию')
    ap.add_argument('--catalog', nargs='?', const='', metavar='МОДЕЛЬ', help='показать каталог лучших пресетов по моделям (можно часть названия: --catalog 3070)')
    ap.add_argument('--catalog-export', metavar='ФАЙЛ', help='записать каталог в файл для передачи другим людям')
    ap.add_argument('--catalog-import', metavar='ФАЙЛ', help='принять чужой файл каталога (как стартовые точки поиска)')
    ap.add_argument('--github-set', nargs='+', metavar='ПАРАМЕТР', help='записать репозиторий и токен GitHub для публикации каталога на сайт: --github-set владелец/репозиторий ТОКЕН [метка рига]')
    ap.add_argument('--catalog-publish', action='store_true', help='обновить каталог на GitHub прямо сейчас и показать результат')
    ap.add_argument('--keep', action='store_true', help='не переделывать готовые пресеты, новая цель только для следующих поисков')
    ap.add_argument('--service', choices=['install', 'start', 'stop', 'restart', 'remove', 'status'], help='автозапуск через systemd: install (поставить и запустить), stop (остановить и не стартовать после ребута), start (запустить и вернуть автозапуск), restart, status, remove')
    ap.add_argument('--repair-xid', type=int, metavar='МИНУТЫ', help='снять ложные «отвалы в работе» за последние МИНУТЫ (старые версии принимали Xid из старого буфера dmesg за свежие после перезапуска бота): вернуть пресет, убрать ложную границу, сбросить лесенку; бота остановить')
    ap.add_argument('--self-update', nargs='?', const='', metavar='URL|rollback', help='обновить бота одной командой (адрес по умолчанию update_url из конфига); rollback вернёт прежний код')
    ap.add_argument('--force', action='store_true', help='--self-update: даже во время 2-часовой проверки или если версия та же')
    ap.add_argument('--fix-external-gpus', nargs='?', const='apply', choices=['apply', 'restore'], help='карты в Thunderbolt не видны X-серверу: добавить AllowExternalGpus в скрипт Hive (нужна перезагрузка рига); restore вернёт копию')
    ap.add_argument('--uninstall', action='store_true', help='полностью удалить бота с рига: остановить, убрать автозапуск и стереть каталог (нужен --yes)')
    ap.add_argument('--yes', action='store_true', help='подтверждение для --uninstall')
    ap.add_argument('--keep-data', action='store_true', help='--uninstall: оставить конфиги, базу и лог')
    ap.add_argument('--repair', action='store_true', help='исправить ложные отвалы, записанные при перезапуске бота (бота предварительно остановить)')
    ap.add_argument('--telegram-set', nargs='+', metavar='ТОКЕН [ID]', help='записать токен бота (и, если указан, Telegram ID) в конфиг; без ID — найдёт его сам по вашему сообщению боту (напишите боту что угодно заранее)')
    ap.add_argument('--telegram-proxy', metavar='URL', help="прокси для Telegram, например http://192.168.3.5:8080 (пустая строка '' отключает)")
    ap.add_argument('--hwid', action='store_true', help=argparse.SUPPRESS)
    ap.add_argument('--activate', metavar='КЛЮЧ', help='активировать ключ с сайта на этом риге (OC-XXXXX-XXXXX-XXXXX-XXXXX)')
    ap.add_argument('--trial', action='store_true', help='пробный период на 3 дня для этого рига (один раз)')
    ap.add_argument('--accept-terms', action='store_true', help='подтвердить, что вы прочитали условия и отказ от ответственности и согласны с ними')
    ap.add_argument('--license-status', action='store_true', help='показать, действует ли лицензия этого рига')
    ap.add_argument('--setup', action='store_true', help='мастер установки: сам найдёт карты, спросит остальное, запустит бота')
    ap.add_argument('--telegram-test', action='store_true', help='проверить связь рига с Telegram: бот пришлёт вам тестовое сообщение')
    args = ap.parse_args()
    if args.accept_terms and (not (args.activate or args.trial)):
        from . import consent
        cfg = Config.load(args.config)
        if consent.ensure(cfg, assume_yes=True):
            print('Согласие записано. Запустите бота: systemctl restart ocbot')
        return
    if args.activate or args.trial:
        from . import license as lic
        from . import consent
        from .service import run_action
        import os
        cfg = Config.load(args.config)
        if not consent.ensure(cfg, assume_yes=args.accept_terms):
            return
        msg = lic.start_trial(cfg) if args.trial else lic.activate(cfg, args.activate)
        print(msg)
        if msg.startswith('Готово'):
            from . import selfupdate as su
            print(run_action('restart', su.workdir_of_code(), os.path.abspath(args.config)))
        return
    if args.hwid or args.license_status:
        from . import license as lic
        print('Идентификатор рига:', lic.hw_id())
        if args.license_status and (not lic.REQUIRED):
            print('Это тестовая сборка: лицензия не требуется.')
        elif args.license_status:
            cfg = Config.load(args.config)
            gate = lic.License(cfg)
            ok, why = gate.status()
            if ok and gate.trial:
                print('Пробный период: ' + why)
            else:
                print(('Лицензия действует: ' if ok else 'Лицензия НЕ действует: ') + why)
        return
    if args.self_update is not None:
        from . import selfupdate as su
        from .service import run_action
        import os
        cfg = Config.load(args.config)
        wd = su.workdir_of_code()
        if args.self_update != 'rollback' and (not args.force):
            if su.verification_running(DB(cfg.db_path), cfg.rig_name):
                print('Сейчас идёт 2-часовая проверка: перезапуск прервёт её, и она начнётся заново. Дождитесь конца или повторите с --force.')
                return
        try:
            if args.self_update == 'rollback':
                print(su.rollback(wd))
            else:
                print(su.install(wd, su.fetch(args.self_update or cfg.update_url, token=cfg.update_token), args.force))
        except su.UpdateError as e:
            print('Обновление не выполнено:', e)
            return
        print(run_action('restart', wd, os.path.abspath(args.config)))
        return
    if args.setup:
        import os
        from .service import run_action
        from .telegram_setup import check
        from .setup import run_setup
        run_setup(os.getcwd(), install=lambda wd, cfg: run_action('install', wd, cfg), telegram_check=lambda cfg, extra='': check(Config.load(cfg), extra=extra))
        return
    if args.telegram_set or args.telegram_test or args.telegram_proxy is not None:
        from .telegram_setup import check, detect_owner_id, set_config
        if args.telegram_set:
            if len(args.telegram_set) > 2:
                print('--telegram-set принимает только токен и, опционально, ID: --telegram-set ТОКЕН [ID]')
                return
            tok = args.telegram_set[0]
            if len(args.telegram_set) == 2:
                uid = args.telegram_set[1]
                if not uid.lstrip('-').isdigit():
                    print('ID должен быть числом (его показывает @userinfobot)')
                    return
                uid_int = int(uid)
            else:
                uid_int = detect_owner_id(tok)
                if not uid_int:
                    print('Не нашёл сообщений от вас этому боту: откройте его в Telegram, напишите что угодно (например /start) и повторите, либо укажите ID вручную: --telegram-set ТОКЕН ID (узнать: @userinfobot)')
                    return
                print(f'Нашёл ваш Telegram ID: {uid_int}.')
            set_config(args.config, tok, uid_int)
            print('Токен и ID записаны в конфиг (файл доступен только владельцу).')
        if args.telegram_proxy is not None:
            import json as _j
            raw = _j.load(open(args.config, encoding='utf-8'))
            raw['tg_proxy'] = args.telegram_proxy
            _j.dump(raw, open(args.config, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
            print('Прокси для Telegram записан в конфиг.' if args.telegram_proxy else 'Прокси для Telegram отключён.')
        print(check(Config.load(args.config)))
        return
    if args.repair_xid is not None:
        from datetime import datetime, timedelta, timezone
        from .repair import repair_false_xid_drops
        cfg = Config.load(args.config)
        since = (datetime.now(timezone.utc) - timedelta(minutes=args.repair_xid)).isoformat(timespec='seconds')
        fixed = repair_false_xid_drops(DB(cfg.db_path), since)
        print(f'Исправлено записей: {len(fixed)}')
        for u, pt, ts in fixed:
            print(f'  карта ...{u[-4:]}: core {pt[0]}, mem {pt[1]}, PL {pt[2]} ({ts}): пресет возвращён в проверенные')
        return
    if args.repair:
        from .backend import system_boot_time
        from .repair import repair_false_crashes
        cfg = Config.load(args.config)
        boot = system_boot_time()
        if boot is None:
            print('Не удалось определить время загрузки системы')
            return
        fixed = repair_false_crashes(DB(cfg.db_path), boot)
        print(f'Исправлено записей: {len(fixed)}')
        for u, pt, ts in fixed:
            print(f'  карта ...{u[-4:]}: core {pt[0]}, mem {pt[1]}, PL {pt[2]} ({ts})')
        return
    if args.table:
        cfg = Config.load(args.config)
        from .backend import NvidiaBackend
        ag = Agent(cfg, DB(cfg.db_path), NvidiaBackend(cfg), State(cfg.state_path))
        ag.refresh_gpus()
        print(ag.table_text('TH/s' if '--unit TH/s' in (cfg.stats_cmd or '') else 'H/s'))
        return
    if args.optimize or args.opt_gain is not None or args.params:
        import json
        import os
        cfg = Config.load(args.config)
        req = {}
        if args.params:
            req['params'] = [args.params[0], args.params[1]]
        if args.optimize:
            req['optimize'] = args.optimize
            if args.opt_gain is not None:
                req['gain'] = args.opt_gain
        elif args.opt_gain is not None:
            req['opt_gain'] = args.opt_gain
        tmp = cfg.control_path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(req, f)
        os.replace(tmp, cfg.control_path)
        print('Запрос передан: работающий бот применит его в течение десяти секунд.')
        return
    if args.balance:
        import json
        cfg = Config.load(args.config)
        if args.balance == 'show':
            from .backend import NvidiaBackend
            ag = Agent(cfg, DB(cfg.db_path), NvidiaBackend(cfg), State(cfg.state_path))
            print(ag.balance_report('TH/s' if '--unit TH/s' in (cfg.stats_cmd or '') else ''))
            return
        tmp = cfg.control_path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump({'balance': 'deep' if args.balance == 'deep' else True}, f)
        import os
        os.replace(tmp, cfg.control_path)
        print('Запрос передан: работающий бот запустит распределение мощности в течение десяти секунд.')
        return
    if args.github_set or args.catalog_publish:
        from . import publish
        if args.github_set:
            if len(args.github_set) < 2 or '/' not in args.github_set[0]:
                print("Формат: --github-set владелец/репозиторий 'ТОКЕН' [метка рига]")
                return
            publish.set_config(args.config, *args.github_set[:3])
            print('Репозиторий и токен записаны в конфиг (файл доступен только владельцу).')
        if args.catalog_publish or args.github_set:
            cfg = Config.load(args.config)
            print(publish.publish(cfg, DB(cfg.db_path)))
        return
    if args.catalog is not None or args.catalog_import or args.catalog_export:
        from . import catalog
        cfg = Config.load(args.config)
        db = DB(cfg.db_path)
        if args.catalog_import:
            ok, bad, notes = catalog.import_text(db, cfg, open(args.catalog_import, encoding='utf-8').read())
            print(f'Принято записей: {ok}, отклонено: {bad}')
            for n in notes:
                print('  ' + n)
        if args.catalog_export:
            with open(args.catalog_export, 'w', encoding='utf-8') as f:
                f.write(catalog.export_text(db))
            print(f'Каталог записан в {args.catalog_export}: записей {len(catalog.build(db))}')
        if args.catalog is not None:
            print(catalog.format_table(catalog.lookup(db, args.catalog), 'TH/s'))
        return
    if args.fix_external_gpus:
        from . import xfix
        if args.fix_external_gpus == 'restore':
            print('Скрипт Hive возвращён из копии, перезагрузите риг.' if xfix.restore() else 'Копии нет, откатывать нечего.')
        else:
            print(xfix.report())
        return
    if args.uninstall:
        import os
        from .service import uninstall
        if not args.yes:
            print(f"Будет удалено: служба ocbot и каталог {os.getcwd()} (код, база пресетов, конфиги, лог){(', кроме конфигов/базы/лога' if args.keep_data else '')}.\nЭто необратимо (пресеты пропадут). Подтвердить: добавьте --yes")
            return
        print(uninstall(os.getcwd(), args.keep_data))
        return
    if args.service:
        import os
        from .service import run_action
        print(run_action(args.service, os.getcwd(), args.config))
        return
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    if args.mode or args.restore:
        import json
        cfg = Config.load(args.config)
        if args.mode == 'show' and (not args.restore):
            m = State(cfg.state_path).data.get('mode')
            print(f"Цель: {m['objective']} (допуск {float(m['tolerance']):.0%}, задана командой)" if m else f'Цель: {cfg.objective} (допуск {cfg.eff_tolerance:.0%}, из конфига)')
            return
        req = {}
        if args.card and args.mode and (args.mode != 'show'):
            req.update({'objective': args.mode, 'card': args.card, 'retune': not (args.keep or args.restore)})
        elif args.mode and args.mode != 'show':
            req.update({'objective': args.mode, 'retune': not (args.keep or args.restore)})
            if args.tolerance is not None:
                req['tolerance'] = args.tolerance / 100
        if args.restore:
            req['restore'] = args.restore
        tmp = cfg.control_path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(req, f)
        import os
        os.replace(tmp, cfg.control_path)
        print(f'Запрос передан: {req}. Работающий бот применит его в течение десяти секунд, остановленный при запуске.')
        return
    if args.sim:
        import os
        import tempfile
        from .sim import FakeClock, SimBackend
        tmp = tempfile.mkdtemp(prefix='ocbot_sim_')
        cfg = Config(rig_name='sim', algo='demo', miner='demo', miner_version='1', db_path=':memory:', psu_required=False, state_path=os.path.join(tmp, 'state.json'), xid_log_path=os.path.join(tmp, 'xid.log'))
        clock = FakeClock()
        backend = SimBackend(clock, [{'uuid': 'GPU-SIM-1', 'mem_lim': 1200, 'core_lim': 100}, {'uuid': 'GPU-SIM-2', 'mem_lim': 900, 'core_lim': 100, 'late_mem_lim': 700}])
        agent = Agent(cfg, DB(cfg.db_path), backend, State(cfg.state_path), clock, notify=print)
        agent.startup()
        for _ in range(3):
            agent.cycle()
        for r in agent.db.q('select gpu_uuid, status, core_offset, mem_offset, power_limit, efficiency from profiles'):
            print(tuple(r))
        return
    cfg = Config.load(args.config)
    from .backend import NvidiaBackend
    db = DB(cfg.db_path)
    agent = Agent(cfg, db, NvidiaBackend(cfg), State(cfg.state_path))
    from . import license as lic
    lic.install_gate(agent, cfg)
    from . import publish
    if publish.configured(cfg):
        pub = publish.Publisher(cfg, db, notify=lambda text: agent.notify(text))
        prev = agent.on_verified
        agent.on_verified = lambda pid: (prev(pid), pub.poke())
        pub.poke()
        threading.Thread(target=pub.loop, daemon=True).start()
    from . import share
    if share.enabled(cfg, agent):
        sharer = share.Sharer(cfg, db, lic.hw_id(), agent=agent)
        prev2 = agent.on_verified
        agent.on_verified = lambda pid: (prev2(pid), sharer.poke())
        sharer.poke()
        threading.Thread(target=sharer.loop, daemon=True).start()

    def mirror_loop():
        import time as _t
        while True:
            try:
                agent.hive_mirror_tick()
            except Exception:
                pass
            _t.sleep(30)
    threading.Thread(target=mirror_loop, daemon=True).start()
    from .bot import REPLY_CHANNELS
    has_channels = any((c in REPLY_CHANNELS and (v or {}).get('url') for c, v in (agent.state.data.get('notify_channels') or {}).items()))
    if cfg.token and cfg.owner_id or has_channels:
        from .bot import run_when_ready
        from .tg import TgClient

        def start_telegram():
            bot = run_when_ready(cfg, db, agent, lambda: TgClient(cfg.token, cfg.tg_proxy, cfg.tg_api_base))
            if bot:
                bot.poll_forever()
        threading.Thread(target=start_telegram, daemon=True).start()
    agent.run_forever()
if __name__ == '__main__':
    main()
