from __future__ import annotations
import queue
import logging
import re
import time
from . import catalog, protocol
from .importer import CODE_DUPLICATE, import_preset, preset_message
log = logging.getLogger('ocbot')
REPLY_CHANNELS = ('ntfy', 'max')
GROUPS = [(('1. Состояние', '1. Status'), [('status', 'Состояние всех карт и пресетов', 'Status of all cards and presets'), ('card', 'Подробно по одной карте: <code>/card 3</code>', 'Details for one card: <code>/card 3</code>'), ('profiles', 'Готовые пресеты', 'Ready presets'), ('history', 'История карты: <code>/history 3</code>', 'Card history: <code>/history 3</code>'), ('slots', 'Статистика по слотам', 'Per-slot statistics'), ('table', 'Сводная таблица по ригу (максимум, минимум, лучшая эффективность), файл CSV', 'Rig summary table (max, min, best efficiency), CSV file')]), (('2. Подбор и проверка', '2. Tuning & verification'), [('tune', 'Подбор заново для одной карты: <code>/tune 3</code>', 'Re-tune one card: <code>/tune 3</code>'), ('newsearch', 'Новый подбор: <code>/newsearch 3</code> (одна карта) или <code>/newsearch all</code> (весь риг)', 'Fresh search: <code>/newsearch 3</code> (one card) or <code>/newsearch all</code> (whole rig)'), ('restore', 'Вернуть прежний пресет без нового подбора: <code>/restore 3</code> или <code>/restore all</code>', 'Restore the previous preset without a new search: <code>/restore 3</code> or <code>/restore all</code>'), ('verify', 'Двухчасовая проверка карты: <code>/verify 3</code>', 'Two-hour verification for a card: <code>/verify 3</code>'), ('optimize', 'Подробный поиск лучшего вокруг готового пресета: <code>/optimize 3</code>, <code>/optimize all</code>, <code>/optimize cancel</code>', 'Fine search around a ready preset: <code>/optimize 3</code>, <code>/optimize all</code>, <code>/optimize cancel</code>')]), (('3. Цель и режимы', '3. Target & modes'), [('mode', 'Цель подбора: efficiency, compromise, hashrate; для одной карты <code>/mode 3 hashrate</code>', 'Tuning target: efficiency, compromise, hashrate; for one card <code>/mode 3 hashrate</code>'), ('params', 'Режим карты: <code>/params 3 4</code> (плюс фиксация частот ядра и памяти), <code>/params all 4</code>, <code>/params 3 2</code>', 'Card mode: <code>/params 3 4</code> (plus core/memory clock lock), <code>/params all 4</code>, <code>/params 3 2</code>')]), (('4. Управление', '4. Control'), [('safe', 'Безопасные настройки на карты', 'Apply safe settings to the cards'), ('stop', 'Остановить автоматику', 'Stop the automation'), ('resume', 'Продолжить автоматику', 'Resume the automation'), ('queue', 'Очередь невыполненных команд, очистить: <code>/queue clear</code>', 'Pending command queue, clear it: <code>/queue clear</code>'), ('update', 'Обновить бота одной командой: <code>/update</code> (при идущей проверке откажет), <code>/update force</code>, <code>/update rollback</code>', 'Update the bot with one command: <code>/update</code> (refuses during an active verification), <code>/update force</code>, <code>/update rollback</code>'), ('faulty', 'Пометить карту неисправной: <code>/faulty 3</code> или снять пометку: <code>/faulty 3 off</code>', 'Mark a card as faulty: <code>/faulty 3</code> or clear it: <code>/faulty 3 off</code>'), ('hive', 'Дублировать события панели Hive в Telegram: <code>/hive on</code>, <code>/hive off</code>', 'Mirror Hive panel events to Telegram: <code>/hive on</code>, <code>/hive off</code>')]), (('5. Питание', '5. Power'), [('pl', 'Замок мощности: <code>/pl 3 150</code> или снять: <code>/pl 3 off</code>', 'Power limit lock: <code>/pl 3 150</code> or clear it: <code>/pl 3 off</code>'), ('psu', 'Нагрузка на блок питания; сменить вводные: <code>/psu 1400 1200</code>', 'PSU load; change the inputs: <code>/psu 1400 1200</code>'), ('balance', 'Распределение лимита PL: /balance (показать), <code>/balance run</code> (раздать), <code>/balance deep</code> (плотный перебор)', 'Distribute the PL budget: /balance (show), <code>/balance run</code> (apply), <code>/balance deep</code> (dense search)')]), (('6. Каталог и обмен', '6. Catalog & sharing'), [('forward', 'Прислать пресет карты строкой OCP1 для пересылки в общую группу: <code>/forward 3</code>', "Send a card's preset as an OCP1 line to forward into the shared group: <code>/forward 3</code>"), ('export', 'Выгрузить пресеты файлом', 'Export presets as a file'), ('models', 'Каталог лучших пресетов по моделям карт', 'Catalog of best presets by card model'), ('model', 'Пресеты одной модели: <code>/model 3070</code>', 'Presets for one model: <code>/model 3070</code>'), ('catalog', 'Файл каталога для друзей (без UUID и имён ригов)', 'Catalog file to share with friends (no rig names or card UUIDs)')]), (('7. Лицензия', '7. License'), [('terms', 'Условия и отказ от ответственности; подтвердить согласие: <code>/terms accept</code>', 'Terms and disclaimer; confirm agreement: <code>/terms accept</code>'), ('activate', 'Активировать купленный ключ (свой вместо OC-...): <code>/activate OC-XXXXX-XXXXX-XXXXX-XXXXX</code>', 'Activate a purchased key (use your own instead of OC-...): <code>/activate OC-XXXXX-XXXXX-XXXXX-XXXXX</code>')]), (('8. Справка', '8. Help'), [('help', 'Список команд', 'List of commands'), ('lang', 'Язык бота: <code>/lang en</code>, <code>/lang ru</code>, <code>/lang auto</code>', 'Bot language: <code>/lang en</code>, <code>/lang ru</code>, <code>/lang auto</code>'), ('notify', 'Оповещения кроме Telegram: <code>/notify</code> (список), <code>/notify webhook URL</code>, <code>/notify discord URL</code>, <code>/notify ntfy URL</code>, <code>/notify max ТОКЕН CHAT_ID</code>, <code>/notify off канал</code>, <code>/notify test</code>', 'Extra notifications: <code>/notify</code> (list), <code>/notify webhook URL</code>, <code>/notify discord URL</code>, <code>/notify ntfy URL</code>, <code>/notify max TOKEN CHAT_ID</code>, <code>/notify off channel</code>, <code>/notify test</code>')]), (('9. Удаление', '9. Removal'), [('uninstall', 'Полное удаление бота с рига: /uninstall, затем подтвердить: <code>/uninstall confirm</code> (чтобы оставить конфиги, базу и лог: <code>/uninstall confirm keep-data</code>)', 'Fully remove the bot from this rig: /uninstall, then confirm with: <code>/uninstall confirm</code> (to keep the configs, database and log: <code>/uninstall confirm keep-data</code>)')])]

def _commands_for(lang: str) -> list:
    en = lang == 'en'
    return [(c, d_en if en else d_ru) for _, items in GROUPS for c, d_ru, d_en in items]
COMMANDS = _commands_for('ru')

def help_text(lang: str, license_line: str='') -> str:
    en = lang == 'en'
    header = 'Bot commands' if en else 'Команды бота'
    if license_line:
        header += '\n' + license_line
    blocks = []
    for (title_ru, title_en), items in GROUPS:
        title = title_en if en else title_ru
        lines = '\n'.join((f'<code>/{c}</code> : {(d_en if en else d_ru)}' for c, d_ru, d_en in items))
        blocks.append(title + '\n' + lines)
    footer = "\n\nA card can be given by its slot number, label, or the last characters of its UUID. To forward a card's preset to the shared group: <code>/forward 3</code>." if en else '\n\nКарту можно указать номером слота, меткой или последними символами UUID. Чтобы переслать пресет карты в общую группу: <code>/forward 3</code>.'
    return header + '\n\n' + '\n\n'.join(blocks) + footer

def psu_help(lang: str) -> str:
    if lang == 'en':
        return "One PSU for the whole rig: <code>/psu 1400 1200</code> [base]\n1400: PSU wattage, W; 1200: total PL limit for all cards, W; base (optional): system power draw without the cards, W.\n\nMultiple PSUs:\n<code>/psu add PSU1 1600 1300</code>: add a unit (name, wattage, total PL limit for its cards)\n<code>/psu cards PSU1 0,1,2,3</code>: which slots are powered by this unit (ranges like 0-3 allowed)\n<code>/psu system PSU2</code> [W]: which unit powers the rest of the system (motherboard, CPU); wattage optional\n<code>/psu limit PSU1 1200</code>: total PL limit for this unit's cards\n<code>/psu del PSU2</code>: remove a unit; <code>/psu cancel</code>: discard unfinished edits.\nEdits apply once every card in the rig is assigned to a unit."
    return 'Один БП на весь риг: <code>/psu 1400 1200</code> [база]\n1400: мощность БП, Вт; 1200: лимит суммы PL всех карт, Вт; база (необязательно): потребление системы без карт, Вт.\n\nНесколько БП:\n<code>/psu add PSU1 1600 1300</code>: добавить блок (имя, мощность, лимит суммы PL его карт)\n<code>/psu cards PSU1 0,1,2,3</code>: какие слоты питаются от блока (можно 0-3)\n<code>/psu system PSU2</code> [Вт]: на каком блоке вся остальная система (материнка, процессор), необязательно сколько Вт\n<code>/psu limit PSU1 1200</code>: лимит суммы PL карт этого блока\n<code>/psu del PSU2</code>: убрать блок; <code>/psu cancel</code>: сбросить недоделанные правки.\nПравки применяются, когда все карты рига привязаны к блокам.'

def lic_required() -> bool:
    from . import license as lic
    return bool(lic.REQUIRED)

class Bot:

    def __init__(self, cfg, db, agent, tg):
        self.cfg, self.db, self.agent, self.tg = (cfg, db, agent, tg)
        self.username = ''
        try:
            self.username = (tg.get_me().get('username') or '').lower()
        except Exception as e:
            log.warning('getMe недоступен (%s), продолжаю без меню команд Telegram', e)
        try:
            self.offset = int(self.agent.state.data.get('tg_offset') or 0)
        except (TypeError, ValueError):
            self.offset = 0
        self.lang = self._lang_override() or 'ru'
        try:
            tg.set_commands(_commands_for(self.lang))
        except Exception as e:
            log.warning('меню команд не установлено: %s', e)

    def L(self, ru: str, en: str) -> str:
        return en if self.lang == 'en' else ru

    def _lang_override(self):
        return self.agent.state.data.get('lang')

    def _update_menu(self) -> None:
        try:
            self.tg.set_commands(_commands_for(self.lang))
        except Exception as e:
            log.warning('меню команд не обновлено: %s', e)

    def _unit(self) -> str:
        parts = (self.cfg.stats_cmd or '').split()
        return parts[parts.index('--unit') + 1] if '--unit' in parts and parts.index('--unit') + 1 < len(parts) else 'H/s'

    def say(self, text: str, chat_id: int | str | None=None, parse_mode: str | None=None) -> None:
        try:
            if isinstance(chat_id, str):
                return self._channel_say(chat_id, text, parse_mode)
            self.tg.send(chat_id or self.cfg.owner_id, text, parse_mode=parse_mode)
        except Exception as e:
            log.warning('telegram send: %s', e)

    def _channel_say(self, channel: str, text: str, parse_mode: str | None=None) -> None:
        from . import notifyhub
        url = ((self.agent.state.data.get('notify_channels') or {}).get(channel) or {}).get('url')
        if not url:
            return
        if parse_mode:
            text = re.sub('<[^>]+>', '', text).replace('&lt;', '<').replace('&gt;', '>').replace('&amp;', '&')
        notifyhub.SENDERS[channel](url, self.cfg.rig_name, text)

    def _send_file(self, chat_id: int | str, filename: str, content: bytes) -> None:
        if isinstance(chat_id, str):
            return self.say(self.L('Файлы бот присылает только в Telegram, этот канал — для команд и текста. Тот же файл в Telegram: та же команда.', 'Files are only sent to Telegram; this channel is for commands and text. The same file is in Telegram: the same command.'), chat_id)
        self.tg.send_document(chat_id, filename, content)

    def notify_all(self, text: str) -> None:
        self.say(text)
        channels = self.agent.state.data.get('notify_channels')
        if channels:
            from . import notifyhub
            self._dispatch(notifyhub.broadcast, channels, self.cfg.rig_name, text)

    def _dispatch(self, fn, *args) -> None:
        import threading
        threading.Thread(target=fn, args=args, daemon=True).start()

    def send_preset(self, profile_id: str) -> None:
        if getattr(self.cfg, 'send_preset_export', False):
            self.say(preset_message(self.db, profile_id))

    def _ensure_username(self) -> None:
        if self.cfg.token and (not self.username):
            try:
                self.username = (self.tg.get_me().get('username') or '').lower()
            except Exception:
                pass

    def poll_forever(self) -> None:
        while True:
            self._ensure_username()
            if self.cfg.token:
                try:
                    for u in self.tg.get_updates(self.offset, timeout=5 if self._reply_channels() else 30):
                        self.offset = u['update_id'] + 1
                        try:
                            self.agent.state.data['tg_offset'] = self.offset
                            self.agent.state.save()
                        except (OSError, RuntimeError, TypeError, ValueError):
                            pass
                        self.handle(u)
                except Exception as e:
                    log.warning('telegram poll: %s', e)
                    time.sleep(5)
            else:
                time.sleep(3)
            self.poll_channels()

    def _reply_channels(self) -> dict:
        channels = self.agent.state.data.get('notify_channels') or {}
        return {c: cfg for c, cfg in channels.items() if c in REPLY_CHANNELS and (cfg or {}).get('url')}

    def poll_channels(self) -> None:
        from . import notifyhub
        if not hasattr(self, '_chan_markers'):
            self._chan_markers = {}
        for channel, cfg in self._reply_channels().items():
            try:
                if channel == 'ntfy':
                    since = self._chan_markers.setdefault(channel, str(int(time.time())))
                    msgs, self._chan_markers[channel] = notifyhub.poll_ntfy(cfg['url'], since)
                else:
                    marker = self._chan_markers.setdefault(channel, '')
                    msgs, self._chan_markers[channel] = notifyhub.poll_max(cfg['url'], marker)
                for text in msgs:
                    self.handle_channel_text(channel, text)
            except Exception as e:
                log.warning('poll %s: %s', channel, e)

    def handle_channel_text(self, channel: str, text: str) -> None:
        text = text.strip()
        if not text:
            return
        self.lang = self._lang_override() or self.lang
        if protocol.find_line(text):
            return self.on_preset(text, channel, self.cfg.owner_id, quiet=False)
        if not text.startswith('/'):
            return
        head, *args = text.split()
        name, _, target = head[1:].partition('@')
        if target and target.lower() != self.username:
            return
        self.on_command(name.lower(), args, channel)

    def handle(self, update: dict) -> None:
        msg = update.get('message')
        if not msg:
            return
        user = msg.get('from') or {}
        if user.get('is_bot') or user.get('id') != self.cfg.owner_id:
            return
        code = (user.get('language_code') or '').lower()
        detected = 'en' if code and (not code.startswith('ru')) else 'ru'
        self.lang = self._lang_override() or detected
        if not self._lang_override() and self.agent.state.data.get('lang_detected') != detected:
            self.agent.state.data['lang_detected'] = detected
            self.agent.state.save()
        chat = msg['chat']
        reply_to = chat['id']
        if 'document' in msg:
            return self.on_document(msg, reply_to, user['id'])
        text = (msg.get('text') or '').strip()
        if protocol.find_line(text):
            return self.on_preset(text, reply_to, user['id'], quiet=chat['type'] != 'private')
        if text.startswith('/'):
            head, *args = text.split()
            name, _, target = head[1:].partition('@')
            if chat['type'] != 'private' and (not target or target.lower() != self.username):
                return
            self.on_command(name.lower(), args, reply_to)

    def on_preset(self, text: str, chat_id: int, user_id: int, quiet: bool) -> None:
        ok, code, why = import_preset(self.db, self.cfg, text, user_id, self.lang)
        if not quiet or (not ok and code != CODE_DUPLICATE):
            self.say(self.L('Пресет: ', 'Preset: ') + why, chat_id)

    def on_document(self, msg: dict, chat_id: int, user_id: int) -> None:
        raw = self.tg.download(msg['document']['file_id']).decode('utf-8', 'replace')
        if catalog.looks_like_catalog(raw):
            ok, bad, notes = catalog.import_text(self.db, self.cfg, raw, self.lang)
            tail = '\n' + '\n'.join(notes[:8]) if notes else ''
            return self.say(self.L(f'Каталог: принято записей {ok}, отклонено {bad}. Чужие пресеты станут стартовой точкой для карт без своей истории (поиск и 2-часовая проверка остаются).', f"Catalog: accepted {ok} entries, rejected {bad}. Other people's presets become a starting point for cards with no history of their own (the search and 2-hour verification still run).") + tail, chat_id)
        ok = bad = dup = 0
        for ln in raw.splitlines():
            if ln.startswith(protocol.PREFIX + '|'):
                good, code, why = import_preset(self.db, self.cfg, ln, user_id, self.lang)
                if good:
                    ok += 1
                elif code == CODE_DUPLICATE:
                    dup += 1
                else:
                    bad += 1
        self.say(self.L(f'Импорт: принято {ok}, дубликатов {dup}, отклонено {bad}', f'Import: accepted {ok}, duplicates {dup}, rejected {bad}'), chat_id)

    def on_command(self, name: str, args: list, chat_id: int) -> None:
        try:
            if name == 'queue':
                if args and args[0].lower() == 'clear':
                    n = self.agent.queue_clear()
                    return self.say(self.L(f'Очередь очищена, убрано команд: {n}', f'Queue cleared, commands removed: {n}'), chat_id)
                return self.say(self.agent.queue_report(), chat_id)
            self._run_command(name, args, chat_id)
        except queue.Full:
            self.say(self.L(f'Очередь переполнена ({self.cfg.queue_cap} команд). Посмотреть: /queue, очистить: /queue clear', f'Queue is full ({self.cfg.queue_cap} commands). View it: /queue, clear it: /queue clear'), chat_id)
    TRIAL_COMMANDS = {'share', 'forward', 'start', 'help', 'status', 'card', 'stop', 'resume', 'safe', 'table', 'psu', 'pl', 'balance', 'queue', 'lang', 'notify', 'uninstall', 'activate', 'update', 'terms'}

    def not_found(self, name: str) -> str:
        return self.L(f'Карта «{name}» не найдена, смотрите /status', f'Card «{name}» not found, see /status')

    def _on_notify(self, args: list, chat_id: int) -> None:
        from . import notifyhub
        sub = args[0].lower() if args else ''
        channels = self.agent.state.data.get('notify_channels') or {}
        if not sub or sub == 'list':
            if not channels:
                return self.say(self.L('Дополнительных каналов нет, оповещения идут только в Telegram.\nДобавить: /notify ntfy URL (без регистрации, команды тоже принимаются), /notify webhook URL, /notify discord URL, /notify max ТОКЕН CHAT_ID', 'No extra channels yet, notifications only go to Telegram.\nAdd one: /notify ntfy URL (no registration, commands accepted too), /notify webhook URL, /notify discord URL, /notify max TOKEN CHAT_ID'), chat_id)
            lines = []
            for c, cfg in channels.items():
                url = cfg.get('url', '')
                base = url.split('?', 1)[0]
                lines.append(f'{c}: {base} (параметры скрыты)' if '?' in url else f'{c}: {url}')
            return self.say(self.L('Дополнительные каналы:\n', 'Extra channels:\n') + '\n'.join(lines) + self.L('\n\nПроверить: /notify test\nВыключить: /notify off <канал>', '\n\nTest: /notify test\nTurn off: /notify off <channel>'), chat_id)
        if sub == 'off':
            key = args[1].lower() if len(args) > 1 else ''
            if key in channels:
                del self.agent.state.data['notify_channels'][key]
                self.agent.state.save()
                return self.say(self.L(f'Канал «{key}» выключен.', f'Channel "{key}" turned off.'), chat_id)
            return self.say(self.L(f'Канал «{key}» не настроен, смотрите /notify', f'Channel "{key}" is not set up, see /notify'), chat_id)
        if sub == 'test':
            if not channels:
                return self.say(self.L('Нет дополнительных каналов — сначала настройте: /notify webhook URL', 'No extra channels yet — set one up first: /notify webhook URL'), chat_id)
            errors = notifyhub.broadcast(channels, self.cfg.rig_name, self.L('Тестовое сообщение OCBot.', 'OCBot test message.'))
            bad = {c for c, _ in errors}
            lines = [self.L(f'  {c}: ок', f'  {c}: ok') for c in channels if c not in bad]
            lines += [self.L(f'  {c}: ошибка ({err})', f'  {c}: error ({err})') for c, err in errors]
            return self.say(self.L('Результат проверки:\n', 'Test result:\n') + '\n'.join(lines), chat_id)
        if sub == 'max':
            token = args[1] if len(args) > 1 else ''
            chat_id = args[2].lstrip('-') if len(args) > 2 else ''
            if not token or not chat_id:
                return self.say(self.L('Формат: /notify max ТОКЕН CHAT_ID\nТокен бота: business.max.ru → Чат-боты → ⋮ → Настройки. Напишите боту в MAX и спросите chat_id у встроенного бота «Узнать ID».', 'Format: /notify max TOKEN CHAT_ID\nBot token: business.max.ru → Chat bots → ⋮ → Settings. Write to your bot in MAX and get chat_id from the built-in "Get ID" bot.'), chat_id)
            self.agent.state.data.setdefault('notify_channels', {})['max'] = {'url': f'max://{chat_id}?token={token}'}
            self.agent.state.save()
            return self.say(self.L('Канал MAX сохранён. Команды (/status, /tune 3 и остальные) можно писать прямо этому боту в MAX. Проверить: /notify test', 'MAX channel saved. Commands (/status, /tune 3 and the rest) can be typed to this bot in MAX. Test it: /notify test'), chat_id)
        if sub in notifyhub.SENDERS:
            url = args[1] if len(args) > 1 else ''
            if not url.startswith('https://'):
                return self.say(self.L('Нужна ссылка вида https://... (её сами укажите после названия канала)', 'Need a link like https://... (give it right after the channel name)'), chat_id)
            self.agent.state.data.setdefault('notify_channels', {})[sub] = {'url': url}
            self.agent.state.save()
            if sub == 'ntfy':
                return self.say(self.L('Канал ntfy сохранён — уведомления и команды (например /status) пойдут через этот топик; допишите в его конец ?token=tk_... если тема закрыта токеном. Проверить: /notify test', 'ntfy channel saved — notifications and commands (like /status) go through this topic; append ?token=tk_... if the topic is token-protected. Test it: /notify test'), chat_id)
            return self.say(self.L(f'Канал «{sub}» сохранён. Проверить: /notify test', f'Channel "{sub}" saved. Test it: /notify test'), chat_id)
        self.say(self.L('Формат: /notify (список), /notify webhook URL, /notify discord URL, /notify ntfy URL, /notify max ТОКЕН CHAT_ID, /notify off канал, /notify test', 'Format: /notify (list), /notify webhook URL, /notify discord URL, /notify ntfy URL, /notify max TOKEN CHAT_ID, /notify off channel, /notify test'), chat_id)

    def _run_command(self, name: str, args: list, chat_id: int) -> None:
        a, db, cfg = (self.agent, self.db, self.cfg)
        arg = args[0] if args else None
        if getattr(a, 'trial', False) and name not in self.TRIAL_COMMANDS:
            site = getattr(cfg, 'site_url', '')
            return self.say(self.L('Эта команда доступна с ключом, на пробном периоде работает режим «Компромисс» и основные команды: /status, /card, /stop, /resume, /safe, /table, /psu, /pl, /balance, /help.' + (f'\nКупить ключ: {site}' if site else '') + '\nЕсть ключ? Активируйте: <code>/activate OC-XXXXX-XXXXX-XXXXX-XXXXX</code>.', 'This command needs a license key. During the trial, only "Compromise" mode and the basic commands are available: /status, /card, /stop, /resume, /safe, /table, /psu, /pl, /balance, /help.' + (f'\nBuy a key: {site}' if site else '') + '\nAlready have a key? Activate it: <code>/activate OC-XXXXX-XXXXX-XXXXX-XXXXX</code>.'), chat_id, parse_mode='HTML')
        if name == 'terms':
            from . import consent
            v = (arg or '').lower()
            if v in ('accept', 'принять', 'согласен', 'да', 'yes', 'y'):
                consent.record(cfg)
                lc = getattr(a, 'lic', None)
                if lc is not None:
                    try:
                        lc.status()
                    except Exception:
                        log.exception('не удалось обновить состояние лицензии сразу после /terms accept')
                return self.say(self.L('Принято: условия и отказ от ответственности подтверждены.', 'Accepted: terms and disclaimer confirmed.'), chat_id)
            return self.say(consent.text(cfg, self.lang) + self.L('\n\nЕсли согласны — подтвердите: <code>/terms accept</code>.', '\n\nIf you agree, confirm it: <code>/terms accept</code>.'), chat_id, parse_mode='HTML')
        if name == 'activate':
            from . import license as lic
            if not arg:
                return self.say(self.L('Формат: <code>/activate OC-XXXXX-XXXXX-XXXXX-XXXXX</code> (ключ выдаётся после покупки на сайте).', 'Format: <code>/activate OC-XXXXX-XXXXX-XXXXX-XXXXX</code> (the key is issued after purchase on the site).'), chat_id, parse_mode='HTML')
            msg = lic.activate(cfg, arg)
            lc = getattr(a, 'lic', None)
            if lc is not None:
                try:
                    lc.status()
                except Exception:
                    log.exception('не удалось обновить состояние лицензии сразу после /activate')
            return self.say(msg, chat_id)
        if name == 'lang':
            v = (arg or '').lower()
            if v in ('en', 'english', 'англ', 'английский'):
                a.state.data['lang'] = 'en'
                a.state.save()
                self.lang = 'en'
                self._update_menu()
                self.say('Language set to English.', chat_id)
            elif v in ('ru', 'рус', 'русский'):
                a.state.data['lang'] = 'ru'
                a.state.save()
                self.lang = 'ru'
                self._update_menu()
                self.say('Язык переключён на русский.', chat_id)
            elif v in ('auto', 'авто'):
                a.state.data.pop('lang', None)
                a.state.save()
                self._update_menu()
                self.say(self.L('Язык теперь определяется автоматически по языку вашего Telegram.', 'Language is now auto-detected from your Telegram app language.'), chat_id)
            else:
                self.say(self.L(f'Текущий язык: {self.lang}. Сменить: /lang en, /lang ru, вернуть автоопределение: /lang auto', f'Current language: {self.lang}. Change it: /lang en, /lang ru, back to auto-detect: /lang auto'), chat_id)
        elif name == 'notify':
            self._on_notify(args, chat_id)
        elif name in ('start', 'help'):
            self.say(help_text(self.lang, a.license_line()), chat_id, parse_mode='HTML')
        elif name == 'status':
            text = a.status_text(self._unit())
            while text:
                cut = text if len(text) <= 3800 else text[:text.rfind('\n', 0, 3800)]
                self.say(cut, chat_id)
                text = text[len(cut):].lstrip('\n')
        elif name == 'profiles':
            rows = db.q("select p.*, g.label from profiles p join gpus g on g.uuid=p.gpu_uuid where p.status in ('verified','imported','candidate') order by g.uuid, p.created_at desc")
            self.say('\n'.join((f"{r['label'] or r['gpu_uuid'][-8:]} {r['algo']}/{r['miner']} {r['miner_version']} [{r['status']}] core {r['core_offset']} mem {r['mem_offset']} PL {r['power_limit']}" for r in rows)) or self.L('Профилей пока нет', 'No profiles yet'), chat_id)
        elif name == 'history' and arg:
            u = a.resolve(arg)
            rows = db.q('select ts, reason from preset_changes where gpu_uuid=? order by id desc limit 10', (u,)) if u else []
            crashes = db.q("select started_at, crash_cause, core_offset, mem_offset, power_limit from runs where gpu_uuid=? and status='crash' order by id desc limit 5", (u,)) if u else []
            crash_word = self.L('отвал', 'crash')
            self.say('\n'.join([f"{r['ts']}: {r['reason']}" for r in rows] + [f"{crash_word} {r['started_at']} ({r['crash_cause']}): core {r['core_offset']}, mem {r['mem_offset']}, PL {r['power_limit']}" for r in crashes]) or self.L('Истории нет', 'No history'), chat_id)
        elif name == 'slots':
            rows = db.slot_stats()
            if self.lang == 'en':
                self.say('\n'.join((f"{r['rig']}/slot {r['slot']}: runs {r['runs_total']}, crashes {r['crashes']}, efficiency {r['avg_efficiency'] or 0:.4f}" for r in rows)) or 'No data yet', chat_id)
            else:
                self.say('\n'.join((f"{r['rig']}/слот {r['slot']}: прогонов {r['runs_total']}, отвалов {r['crashes']}, эффективность {r['avg_efficiency'] or 0:.4f}" for r in rows)) or 'Данных пока нет', chat_id)
        elif name == 'forward':
            u = a.resolve(arg) if arg else None
            if not u:
                return self.say(self.L('Формат: /forward <номер слота, метка или конец UUID>', 'Format: /forward <slot number, label, or end of UUID>'), chat_id)
            v = db.get_profile(u, cfg.algo, cfg.miner, cfg.miner_version, 'verified')
            if not v:
                return self.say(self.L(f'{a.card_full(u)}: пресета пока нет, пересылать нечего.', f'{a.card_full(u)}: no preset yet, nothing to forward.'), chat_id)
            self.say(preset_message(db, v['id']), chat_id)
        elif name == 'export':
            rows = db.q("select id from profiles where status='verified'")
            lines = [preset_message(db, r['id']).splitlines()[0] for r in rows]
            self._send_file(chat_id, 'presets.txt', '\n'.join(lines).encode('utf-8'))
        elif name == 'mode':
            if not args:
                return self.say(a.mode_report(), chat_id)
            aliases = {'efficiency': 'efficiency', 'eff': 'efficiency', 'эффективность': 'efficiency', 'compromise': 'compromise', 'комп': 'compromise', 'компромисс': 'compromise', 'hashrate': 'hashrate', 'hash': 'hashrate', 'хешрейт': 'hashrate'}
            mode_fmt = self.L('Формат: /mode efficiency | compromise [допуск %] | hashrate [keep]; для одной карты: /mode 3 hashrate, вернуть под общую цель: /mode 3 rig', 'Format: /mode efficiency | compromise [tolerance %] | hashrate [keep]; for one card: /mode 3 hashrate, return to the rig-wide target: /mode 3 rig')
            target = None
            if args[0].lower() not in aliases:
                if len(args) < 2:
                    return self.say(mode_fmt, chat_id)
                target, args = (args[0], args[1:])
            rig_word = args[0].lower() in ('rig', 'риг', 'общая', 'default', 'сброс')
            obj = None if rig_word else aliases.get(args[0].lower())
            tol, retune, bad = (None, True, obj is None and (not (target and rig_word)))
            for x in args[1:]:
                if x.lower() in ('keep', 'оставить'):
                    retune = False
                else:
                    try:
                        tol = float(x.rstrip('%').replace(',', '.')) / 100
                    except ValueError:
                        bad = True
            if bad:
                return self.say(mode_fmt, chat_id)
            if target:
                if not a.resolve(target):
                    return self.say(self.not_found(target), chat_id)
                a.request_card_mode(target, obj, tol, retune)
            else:
                a.request_mode(obj, tol, retune)
            self.say(self.L('Принято: /mode ', 'Accepted: /mode ') + (target + ' ' if target else '') + ' '.join(args), chat_id)
        elif name == 'psu' and args and (args[0].lower() in ('add', 'del', 'cards', 'system', 'limit', 'cancel')):
            a.commands.put(('psu_edit', args[0].lower(), *args[1:]))
            self.say(self.L('Принято: /psu ', 'Accepted: /psu ') + ' '.join(args), chat_id)
        elif name == 'psu' and args:
            nums = [x for x in args if x.lower() != 'set']
            if len(nums) in (2, 3) and all((x.isdigit() for x in nums)):
                a.commands.put(('psu_set', *[int(x) for x in nums]))
                self.say(self.L('Принято: /psu. Применяю и записываю в конфиг.', 'Accepted: /psu. Applying and saving to the config.'), chat_id)
            else:
                self.say(psu_help(self.lang), chat_id, parse_mode='HTML')
        elif name == 'psu':
            self.say(a.psu_report() + '\n\n' + psu_help(self.lang), chat_id, parse_mode='HTML')
        elif name == 'pl' and (not args):
            lines = []
            for u, g in a.gpus.items():
                lo, _, hi = a.pl_limits(u)
                lock = a.pl_lock(u)
                if self.lang == 'en':
                    lines.append(f'{a.card_full(u)}: ' + (f'locked at {lock} W' if lock else f'not locked, the bot picks within {lo}..{hi} W'))
                else:
                    lines.append(f'{a.card_full(u)}: ' + (f'заблокирован на {lock} Вт' if lock else f'не заблокирован, бот выбирает в диапазоне {lo}..{hi} Вт'))
            self.say('\n'.join(lines) or self.L('Карт нет', 'No cards'), chat_id)
        elif name == 'pl' and len(args) == 2:
            a.commands.put(('pl', args[0], args[1]))
            self.say(self.L('Принято: /pl', 'Accepted: /pl'), chat_id)
        elif name == 'newsearch':
            if not arg:
                self.say(self.L('Новый подбор сбросит готовые пресеты и начнёт поиск заново.\nДля одной карты: /newsearch 3\nДля всего рига: /newsearch all', 'A fresh search clears ready presets and starts over.\nFor one card: /newsearch 3\nFor the whole rig: /newsearch all'), chat_id)
            elif arg.lower() in ('all', 'все', 'всё'):
                a.commands.put(('tune',))
                self.say(self.L('Принято: новый подбор для всех карт рига', 'Accepted: fresh search for all cards in the rig'), chat_id)
            elif a.resolve(arg):
                a.commands.put(('tune', arg))
                self.say(self.L(f'Принято: новый подбор для карты {arg}', f'Accepted: fresh search for card {arg}'), chat_id)
            else:
                self.say(self.not_found(arg), chat_id)
        elif name == 'hive':
            v = (arg or '').lower()
            if v in ('on', 'вкл', '1'):
                a.state.data['hive_mirror'] = True
                a.state.save()
            elif v in ('off', 'выкл', '0'):
                a.state.data['hive_mirror'] = False
                a.state.save()
            on = a.hive_mirror_on()
            self.say(self.L('Дублирование событий панели Hive (перезагрузка, ошибка NVIDIA OC, смена конфига, Hive Shell): ' + ('включено' if on else 'выключено') + '. Изменить: /hive on или /hive off. Пересылаются только короткие сообщения бота, не строки логов.', 'Mirroring Hive panel events (reboot, NVIDIA OC error, config change, Hive Shell) to Telegram: ' + ('on' if on else 'off') + '. Change it: /hive on or /hive off. Only short bot messages are forwarded, not log lines.'), chat_id)
        elif name == 'share':
            from . import share
            if getattr(a, 'trial', False):
                self.say(self.L('На пробном периоде отправка проверенных пресетов в общий каталог обязательна (это условие пробного периода). С ключом её можно отключить.', 'During the trial, sending verified presets to the shared catalog is mandatory (a trial condition). With a license key you can turn it off.'), chat_id)
            elif not lic_required():
                self.say(self.L('Отправка в общий каталог в этой сборке управляется параметром catalog_share в конфиге.', 'In this build, sending to the shared catalog is controlled by the catalog_share setting in the config.'), chat_id)
            else:
                v = (arg or '').lower()
                if v in ('off', 'выкл', '0'):
                    a.state.data['share_off'] = True
                    a.state.save()
                elif v in ('on', 'вкл', '1'):
                    a.state.data.pop('share_off', None)
                    a.state.save()
                on = share.active(cfg, a)
                self.say(self.L('Отправка проверенных пресетов в общий каталог (анонимно, без имени рига и UUID карт): ' + ('включена' if on else 'выключена') + '. Изменить: /share on или /share off.', 'Sending verified presets to the shared catalog (anonymously, without rig name or card UUIDs): ' + ('on' if on else 'off') + '. Change it: /share on or /share off.'), chat_id)
        elif name == 'balance':
            if arg and arg.lower() in ('run', 'start', 'запуск'):
                a.commands.put(('balance',))
                self.say(self.L('Принято: запускаю распределение мощности', 'Accepted: starting the power distribution'), chat_id)
            elif arg and arg.lower() in ('deep', 'глубоко'):
                a.commands.put(('balance', 'deep'))
                self.say(self.L('Принято: распределение мощности с плотной сеткой core x PL (долго, около полусуток на карту)', 'Accepted: power distribution with a dense core x PL grid (slow, about half a day per card)'), chat_id)
            else:
                self.say(a.balance_report(self._unit()), chat_id)
        elif name in ('table', 'summary'):
            text = a.table_text(self._unit())
            while text:
                cut = text if len(text) <= 3800 else text[:text.rfind('\n', 0, 3800)]
                self.say(cut, chat_id)
                text = text[len(cut):].lstrip('\n')
            self._send_file(chat_id, 'rig_table.csv', ('\ufeff' + a.table_csv(self._unit())).encode('utf-8'))
        elif name == 'optimize':
            if not arg:
                return self.say(self.L(f'Формат: /optimize 3 [порог %] (карта) | /optimize all [порог %] | /optimize cancel. Бот ищет лучшую точку в окрестности готового пресета, по одной карте за раз; принимает только при выигрыше больше порога (сейчас по умолчанию {a.opt_gain():.1%}) и 2-часовой проверке. Порог на один запуск: /optimize 3 2 (2 %). Порог по умолчанию: /optimize gain 1.5', f'Format: /optimize 3 [threshold %] (card) | /optimize all [threshold %] | /optimize cancel. The bot searches for a better point near the ready preset, one card at a time; it only accepts a gain above the threshold (currently {a.opt_gain():.1%} by default) after a 2-hour verification. Threshold for one run: /optimize 3 2 (2%). Default threshold: /optimize gain 1.5'), chat_id)
            if arg.lower() in ('gain', 'порог'):
                a.commands.put(('optimize_gain', args[1] if len(args) > 1 else None))
                return self.say(self.L('Принято: /optimize ', 'Accepted: /optimize ') + ' '.join(args), chat_id)
            a.commands.put(('optimize', arg, args[1] if len(args) > 1 else None))
            self.say(self.L('Принято: /optimize ', 'Accepted: /optimize ') + ' '.join(args), chat_id)
        elif name == 'params':
            if len(args) < 2 or args[1] not in ('2', '4'):
                return self.say(self.L(f'Формат: /params 3 4 | /params all 4 | /params 3 2. 2 параметра: смещение ядра, смещение памяти и PL (как раньше). 4 параметра: к ним на готовом пресете добавляется подбор фиксации частоты ядра и памяти (отдельно для каждого алгоритма и майнера, принимается при выигрыше выше порога {a.opt_gain():.1%}; при сбое карты фиксация снимается).', f'Format: /params 3 4 | /params all 4 | /params 3 2. 2 parameters: core offset, memory offset and PL (as before). 4 parameters: once the preset is ready, adds a search for locked core/memory clocks (separately per algorithm and miner, accepted when the gain is above the threshold {a.opt_gain():.1%}; the lock is removed if the card crashes).'), chat_id)
            a.params_requests.put((args[0], args[1]))
            self.say(self.L('Принято: /params ', 'Accepted: /params ') + ' '.join(args), chat_id)
        elif name == 'models':
            self.say(catalog.format_table(catalog.lookup(db, ''), self._unit(), self.lang), chat_id)
        elif name == 'model':
            if not arg:
                return self.say(self.L('Формат: /model 3070 (часть названия модели). Весь каталог: /models', 'Format: /model 3070 (part of the model name). Full catalog: /models'), chat_id)
            self.say(catalog.format_table(catalog.lookup(db, ' '.join(args)), self._unit(), self.lang), chat_id)
        elif name == 'catalog':
            if not catalog.build(db):
                return self.say(self.L('Каталог пуст: нужен хотя бы один проверенный пресет.', 'Catalog is empty: at least one verified preset is needed.'), chat_id)
            self._send_file(chat_id, 'catalog.json', catalog.export_text(db).encode('utf-8'))
            self.say(self.L('Файл каталога: пресеты по моделям без UUID карт и имён ригов. Перешлите его другу, он отправит файл своему боту, и записи станут стартовыми точками для его карт.', 'Catalog file: presets by model, without card UUIDs or rig names. Forward it to a friend — they send the file to their own bot, and the entries become starting points for their cards.'), chat_id)
        elif name == 'restore':
            if not arg:
                self.say(self.L('Вернёт прежний проверенный пресет (тот, что заменил новый подбор) без нового перебора.\nДля одной карты: /restore 3\nДля всего рига: /restore all', 'Restores the previous verified preset (the one a new search replaced) without searching again.\nFor one card: /restore 3\nFor the whole rig: /restore all'), chat_id)
            elif arg.lower() in ('all', 'все', 'всё') or a.resolve(arg):
                a.request_restore('all' if arg.lower() in ('all', 'все', 'всё') else arg)
                self.say(self.L(f'Принято: возврат прежнего пресета ({arg}), без нового подбора', f'Accepted: restoring the previous preset ({arg}), without a new search'), chat_id)
            else:
                self.say(self.not_found(arg), chat_id)
        elif name == 'card':
            u = a.resolve(arg) if arg else None
            if not u:
                return self.say(self.L('Формат: /card <номер слота, метка или конец UUID>', 'Format: /card <slot number, label, or end of UUID>'), chat_id)
            g = a.gpus[u]
            s = a.backend.sample(u)
            v = db.get_profile(u, cfg.algo, cfg.miner, cfg.miner_version, 'verified')
            run = db.one('select kind, core_offset, mem_offset, power_limit, status, started_at from runs where gpu_uuid=? order by id desc limit 1', (u,))
            unit_w = self.L('Вт', 'W')
            lines = [f'{a.card_full(u)}: {s.temp_core:.0f}°C, {s.hashrate:.2f} {self._unit()}, {s.power_w:.0f} {unit_w}', self.L('Пресет: core %s, mem %s, PL %s Вт, эффективность %.4f', 'Preset: core %s, mem %s, PL %s W, efficiency %.4f') % (v['core_offset'], v['mem_offset'], v['power_limit'], v['efficiency'] or 0) if v else self.L('Пресета пока нет', 'No preset yet')]
            if run:
                status_word = run['status'] or self.L('идёт', 'in progress')
                lines.append(self.L(f"Последний замер: {run['kind']} core {run['core_offset']}, mem {run['mem_offset']}, PL {run['power_limit']}, {status_word} (с {run['started_at']})", f"Last run: {run['kind']} core {run['core_offset']}, mem {run['mem_offset']}, PL {run['power_limit']}, {status_word} (since {run['started_at']})"))
            crashes = db.q("select started_at, crash_cause, core_offset, mem_offset from runs where gpu_uuid=? and status in ('crash','unstable') order by id desc limit 3", (u,))
            crash_word = self.L('Сбой', 'Fault')
            lines += [f"{crash_word} {r['started_at']}: {r['crash_cause']}, core {r['core_offset']}, mem {r['mem_offset']}" for r in crashes]
            self.say('\n'.join(lines), chat_id)
        elif name in ('tune', 'verify', 'stop', 'safe', 'resume'):
            a.commands.put((name, *([arg] if arg else [])))
            if name == 'stop':
                a.stop_flag.set()
            self.say(self.L(f'Принято: /{name}', f'Accepted: /{name}'), chat_id)
        elif name == 'update':
            mode = args[0].lower() if args else ''
            if mode not in ('', 'force', 'rollback'):
                return self.say(self.L('Формат: /update | /update force | /update rollback', 'Format: /update | /update force | /update rollback'), chat_id)
            a.commands.put(('update', mode))
            self.say(self.L('Принято: /update. Выполню в начале следующего цикла; бот перезапустится сам.', 'Accepted: /update. Will run at the start of the next cycle; the bot restarts itself.'), chat_id)
        elif name == 'faulty' and arg:
            a.commands.put(('faulty', arg, not (len(args) > 1 and args[1] == 'off')))
            self.say(self.L('Принято', 'Accepted'), chat_id)
        elif name == 'uninstall':
            if not args or args[0].lower() != 'confirm':
                return self.say(self.L('Это необратимо удалит бота с этого рига (пресеты, база и лог пропадут вместе с кодом). Подтвердите: <code>/uninstall confirm</code> (конфиги/базу/лог оставить: <code>/uninstall confirm keep-data</code>).', 'This permanently removes the bot from this rig (presets, database and log go with the code). Confirm with <code>/uninstall confirm</code> (to keep configs/database/log: <code>/uninstall confirm keep-data</code>).'), chat_id, parse_mode='HTML')
            keep_data = len(args) > 1 and args[1].lower() in ('keep-data', 'keep_data')
            a.commands.put(('uninstall', keep_data))
            self.say(self.L('Принято: удаляю бота с рига.', 'Accepted: removing the bot from this rig.'), chat_id)
        else:
            self.say(help_text(self.lang, a.license_line()), chat_id, parse_mode='HTML')

def run_when_ready(cfg, db, agent, tg_factory, sleep=time.sleep, max_tries=None):
    delay, n = (30, 0)
    while True:
        try:
            bot = Bot(cfg, db, agent, tg_factory())
            break
        except Exception as e:
            n += 1
            if max_tries and n >= max_tries:
                return None
            log.warning('Telegram пока недоступен (%s), повторю через %s с; работа бота идёт без него', e, delay)
            sleep(delay)
            delay = min(delay * 2, 300)
    prev = agent.on_verified
    agent.notify = bot.notify_all
    agent.on_verified = lambda pid: (bot.send_preset(pid), prev(pid))
    return bot
