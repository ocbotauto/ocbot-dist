from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Iterable, Optional

@dataclass(frozen=True)
class Point:
    core: int
    mem: int
    pl: int
    fan: Optional[int] = None

    def key(self):
        return (self.core, self.mem, self.pl)

@dataclass
class EvalResult:
    status: str
    efficiency: float = 0.0
    boundary: bool = True
    abort: bool = False
    hashrate: float = 0.0

@dataclass
class SearchResult:
    best: Optional[Point]
    best_eff: float
    ranking: list
    tested: int
    reason: str

def dominated(p: Point, bad: Iterable[Point]) -> bool:
    return any((p.core >= b.core and p.mem >= b.mem and (p.pl <= b.pl) for b in bad))

def wedge_pivot(p: Point, bounds: dict, margins: dict) -> Optional[str]:
    for axis in ('pl', 'mem', 'core'):
        m = margins.get(axis, 0)
        if m and getattr(p, axis) >= bounds[axis][1] - m:
            return axis
    return None

def wedge_blocked(p: Point, wedges: Iterable, margins: dict) -> bool:
    for w, pivot in wedges:
        if getattr(p, pivot) < getattr(w, pivot) - margins.get(pivot, 0):
            continue
        blocked = True
        for axis in ('core', 'mem', 'pl'):
            if axis == pivot:
                continue
            v, wv = (getattr(p, axis), getattr(w, axis))
            if axis == 'pl':
                if v > wv + margins.get(axis, 0):
                    blocked = False
                    break
            elif v < wv - margins.get(axis, 0):
                blocked = False
                break
        if blocked:
            return True
    return False

def shift_safe(p: Point, steps: dict, bounds: dict, n: int=1) -> Point:
    mem = max(bounds['mem'][0], p.mem - n * steps['mem'])
    core = max(bounds['core'][0], p.core - n * steps['core']) if p.core > 0 else p.core
    return Point(core, mem, p.pl, p.fan)
MOVES = [('mem', +1), ('pl', -1), ('core', -1), ('core', +1), ('mem', -1), ('pl', +1)]
AGGR = {'mem': +1, 'core': +1, 'pl': -1}
GALLOP_MAX = 8

class Searcher:

    def __init__(self, evaluate: Callable[[Point], EvalResult], bounds: dict, steps: dict, hard: Iterable[Point], soft: Iterable[Point]=(), history: Optional[dict]=None, stale_after: int=5, max_points: int=40, min_gain: float=0.005, start_attempts: int=4, edges: Optional[dict]=None, hs_history: Optional[dict]=None, objective: str='efficiency', tolerance: float=0.03, refine_points: int=12, frozen: Iterable[str]=(), axis_rank: Optional[list]=None, trim_tol: float=0.0, trim_points: int=0, wedges: Iterable=(), wedge_margins: Optional[dict]=None):
        if objective not in ('efficiency', 'compromise', 'hashrate'):
            raise ValueError(f'неизвестная цель поиска: {objective}')
        self.objective = objective
        self.frozen: set = set(frozen)
        self.axis_rank = [a for a in axis_rank or [] if a in AGGR]
        self.moves = sorted(MOVES, key=lambda m: self.axis_rank.index(m[0]) if m[0] in self.axis_rank else len(self.axis_rank))
        self.tolerance = tolerance
        self.trim_tol = trim_tol
        self.trim_points = trim_points
        self.refine_points = refine_points
        self.hs: dict = dict(hs_history or {})
        self.evaluate = evaluate
        self.start_attempts = start_attempts
        self.edges = edges or {}
        self.bounds = bounds
        self.steps = steps
        self.hard = list(hard)
        self.soft = list(soft)
        self.wedges = list(wedges)
        self.wedge_margins = dict(wedge_margins or {})
        self.ok: dict = dict(history or {})
        self.seen = {p.key() for p in self.ok}
        self.stale_after = stale_after
        self.max_points = max_points
        self.min_gain = min_gain
        self.tested = 0
        self.limit: dict = {}
        self.mult = {a: 1 for a in AGGR}
        self.last: dict = {}
        for h in self.hard:
            self._blame(h)

    def _in_bounds(self, p: Point) -> bool:
        return all((self.bounds[a][0] <= getattr(p, a) <= self.bounds[a][1] for a in ('core', 'mem', 'pl')))

    def _move(self, p: Point, axis: str, sign: int, k: int=1) -> Point:
        d = {'core': p.core, 'mem': p.mem, 'pl': p.pl}
        d[axis] += sign * self.steps[axis] * k
        return Point(d['core'], d['mem'], d['pl'], p.fan)

    def _blame(self, h: Point) -> None:
        okkeys = {p.key() for p in self.ok}
        for axis, s in AGGR.items():
            for k in (1, 2, 4, 8):
                if self._move(h, axis, -s, k).key() in okkeys:
                    v, cur = (getattr(h, axis), self.limit.get(axis))
                    self.limit[axis] = v if cur is None else min(cur, v) if s > 0 else max(cur, v)
                    break

    def _blocked(self, p: Point) -> bool:
        tol = 2 * self.steps['pl']
        if any((h.core == p.core and h.mem == p.mem and (abs(h.pl - p.pl) <= tol) for h in self.hard)):
            return True
        if self.wedges and wedge_blocked(p, self.wedges, self.wedge_margins):
            return True
        for axis, s in AGGR.items():
            lim = self.limit.get(axis)
            if lim is not None and (getattr(p, axis) >= lim if s > 0 else getattr(p, axis) <= lim):
                return True
        return False

    def _back_off(self, p: Point, n: int) -> Point:
        f = 2 ** n
        return Point(max(self.bounds['core'][0], p.core - self.steps['core'] * f) if p.core > 0 else p.core, max(self.bounds['mem'][0], p.mem - 2 * self.steps['mem'] * f), min(self.bounds['pl'][1], p.pl + self.steps['pl'] * f), p.fan)

    def _eval(self, p: Point) -> EvalResult:
        self.seen.add(p.key())
        r = self.evaluate(p)
        self.tested += 1
        if r.status == 'ok':
            self.ok[p] = r.efficiency
            if r.hashrate:
                self.hs[p] = r.hashrate
        elif r.boundary:
            pivot = wedge_pivot(p, self.bounds, self.wedge_margins) if self.wedge_margins else None
            if pivot:
                self.wedges.append((p, pivot))
            else:
                self.hard.append(p)
                self._blame(p)
        return r

    def _next(self, best: Point):
        primary, late = ([], [])
        for axis, sign in self.moves:
            if axis in self.frozen:
                continue
            k = self.mult[axis] if self.last.get(axis) == sign else 1
            while k >= 1:
                c = self._move(best, axis, sign, k)
                edge = self.edges.get(axis)
                if k > 2 and edge is not None and (sign == AGGR[axis]) and (getattr(c, axis) > edge):
                    k //= 2
                    continue
                if self._in_bounds(c) and c.key() not in self.seen and (not dominated(c, self.hard)) and (not self._blocked(c)):
                    (late if dominated(c, self.soft) else primary).append((c, axis, sign, k))
                    break
                k //= 2
        pick = (primary or late or [None])[0]
        return pick

    def _floor(self) -> float:
        if self.objective == 'hashrate':
            return 0.0
        best = max((e for p, e in self.ok.items() if not dominated(p, self.hard)), default=0.0)
        return best * (1 - self.tolerance)

    def ranking(self) -> list:
        items = [(p, e) for p, e in self.ok.items() if not dominated(p, self.hard)]
        if self.objective == 'efficiency' or not items:
            return sorted(items, key=lambda t: t[1], reverse=True)
        floor = self._floor()
        cand = [t for t in items if t[0] in self.hs and t[1] >= floor]
        if self.objective == 'hashrate' and self.trim_tol > 0 and cand:
            thr = max((self.hs[t[0]] for t in cand)) * (1 - self.trim_tol)
            elig = sorted(cand, key=lambda t: (self.hs[t[0]] >= thr, (-t[0].pl, -t[0].core, -t[0].mem) if self.hs[t[0]] >= thr else 0, self.hs[t[0]], t[1]), reverse=True)
        else:
            elig = sorted(cand, key=lambda t: (self.hs[t[0]], t[1]), reverse=True)
        rest = sorted([t for t in items if t not in elig], key=lambda t: t[1], reverse=True)
        return elig + rest

    def _top(self):
        r = self.ranking()
        if not r or r[0][0] not in self.hs or r[0][1] < self._floor():
            return None
        return r[0][0]

    def _refine(self) -> bool:
        k = {'pl': 1, 'core': 1, 'mem': 1}
        spent = 0
        while spent < self.refine_points:
            cur = self._top()
            if cur is None:
                return False
            hs0, moved = (self.hs[cur], False)
            for axis in self.axis_rank or ('pl', 'core', 'mem'):
                if axis in self.frozen:
                    continue
                kk, cand = (k[axis], None)
                while kk >= 1:
                    c = self._move(cur, axis, +1, kk)
                    if self._in_bounds(c) and c.key() not in self.seen and (not dominated(c, self.hard)) and (not self._blocked(c)):
                        cand = c
                        break
                    kk //= 2
                if cand is None:
                    continue
                r = self._eval(cand)
                spent += 1
                if r.abort:
                    return True
                if r.status == 'ok' and r.hashrate > hs0 * (1 + self.min_gain) and (r.efficiency >= self._floor()):
                    k[axis] = min(kk * 2, 4 if axis == 'pl' else 2)
                    moved = True
                    break
                k[axis] = 1
                if spent >= self.refine_points:
                    break
            if not moved:
                return False
        return False

    def _trim(self) -> bool:
        if self.trim_tol <= 0:
            return False
        spent = 0
        order = ['pl'] + [a for a in ('core', 'mem') if a != 'pl']
        for axis in order:
            if axis in self.frozen:
                continue
            k = 1
            while self.trim_points <= 0 or spent < self.trim_points:
                cur = self._top()
                if cur is None:
                    return False
                peak = max((self.hs[p] for p, _ in self.ranking() if p in self.hs))
                kk, cand = (k, None)
                while kk >= 1:
                    c = self._move(cur, axis, -1, kk)
                    if self._in_bounds(c) and c.key() not in self.seen and (not dominated(c, self.hard)) and (not self._blocked(c)):
                        cand = c
                        break
                    kk //= 2
                if cand is None:
                    break
                r = self._eval(cand)
                spent += 1
                if r.abort:
                    return True
                if r.status == 'ok' and r.hashrate >= peak * (1 - self.trim_tol):
                    k = min(kk * 2, 4)
                elif kk > 1:
                    k = max(kk // 2, 1)
                else:
                    break
        return False

    def _result(self, best, best_eff, reason) -> SearchResult:
        rk = self.ranking()
        if best is not None and self.objective != 'efficiency' and rk:
            best, best_eff = rk[0]
        return SearchResult(best, best_eff, rk, self.tested, reason)

    def run(self, start: Point) -> SearchResult:
        ranked = self.ranking()
        if ranked:
            best, best_eff = ranked[0]
        else:
            best, best_eff = (None, 0.0)
            for n in range(self.start_attempts):
                cur = start if n == 0 else self._back_off(start, n - 1)
                if dominated(cur, self.hard):
                    continue
                r = self._eval(cur)
                if r.abort:
                    return self._result(None, 0.0, 'aborted')
                if r.status == 'ok':
                    best, best_eff = (cur, r.efficiency)
                    break
            if best is None:
                return self._result(None, 0.0, 'no_stable_start')
        no_improve, reason = (0, 'max_points')
        top_eff = max((e for p, e in self.ok.items() if not dominated(p, self.hard)), default=best_eff)
        top_hs = max((self.hs[p] for p in self.ok if p in self.hs and (not dominated(p, self.hard))), default=0.0)
        while self.tested < self.max_points:
            pick = self._next(best)
            if pick is None:
                reason = 'exhausted'
                break
            cand, axis, sign, k = pick
            r = self._eval(cand)
            if r.abort:
                reason = 'aborted'
                break
            gain = r.status == 'ok' and (r.efficiency > top_eff * (1 + self.min_gain) or (self.objective != 'efficiency' and r.hashrate > top_hs * (1 + self.min_gain) and (r.efficiency >= self._floor())))
            if gain:
                best, best_eff, no_improve = (cand, r.efficiency, 0)
                top_eff = max(top_eff, r.efficiency)
                top_hs = max(top_hs, r.hashrate)
                self.mult[axis] = min(k * 2, GALLOP_MAX)
                self.last[axis] = sign
            else:
                if self.last.get(axis) == sign:
                    self.mult[axis] = 1
                no_improve += 1
                if no_improve >= self.stale_after:
                    reason = 'converged'
                    break
        if self.objective != 'efficiency' and best is not None and (reason != 'aborted'):
            if self._refine():
                reason = 'aborted'
            elif self.objective == 'hashrate' and self._trim():
                reason = 'aborted'
        return self._result(best, best_eff, reason)
