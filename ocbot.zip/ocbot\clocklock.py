from __future__ import annotations
from typing import Optional

def parse_supported(text: str) -> dict:
    out: dict = {}
    for ln in (text or '').splitlines():
        parts = [x.strip() for x in ln.split(',')]
        if len(parts) < 2:
            continue
        try:
            mem, gr = (int(float(parts[0])), int(float(parts[1])))
        except ValueError:
            continue
        out.setdefault(mem, set()).add(gr)
    return {m: sorted(v) for m, v in out.items()}

def nearest(value: int, options: list) -> int:
    return min(options, key=lambda o: (abs(o - value), o)) if options else value

def core_candidates(cur: int, options: list, stride: int, span: int, floor: int=600) -> list:
    out, k = ([], 1)
    while k * stride <= span:
        t = cur - k * stride
        k += 1
        if t < floor:
            break
        if options:
            t = nearest(t, [o for o in options if o >= floor])
        if t < cur and t not in out:
            out.append(t)
    return out

def refine_candidates(best: int, tried: list, options: list, step: int, floor: int=600) -> list:
    out = []
    for t in (best - step, best + step):
        if t < floor:
            continue
        if options:
            t = nearest(t, options)
        if t != best and t not in tried and (t not in out):
            out.append(t)
    return out

def mem_candidates(cur: int, mems: list, allow_higher: bool, count: int=2) -> list:
    mems = sorted(set(mems))
    lower = [m for m in mems if m < cur][-count:]
    higher = [m for m in mems if m > cur][:count] if allow_higher else []
    return [m for m in lower + higher if m != cur]
