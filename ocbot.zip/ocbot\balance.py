from __future__ import annotations
from typing import Dict, List, Optional, Tuple
Option = Tuple[int, float, object]

def frontier(options: List[Option]) -> List[Option]:
    out, top = ([], 0.0)
    for o in sorted(options, key=lambda t: (t[0], -t[1])):
        if o[1] > top * (1 + 1e-09):
            out.append(o)
            top = o[1]
    return out

def allocate(options: Dict[str, List[Option]], budget: int) -> Optional[Dict[str, Option]]:
    neg = float('-inf')
    keys = list(options)
    dp = [0.0] + [neg] * budget
    back: list = []
    for k in keys:
        nd, ch = ([neg] * (budget + 1), [None] * (budget + 1))
        for w in range(budget + 1):
            if dp[w] == neg:
                continue
            for i, (pl, h, _) in enumerate(options[k]):
                nw = w + int(pl)
                if nw <= budget and dp[w] + h > nd[nw] + 1e-12:
                    nd[nw], ch[nw] = (dp[w] + h, (i, w))
        dp = nd
        back.append(ch)
    reach = [w for w in range(budget + 1) if dp[w] != neg]
    if not reach:
        return None
    w = max(reach, key=lambda x: (round(dp[x], 9), -x))
    picked: Dict[str, Option] = {}
    for k, ch in zip(reversed(keys), reversed(back)):
        i, w = ch[w]
        picked[k] = options[k][i]
    return picked
