from __future__ import annotations
import hashlib
import json
import logging
import threading
import time
import urllib.request
from typing import Callable, Optional
from . import catalog
log = logging.getLogger('ocbot.share')

def active(cfg, agent=None) -> bool:
    if not getattr(cfg, 'catalog_submit_url', ''):
        return False
    if agent is not None and getattr(agent, 'trial', False):
        return True
    from . import license as lic
    if lic.REQUIRED and agent is not None:
        return not (agent.state.data.get('share_off') or False)
    return bool(getattr(cfg, 'catalog_share', False))

def enabled(cfg, agent=None) -> bool:
    from . import license as lic
    return bool(getattr(cfg, 'catalog_submit_url', '')) and (bool(getattr(cfg, 'catalog_share', False)) or lic.REQUIRED)

def rig_token(hwid: str) -> str:
    return hashlib.sha256(('ocbot-rid:' + hwid).encode('utf-8')).hexdigest()

def build_payload(db, hwid: str) -> Optional[dict]:
    entries = []
    for e in catalog.build(db):
        if e.get('hashrate') is None or e.get('power_w') is None or e.get('efficiency') is None:
            continue
        best = {k: e['best'][k] for k in ('core', 'mem', 'pl')}
        med = {k: e['median'][k] for k in ('core', 'mem', 'pl')}
        entries.append({'model': e['model'], 'mem_vendor': e['mem_vendor'], 'algo': e['algo'], 'miner': e['miner'], 'miner_version': e['miner_version'], 'objective': e['objective'], 'cards': e['cards'], 'best': best, 'median': med, 'hashrate': e['hashrate'], 'power_w': e['power_w'], 'efficiency': e['efficiency']})
    if not entries:
        return None
    return {'v': 1, 'rid': rig_token(hwid), 'entries': entries}

def submit(url: str, payload: dict, opener: Optional[Callable]=None, timeout: int=20) -> str:
    req = urllib.request.Request(url.rstrip('/') + '/submit', data=json.dumps(payload).encode('utf-8'), method='POST', headers={'Content-Type': 'application/json', 'User-Agent': 'ocbot'})
    try:
        with (opener or urllib.request.urlopen)(req, timeout=timeout) as r:
            doc = json.loads(r.read().decode('utf-8') or '{}')
        return 'отправлено записей: %s' % doc.get('accepted', '?') if doc.get('ok') else 'приёмник отказал: %s' % doc.get('error')
    except urllib.error.HTTPError as e:
        if e.code == 429:
            return 'слишком часто (не раньше чем через час)'
        return 'приёмник ответил %s' % e.code
    except Exception as e:
        return 'не отправлено: %s' % e

class Sharer:

    def __init__(self, cfg, db, hwid: str, send: Optional[Callable]=None, delay_s: float=300.0, interval_s: float=21600.0, agent=None):
        self.cfg, self.db, self.hwid, self.delay_s, self.interval_s = (cfg, db, hwid, delay_s, interval_s)
        self.agent = agent
        self.send = send or submit
        self.event = threading.Event()
        self.last_sent = 0.0

    def poke(self, *_a) -> None:
        if active(self.cfg, self.agent):
            self.event.set()

    def run_once(self) -> str:
        if not active(self.cfg, self.agent):
            return 'отправка выключена'
        payload = build_payload(self.db, self.hwid)
        if not payload:
            return 'нет проверенных пресетов'
        msg = self.send(self.cfg.catalog_submit_url, payload)
        if msg.startswith('отправлено'):
            self.last_sent = time.time()
        log.info('общий каталог: %s', msg)
        return msg

    def loop(self) -> None:
        while True:
            self.event.wait(timeout=3600)
            if not self.event.is_set() and (not self.last_sent) and active(self.cfg, self.agent):
                self.event.set()
            if not self.event.is_set():
                continue
            time.sleep(self.delay_s)
            wait = self.last_sent + self.interval_s - time.time()
            if wait > 0:
                time.sleep(wait)
            self.event.clear()
            try:
                self.run_once()
            except Exception as e:
                log.warning('общий каталог: %s', e)
