import os
import re
import shutil
SCRIPT = '/hive/bin/xorg-conf'
PATTERN = re.compile('^(?P<ind>\\s*)Option\\s+\\\\"Coolbits\\\\"\\s+\\\\"\\d+\\\\"\\s*$')
OPTION = 'Option         \\"AllowExternalGpus\\" \\"True\\"'

def patch(path: str=SCRIPT) -> str:
    with open(path, encoding='utf-8') as f:
        lines = f.read().split('\n')
    if any(('AllowExternalGpus' in ln for ln in lines)):
        return 'already'
    out, n = ([], 0)
    for ln in lines:
        out.append(ln)
        m = PATTERN.match(ln)
        if m:
            out.append(f"{m.group('ind')}{OPTION}")
            n += 1
    if not n:
        return 'nomatch'
    bak = path + '.ocbot.bak'
    if not os.path.exists(bak):
        shutil.copy2(path, bak)
    with open(path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(out))
    return f'patched {n}'

def restore(path: str=SCRIPT) -> bool:
    bak = path + '.ocbot.bak'
    if not os.path.exists(bak):
        return False
    shutil.copy2(bak, path)
    return True

def report(path: str=SCRIPT) -> str:
    if not os.path.exists(path):
        return f'Файл {path} не найден: это не HiveOS или другая версия, правку нужно делать вручную.'
    r = patch(path)
    if r == 'already':
        return 'Параметр AllowExternalGpus уже есть в скрипте Hive. Если карты в иксах не видны, перезагрузите риг.'
    if r == 'nomatch':
        return 'В скрипте Hive не нашлось строк Coolbits, автоматическая правка невозможна.'
    return f'Параметр AllowExternalGpus добавлен ({r.split()[1]} строк). Копия: {path}.ocbot.bak. Чтобы он вступил в силу, перезагрузите риг (reboot). Откат: --fix-external-gpus restore. При обновлении образа Hive скрипт перезапишется: тогда повторите команду.'
