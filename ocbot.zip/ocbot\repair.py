from __future__ import annotations
from datetime import datetime
from . import escalation
from .db import DB
FALSE_NOTE = 'обнаружено после перезагрузки'

def repair_false_crashes(db: DB, boot_ts: float, margin: int=60) -> list:
    fixed, cards = ([], set())
    rows = db.q("select id, gpu_uuid, core_offset, mem_offset, power_limit, started_at from runs where note=? and status='crash'", (FALSE_NOTE,))
    for r in rows:
        if datetime.fromisoformat(r['started_at']).timestamp() > boot_ts + margin:
            db.x('update runs set status=NULL, crash_cause=NULL, note=? where id=?', ('прервано перезапуском бота (исправлено)', r['id']))
            fixed.append((r['gpu_uuid'], (r['core_offset'], r['mem_offset'], r['power_limit']), r['started_at']))
            cards.add(r['gpu_uuid'])
    for u in cards:
        escalation.reset(db, u)
    return fixed

def repair_false_xid_drops(db: DB, since_iso: str) -> list:
    fixed, cards = ([], set())
    rows = db.q("select id, gpu_uuid, algo, miner, miner_version, core_offset, mem_offset, power_limit, finished_at from runs where kind='work' and status='crash' and note like 'Xid % в работе' and finished_at >= ?", (since_iso,))
    for r in rows:
        db.x('update runs set status=NULL, crash_cause=NULL, note=? where id=?', ('ложный Xid из старого буфера dmesg (исправлено)', r['id']))
        if not db.get_profile(r['gpu_uuid'], r['algo'], r['miner'], r['miner_version'], 'verified'):
            db.x("update profiles set status='verified' where id=(select id from profiles where gpu_uuid=? and algo=? and miner=? and miner_version=? and core_offset=? and mem_offset=? and power_limit=? and status='outdated' order by created_at desc limit 1)", (r['gpu_uuid'], r['algo'], r['miner'], r['miner_version'], r['core_offset'], r['mem_offset'], r['power_limit']))
        fixed.append((r['gpu_uuid'], (r['core_offset'], r['mem_offset'], r['power_limit']), r['finished_at']))
        cards.add(r['gpu_uuid'])
    for u in cards:
        escalation.reset(db, u)
    return fixed
