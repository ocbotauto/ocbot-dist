from __future__ import annotations
import json
import os
import urllib.error
from . import license as _lic
from .config import Config
from .state import lang_of

def detect_owner_id(token: str, client_cls=None) -> int:
    if client_cls is None:
        from .tg import TgClient as client_cls
    try:
        updates = client_cls(token).get_updates(0, timeout=0)
    except Exception:
        return 0
    for u in reversed(updates):
        msg = u.get('message') or u.get('edited_message') or {}
        frm = msg.get('from') or {}
        if frm.get('id'):
            return int(frm['id'])
    return 0

def set_config(path: str, token: str, owner_id: int) -> None:
    with open(path, encoding='utf-8') as f:
        raw = json.load(f)
    raw['token'], raw['owner_id'] = (token.strip(), int(owner_id))
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(raw, f, ensure_ascii=False, indent=2)
    os.chmod(tmp, 384)
    os.replace(tmp, path)

def check(cfg: Config, client_cls=None, extra: str='', lang: str=None) -> str:
    if client_cls is None:
        from .tg import TgClient as client_cls
    en = (lang or lang_of(cfg)) == 'en'
    if not cfg.token or not cfg.owner_id:
        return 'The config has no token or owner ID: run --telegram-set TOKEN ID first' if en else 'В конфиге нет токена или ID владельца: сначала --telegram-set ТОКЕН ID'
    try:
        tg = client_cls(cfg.token, cfg.tg_proxy, cfg.tg_api_base)
        me = tg.get_me()
    except urllib.error.HTTPError as e:
        if e.code in (401, 404):
            return 'Telegram rejected the token: make sure you copied it in full from @BotFather' if en else 'Telegram не принял токен: проверьте, что он скопирован целиком из @BotFather'
        return f'Telegram returned an error {e.code}' if en else f'Telegram ответил ошибкой {e.code}'
    except (urllib.error.URLError, OSError) as e:
        return f'The rig could not reach api.telegram.org ({e}). Telegram may be blocked by your provider: you need a proxy: --telegram-proxy http://host:port' if en else f'Риг не достучался до api.telegram.org ({e}). Возможно, Telegram блокируется провайдером: нужен прокси: --telegram-proxy http://хост:порт'
    except Exception as e:
        return f'Could not reach Telegram: {e}' if en else f'Не удалось связаться с Telegram: {e}'
    if en:
        msg = f'The bot for rig {cfg.rig_name} is connected.' + (f'\n{extra}' if extra else '') + '\nCommands: /help'
    else:
        msg = f'Бот рига {cfg.rig_name} подключён.' + (f'\n{extra}' if extra else '') + '\nКоманды: /help'
    if _lic.REQUIRED and (not _lic.License(cfg).status()[0]):
        name = os.path.basename(getattr(cfg, '_path', '') or 'config.json')
        if en:
            msg += f'\nThe bot only works with an active license. Trial period (one-time, free):\npython3 -m ocbot --config {name} --trial\nOr activate a key from the site right away:\npython3 -m ocbot --config {name} --activate YOUR-KEY'
        else:
            msg += f'\nБот работает только с действующей лицензией. Пробный период (один раз, без оплаты):\npython3 -m ocbot --config {name} --trial\nИли сразу ключ с сайта:\npython3 -m ocbot --config {name} --activate ВАШ-КЛЮЧ'
    try:
        tg.send(cfg.owner_id, msg)
    except Exception as e:
        return f"Bot @{me.get('username')} found, but could not message you ({e}). Open it in Telegram and press Start, then check again" if en else f"Бот @{me.get('username')} найден, но написать вам не может ({e}). Откройте его в Telegram и нажмите Start, затем повторите проверку"
    return f"Done: bot @{me.get('username')} sent you a message in Telegram" if en else f"Готово: бот @{me.get('username')} написал вам в Telegram"
