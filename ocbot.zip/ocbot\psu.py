from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, List, Optional, Set, Tuple

@dataclass
class Group:
    name: str
    watts: int
    base_watts: int
    slots: Optional[Set[int]] = None
    cap: Optional[int] = None

class PsuGuard:

    def __init__(self, cfg):
        self.cfg = cfg
        self.groups: List[Group] = []
        for d in cfg.psu_groups:
            slots = d.get('slots')
            self.groups.append(Group(str(d.get('name', f'PSU{len(self.groups) + 1}')), int(d['watts']), int(d.get('base_watts', 0)), set(slots) if slots is not None else None, int(d['pl_max']) if d.get('pl_max') else None))
        if not self.groups and cfg.psu_watts:
            self.groups.append(Group('PSU1', int(cfg.psu_watts), int(cfg.psu_base_watts)))

    @property
    def configured(self) -> bool:
        return bool(self.groups)

    def group_of(self, slot: int) -> Optional[Group]:
        for g in self.groups:
            if g.slots is None or slot in g.slots:
                return g
        return None

    def budget(self, g: Group) -> float:
        cap = g.cap or getattr(self.cfg, 'pl_total_max', 0)
        if cap:
            return min(cap * self.cfg.psu_transient, self.hard_total(g) - g.base_watts)
        return g.watts * self.cfg.psu_max_load_frac - g.base_watts

    def hard_total(self, g: Group) -> float:
        return g.watts * self.cfg.psu_hard_frac

    def ceilings(self, cards: Dict[int, Tuple[int, Optional[int]]], caps: Optional[Dict[int, int]]=None, lang: str='ru') -> Tuple[Dict[int, int], List[str]]:
        en = lang == 'en'
        t, errors, out = (self.cfg.psu_transient, [], {})
        for slot in cards:
            if self.group_of(slot) is None:
                errors.append(f'slot {slot} is not assigned to any PSU (psu_groups)' if en else f'слот {slot} не привязан ни к одному БП (psu_groups)')
        for g in self.groups:
            members = {s: v for s, v in cards.items() if self.group_of(s) is g}
            if not members:
                continue
            locked = {s: v[1] for s, v in members.items() if v[1]}
            free = [s for s in members if s not in locked]
            avail = self.budget(g) - sum(locked.values()) * t
            if avail < 0:
                errors.append(f"{g.name}: PL locks ({sum(locked.values())} W with {t:.2f} headroom) don't fit the budget {self.budget(g):.0f} W (PSU {g.watts} W, base {g.base_watts} W, load ceiling {self.cfg.psu_max_load_frac:.0%})" if en else f'{g.name}: PL-замки ({sum(locked.values())} Вт с запасом {t:.2f}) не помещаются в бюджет {self.budget(g):.0f} Вт (БП {g.watts} Вт, база {g.base_watts} Вт, потолок загрузки {self.cfg.psu_max_load_frac:.0%})')
                continue
            if not free:
                continue
            capped = {s: int(caps[s]) for s in free if caps and s in caps}
            if capped and sum(capped.values()) * t > avail + 1e-06:
                capped = {}
            for s, w in capped.items():
                out[s] = max(w, members[s][0])
                avail -= out[s] * t
            free = [s for s in free if s not in capped]
            if not free:
                continue
            share = int(avail / (len(free) * t))
            for s in free:
                if share < members[s][0]:
                    errors.append(f'{g.name}: {len(free)} card(s) are left with {share} W each at a minimum PL of {members[s][0]} W (PSU {g.watts} W, base {g.base_watts} W, load ceiling {self.cfg.psu_max_load_frac:.0%}). Needs a stronger PSU or fewer cards' if en else f'{g.name}: на {len(free)} карт остаётся по {share} Вт при минимальном PL {members[s][0]} Вт (БП {g.watts} Вт, база {g.base_watts} Вт, потолок загрузки {self.cfg.psu_max_load_frac:.0%}). Нужен БП мощнее или меньше карт')
                    break
                out[s] = share
        return (out, errors)

    def overload(self, draws: Dict[int, float], lang: str='ru') -> Optional[str]:
        en = lang == 'en'
        for g in self.groups:
            cards = sum((w for s, w in draws.items() if self.group_of(s) is g))
            total = cards + g.base_watts
            if total > self.hard_total(g):
                return f'{g.name}: measured load {total:.0f} W (cards {cards:.0f} W + base {g.base_watts} W) is above the emergency threshold {self.hard_total(g):.0f} W at a PSU rating of {g.watts} W' if en else f'{g.name}: измеренная нагрузка {total:.0f} Вт (карты {cards:.0f} Вт + база {g.base_watts} Вт) выше аварийного порога {self.hard_total(g):.0f} Вт при номинале БП {g.watts} Вт'
        return None
