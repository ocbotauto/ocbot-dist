from __future__ import annotations
'Дополнительные каналы оповещений, помимо Telegram (который остаётся основным и всегда\nвключён отдельно, этот модуль о нём не знает). Покупатель сам включает нужные каналы\nкомандой /notify в Telegram (bot.py) — здесь только сами отправители и общий broadcast().\n\nНамеренно НЕ показывается на установке и не требует отдельного вопроса в мастере — ленивому\nпокупателю незачем видеть лишний текст про вебхуки при первом запуске; канал появляется,\nтолько если его сами явно попросили через /notify.'
import json
import logging
import urllib.error
import urllib.request
from typing import Callable, Dict, List, Tuple
log = logging.getLogger('ocbot')

def _post(url: str, data: bytes, headers: Dict[str, str], timeout: float=8.0) -> None:
    req = urllib.request.Request(url, data=data, headers=headers, method='POST')
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        resp.read()

def send_webhook(url: str, rig: str, text: str, post: Callable=_post) -> None:
    payload = json.dumps({'rig': rig, 'text': text}, ensure_ascii=False).encode('utf-8')
    post(url, payload, {'Content-Type': 'application/json'})

def send_discord(url: str, rig: str, text: str, post: Callable=_post) -> None:
    content = f'**{rig}**: {text}'
    if len(content) > 1900:
        content = content[:1897] + '...'
    payload = json.dumps({'content': content}, ensure_ascii=False).encode('utf-8')
    post(url, payload, {'Content-Type': 'application/json'})

def send_ntfy(url: str, rig: str, text: str, post: Callable=_post) -> None:
    try:
        title = rig.encode('ascii')
    except UnicodeEncodeError:
        title = b'OCBot'
    post(url, text.encode('utf-8'), {'Content-Type': 'text/plain; charset=utf-8', 'Title': title.decode('ascii')})
MAX_API = 'https://platform-api2.max.ru'

def send_max(url: str, rig: str, text: str, post: Callable=_post) -> None:
    from urllib.parse import urlsplit, parse_qs, unquote, quote as urlquote
    parts = urlsplit(url)
    if parts.scheme != 'max':
        raise ValueError('MAX-канал настраивается в формате max://<chat_id>?token=<токен>')
    chat_id = unquote(parts.netloc).strip()
    token = (parse_qs(parts.query).get('token') or [''])[0].strip()
    if not chat_id or not token:
        raise ValueError('в MAX-канале нет chat_id или токена бота')
    content = f'[{rig}] {text}'
    if len(content) > 3900:
        content = content[:3897] + '...'
    req_url = f'{MAX_API}/messages?chat_id={urlquote(chat_id)}'
    payload = json.dumps({'text': content}, ensure_ascii=False).encode('utf-8')
    post(req_url, payload, {'Content-Type': 'application/json', 'Authorization': token})
SENDERS: Dict[str, Callable] = {'webhook': send_webhook, 'discord': send_discord, 'ntfy': send_ntfy, 'max': send_max}

def broadcast(channels: dict, rig: str, text: str, post: Callable=_post) -> List[Tuple[str, str]]:
    errors: List[Tuple[str, str]] = []
    for name, chan_cfg in (channels or {}).items():
        url = (chan_cfg or {}).get('url') if isinstance(chan_cfg, dict) else None
        fn = SENDERS.get(name)
        if not url or not fn:
            continue
        try:
            fn(url, rig, text, post=post)
        except (urllib.error.URLError, OSError, ValueError) as e:
            log.warning('notify %s: %s', name, e)
            errors.append((name, str(e)))
        except Exception as e:
            log.exception('notify %s: непредвиденная ошибка', name)
            errors.append((name, str(e)))
    return errors
