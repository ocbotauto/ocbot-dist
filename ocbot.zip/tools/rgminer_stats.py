from __future__ import annotations
import argparse
import glob
import json
import os
import re
import subprocess
import sys
import time
import urllib.request
from typing import Dict, List, Optional, Tuple
ANSI = re.compile('\\x1b\\[[0-9;?]*[A-Za-z]|\\x1b\\][^\\x07]*\\x07')
UNIT = {'H': 1.0, 'KH': 1000.0, 'MH': 1000000.0, 'GH': 1000000000.0, 'TH': 1000000000000.0, 'PH': 1000000000000000.0}
HASH = re.compile('([0-9]+(?:\\.[0-9]+)?)\\s*([KMGTP]?H)/s', re.I)
SHARES = re.compile('(\\d+)\\s*/\\s*(\\d+)\\s*/\\s*(\\d+)')
MARKER = 'Shares A/R/S'
BLOCK_HEAD = re.compile('^(\\d+)\\s+(.+?)\\s*\\|[^|]*\\|\\s*([0-9.]+\\s*[KMGTP]?H/s)\\s*\\|\\s*Power\\s+([0-9.]+)\\s*W', re.I)
BLOCK_TEMP = re.compile('^Temp\\s+([0-9.]+)\\s*C\\b', re.I)
BLOCK_SHARES = re.compile('Shares\\s+(\\d+)\\s*/\\s*(\\d+)\\s*/\\s*(\\d+)')
BLOCK_PROBE = re.compile('\\|\\s*Power\\s+[0-9.]+\\s*W\\s*\\|\\s*H/W', re.I)
TAIL_BYTES = 256 * 1024

class SetupError(Exception):

    def __init__(self, msg: str, code: int):
        super().__init__(msg)
        self.code = code

def _cells(line: str) -> List[str]:
    return [c.strip() for c in line.split('|')]

def has_table(text: str) -> bool:
    return MARKER in text or bool(BLOCK_PROBE.search(ANSI.sub('', text)))

def parse_last_table(text: str) -> List[dict]:
    lines = [ANSI.sub('', ln).strip() for ln in re.split('[\\r\\n]+', text)]
    closed: Optional[List[dict]] = None
    cur: Optional[List[dict]] = None
    cols: Dict[str, int] = {}
    pend: Optional[dict] = None
    for ln in lines:
        if '|' not in ln:
            continue
        bh = BLOCK_HEAD.match(ln)
        if bh:
            if cur is None:
                cur = []
            h = HASH.search(bh.group(3))
            pend = {'idx': int(bh.group(1)), 'name': bh.group(2).strip(), 'hps': float(h.group(1)) * UNIT[h.group(2).upper()], 'power': float(bh.group(4)), 'temp': 0.0, 'status': '', 'shares': None} if h else None
            continue
        if pend is not None:
            t = BLOCK_TEMP.match(ln)
            if t:
                pend['temp'] = float(t.group(1))
                continue
            sh = BLOCK_SHARES.search(ln)
            if sh and cur is not None:
                pend['shares'] = tuple((int(x) for x in sh.groups()))
                pend['status'] = ln.split('|')[-1].strip()
                cur.append(pend)
                pend = None
                continue
        cells = _cells(ln)
        if MARKER in ln:
            cols = {c.lower(): i for i, c in enumerate(cells)}
            cur = []
            continue
        first = cells[0].lower()
        if first.startswith('total') and cur is not None:
            closed, cur, pend = (cur, None, None)
            continue
        if cur is None or not cols:
            continue
        m = re.match('(\\d+)\\s+(.+)$', cells[0])
        if not m:
            continue
        try:
            row = _row(cells, cols, int(m.group(1)), m.group(2).strip())
        except (KeyError, IndexError, ValueError):
            continue
        cur.append(row)
    return closed if closed is not None else cur or []

def _col(cols: Dict[str, int], *names: str) -> int:
    for n in names:
        for key, i in cols.items():
            if key.startswith(n):
                return i
    raise KeyError(names[0])

def _row(cells: List[str], cols: Dict[str, int], idx: int, name: str) -> dict:
    h = HASH.search(cells[_col(cols, 'hashrate')])
    if not h:
        raise ValueError('нет хешрейта')
    s = SHARES.search(cells[_col(cols, 'shares')])
    if not s:
        raise ValueError('нет шар')
    return {'idx': idx, 'name': name, 'hps': float(h.group(1)) * UNIT[h.group(2).upper()], 'power': _num(cells[_col(cols, 'power')]), 'temp': _num(cells[_col(cols, 'temp')]), 'status': cells[_col(cols, 'status')] if 'status' in cols else '', 'shares': tuple((int(x) for x in s.groups()))}

def _num(s: str) -> float:
    try:
        return float(s.strip())
    except ValueError:
        return 0.0
DEFAULT_API = 'http://127.0.0.1:9200/metrics'

def _devices(data) -> list:
    if isinstance(data, list):
        return [d for d in data if isinstance(d, dict)]
    if isinstance(data, dict):
        for key in ('miners', 'devices', 'gpus'):
            if isinstance(data.get(key), list):
                return _devices(data[key])
        for v in data.values():
            if isinstance(v, list) and v and all((isinstance(x, dict) for x in v)):
                return v
    return []

def parse_api(text: str) -> List[dict]:
    rows = []
    for d in _devices(json.loads(text)):
        try:
            rows.append({'idx': int(d['deviceId']), 'uuid': d.get('gpuUuid'), 'name': str(d.get('gpuName', '')), 'hps': float(d.get('emaRate') or 0.0), 'power': 0.0, 'temp': 0.0, 'status': str(d.get('lastStatus', '')), 'shares': (int(d.get('acceptedShares', 0)), int(d.get('rejectedShares', 0)), int(d.get('staleShares', 0))), 'updated': float(d['lastUpdated']) / 1000.0 if d.get('lastUpdated') else None, 'uptime_s': float(d['processUptimeMs']) / 1000.0 if d.get('processUptimeMs') is not None else None})
        except (KeyError, TypeError, ValueError):
            continue
    return rows

def remap_to_smi(rows: List[dict], uuid_to_index: Dict[str, int]) -> List[dict]:
    out = []
    for r in rows:
        if r.get('uuid') in uuid_to_index:
            out.append(dict(r, idx=uuid_to_index[r['uuid']]))
    return out

def remap_to_smi_bus(rows: List[dict], bus_to_index: Dict[str, int]) -> List[dict]:
    out = []
    for r in rows:
        if r.get('bus') in bus_to_index:
            out.append(dict(r, idx=bus_to_index[r['bus']]))
    return out

def smi_uuid_map() -> Optional[Dict[str, int]]:
    if os.environ.get('OCBOT_NO_SMI'):
        return None
    try:
        out = subprocess.run(['nvidia-smi', '--query-gpu=index,uuid', '--format=csv,noheader'], capture_output=True, text=True, timeout=20, check=True).stdout
    except (OSError, subprocess.SubprocessError):
        return None
    res = {}
    for ln in out.strip().splitlines():
        i, _, u = ln.partition(',')
        if u.strip():
            res[u.strip()] = int(i)
    return res

def _short_bus(bus: str) -> str:
    return bus.strip().lower()[-7:]

def smi_bus_map() -> Optional[Dict[str, int]]:
    if os.environ.get('OCBOT_NO_SMI'):
        return None
    try:
        out = subprocess.run(['nvidia-smi', '--query-gpu=index,pci.bus_id', '--format=csv,noheader'], capture_output=True, text=True, timeout=20, check=True).stdout
    except (OSError, subprocess.SubprocessError):
        return None
    res = {}
    for ln in out.strip().splitlines():
        i, _, b = ln.partition(',')
        b = _short_bus(b)
        if b:
            res[b] = int(i)
    return res

def is_hive_stats(data) -> bool:
    return isinstance(data, dict) and isinstance(data.get('hs'), list) and isinstance(data.get('bus_ids'), list)
HIVE_HS_UNITS = {'hs': 1.0, 'khs': 1000.0, 'mhs': 1000000.0, 'ghs': 1000000000.0, 'ths': 1000000000000.0, 'phs': 1000000000000000.0}

def parse_hive_stats(d: dict) -> List[dict]:
    hs, temps, buses = (d.get('hs') or [], d.get('temp') or [], d.get('bus_ids') or [])
    mult = HIVE_HS_UNITS.get(str(d.get('hs_units') or 'hs').strip().lower(), 1.0)
    up = d.get('uptime')
    rows = []
    for i, h in enumerate(hs):
        try:
            rows.append({'idx': i, 'bus': _short_bus(str(buses[i])) if i < len(buses) else '', 'uuid': None, 'name': '', 'hps': float(h or 0.0) * mult, 'power': 0.0, 'temp': float(temps[i]) if i < len(temps) else 0.0, 'status': 'ok', 'shares': (0, 0, 0), 'updated': None, 'uptime_s': float(up) if up else None})
        except (TypeError, ValueError):
            continue
    return rows
PORT_FLAGS = ('--metrics-port', '--api-port', '--http-port', '--port', '--api-bind')
DEFAULT_PORTS = (9200, 9900)
API_PATHS = ('/hive-stats', '/metrics')

def _miner_ports() -> List[int]:
    ports = []
    try:
        pids = [p for p in os.listdir('/proc') if p.isdigit()]
    except OSError:
        return ports
    for pid in pids:
        try:
            with open(f'/proc/{pid}/cmdline', 'rb') as f:
                args = f.read().decode('utf-8', 'replace').split('\x00')
        except OSError:
            continue
        for i, arg in enumerate(args):
            for fl in PORT_FLAGS:
                if arg == fl and i + 1 < len(args) and args[i + 1].isdigit():
                    ports.append(int(args[i + 1]))
                elif arg.startswith(fl + '=') and arg.split('=', 1)[1].isdigit():
                    ports.append(int(arg.split('=', 1)[1]))
    return ports

def discover_api(timeout: float=1.5) -> Tuple[Optional[str], Optional[str]]:
    for port in list(dict.fromkeys(_miner_ports() + list(DEFAULT_PORTS))):
        for path in API_PATHS:
            url = f'http://127.0.0.1:{port}{path}'
            try:
                text = fetch(url, timeout)
            except (OSError, ValueError):
                continue
            t = text.lstrip()[:1]
            if t == '{':
                try:
                    data = json.loads(text)
                except ValueError:
                    continue
                if is_hive_stats(data) or parse_api(text):
                    return (url, text)
            elif t == '[':
                try:
                    if parse_api(text):
                        return (url, text)
                except ValueError:
                    continue
    return (None, None)

def fetch(url: str, timeout: float=5) -> str:
    with urllib.request.urlopen(url, timeout=timeout) as r:
        return r.read().decode('utf-8', 'replace')

def invalid_by_window(state: dict, now: float, shares: Dict[int, Tuple[int, int, int]], window: float, min_shares: int) -> Dict[int, Tuple[float, bool]]:
    snaps = state.setdefault('snaps', [])
    if snaps and any((shares[i][0] + shares[i][1] + shares[i][2] < sum(snaps[-1]['s'].get(str(i), [0, 0, 0])) for i in shares)):
        snaps.clear()
    if not snaps or now - snaps[-1]['t'] >= 5:
        snaps.append({'t': now, 's': {str(i): list(v) for i, v in shares.items()}})
    snaps[:] = [x for x in snaps if now - x['t'] <= window * 2]
    base = None
    for x in snaps:
        if now - x['t'] >= window:
            base = x
    base = base or snaps[0]
    out = {}
    for i, (a, r, s) in shares.items():
        a0, r0, s0 = base['s'].get(str(i), [a, r, s])
        da, dr, ds = (max(a - a0, 0), max(r - r0, 0), max(s - s0, 0))
        total = da + dr + ds
        out[i] = (100.0 * (dr + ds) / total if total >= min_shares else 0.0, total >= min_shares)
    return out

def read_tail(path: str, n: int=TAIL_BYTES) -> str:
    with open(path, 'rb') as f:
        f.seek(0, os.SEEK_END)
        f.seek(max(0, f.tell() - n))
        return f.read().decode('utf-8', 'replace')

def find_log(max_age: float, now: float) -> str:
    cands = sorted(glob.glob('/var/log/miner/*/*.log') + glob.glob('/var/log/miner/*.log'), key=lambda p: os.path.getmtime(p), reverse=True)
    for p in cands:
        try:
            if has_table(read_tail(p)):
                return p
        except OSError:
            continue
    raise SetupError("не нашёл лог с таблицей rgminer в /var/log/miner: найдите его командой grep -lE 'Shares A/R/S|H/W [0-9.]+G' -r /var/log 2>/dev/null и передайте путь через --log", 3)

def norm_name(s: str) -> str:
    return re.sub('^(nvidia\\s+)?(geforce\\s+)?', '', s.strip(), flags=re.I).lower()

def check_smi(rows: List[dict], smi_names: Dict[int, str]) -> Optional[str]:
    for r in rows:
        want = smi_names.get(r['idx'])
        if want is None or norm_name(want) != norm_name(r['name']):
            return f"карта {r['idx']}: у майнера '{r['name']}', у nvidia-smi '{want}'. Порядок не совпадает, замеры могут попасть не той карте"
    return None

def smi_names() -> Dict[int, str]:
    out = subprocess.run(['nvidia-smi', '--query-gpu=index,name', '--format=csv,noheader'], capture_output=True, text=True, timeout=20, check=True).stdout
    res = {}
    for ln in out.strip().splitlines():
        i, _, n = ln.partition(',')
        res[int(i)] = n.strip()
    return res

def build(rows: List[dict], unit: str, inv: Dict[int, Tuple[float, bool]], stale: bool) -> dict:
    div = UNIT[unit.upper().replace('/S', '')]
    out = {}
    for r in rows:
        pct, known = inv.get(r['idx'], (0.0, False))
        hr = r['hps'] / div
        rounded = round(hr, 4)
        if rounded == 0.0 and hr > 0:
            rounded = hr
        out[str(r['idx'])] = {'hashrate': 0.0 if stale else rounded, 'invalid_pct': 0.0 if stale else round(pct, 3), 'invalid_known': known and (not stale), 'power': r['power'], 'temp': r['temp'], 'status': r['status'], 'stale': stale}
        if r.get('uptime_s') is not None:
            out[str(r['idx'])]['uptime_s'] = round(r['uptime_s'], 1)
    return out

def main(argv: Optional[List[str]]=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    src = ap.add_mutually_exclusive_group()
    src.add_argument('--api', help=f'адрес интерфейса майнера (по умолчанию {DEFAULT_API})')
    src.add_argument('--log')
    src.add_argument('--cmd')
    src.add_argument('--stdin', action='store_true')
    ap.add_argument('--unit', default='TH/s', help='единица хешрейта в выводе: H/s, KH/s, MH/s, GH/s, TH/s, PH/s')
    ap.add_argument('--window', type=float, default=300.0, help='окно для доли плохих шар, секунды (как window_s в конфиге)')
    ap.add_argument('--min-shares', type=int, default=100)
    ap.add_argument('--max-age', type=float, default=120.0, help='данные старше этого возраста считаются мёртвым майнером')
    ap.add_argument('--state', default='/tmp/ocbot_rgminer_state.json')
    ap.add_argument('--check-smi', action='store_true', help='для текста консоли: сверить порядок карт с nvidia-smi')
    a = ap.parse_args(argv)
    now = time.time()
    try:
        stale = False
        if a.stdin:
            text = sys.stdin.read()
        elif a.cmd:
            text = subprocess.run(a.cmd, shell=True, capture_output=True, text=True, timeout=30).stdout
        elif a.log:
            text = read_tail(a.log)
            stale = now - os.path.getmtime(a.log) > a.max_age
        else:
            api = a.api or DEFAULT_API
            try:
                text = fetch(api)
            except (OSError, ValueError) as e:
                url, text = discover_api()
                if url is None:
                    print(f'rgminer_stats: интерфейс майнера недоступен: {e}', file=sys.stderr)
                    print('{}')
                    return 0
                print(f'rgminer_stats: {api} недоступен, переключился на найденный {url}', file=sys.stderr)
        if text.lstrip()[:1] in ('[', '{'):
            try:
                data = json.loads(text)
            except ValueError as e:
                raise SetupError(f'ответ интерфейса не разобрать как JSON: {e}', 5)
            if is_hive_stats(data):
                rows = parse_hive_stats(data)
                m = smi_bus_map()
                if m is None:
                    print('rgminer_stats: nvidia-smi недоступен, ключом остаётся порядок карт у майнера', file=sys.stderr)
                else:
                    rows = remap_to_smi_bus(rows, m)
            else:
                try:
                    rows = parse_api(text)
                except ValueError as e:
                    raise SetupError(f'ответ интерфейса не разобрать как JSON: {e}', 5)
                m = smi_uuid_map()
                if m is None:
                    print('rgminer_stats: nvidia-smi недоступен, ключом остаётся номер карты у майнера', file=sys.stderr)
                else:
                    rows = remap_to_smi(rows, m)
            ups = [r['updated'] for r in rows if r.get('updated')]
            stale = bool(ups) and now - max(ups) > a.max_age
        else:
            rows = parse_last_table(text)
            if rows and a.check_smi:
                bad = check_smi(rows, smi_names())
                if bad:
                    raise SetupError(bad, 4)
        if not rows:
            raise SetupError('в источнике нет данных rgminer (ни ответа интерфейса, ни таблицы)', 5)
        try:
            with open(a.state, encoding='utf-8') as f:
                state = json.load(f)
        except (OSError, ValueError):
            state = {}
        inv = invalid_by_window(state, now, {r['idx']: r['shares'] for r in rows}, a.window, a.min_shares)
        tmp = a.state + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(state, f)
        os.replace(tmp, a.state)
        print(json.dumps(build(rows, a.unit, inv, stale)))
        return 0
    except SetupError as e:
        print(f'rgminer_stats: {e}', file=sys.stderr)
        return e.code
if __name__ == '__main__':
    sys.exit(main())
