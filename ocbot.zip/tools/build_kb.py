import json
import os
import re
import statistics
from collections import defaultdict
HERE = os.path.dirname(os.path.abspath(__file__))

def norm_model(name):
    return re.sub('\\s+', ' ', name.replace('NVIDIA', '').replace('GeForce', '')).strip()

def vendor_of(name):
    m = re.search('(samsung|micron|hynix)', name, re.I)
    return m.group(1).capitalize() if m else ''

def algo_of(raw):
    return raw.split()[0].lower() if raw else ''

def to_int(s):
    return int(s.replace('+', '').replace('%', ''))

def main():
    rows = json.load(open(os.path.join(HERE, 'raw_kryptex.json'), encoding='utf-8'))
    models = json.load(open(os.path.join(HERE, 'models.json'), encoding='utf-8'))
    groups = defaultdict(list)
    skipped = defaultdict(int)
    for r in rows:
        model = norm_model(r['model'])
        spec = models.get(model)
        algo = algo_of(r['algo'])
        if not spec or not algo:
            skipped['нет модели/алго'] += 1
            continue
        official = bool(re.search('\\((Low|Medium|High|Efficiency) Overclock\\)', r['name']))
        if not official and r['likes'] < 50:
            skipped['низкий рейтинг'] += 1
            continue
        core_raw, mem_raw, power_raw = (r['core'], r['mem'], r['power'])
        try:
            core_v, mem_v, pw = (to_int(core_raw), to_int(mem_raw), to_int(power_raw))
        except ValueError:
            skipped['не число'] += 1
            continue
        if pw <= 0:
            skipped['мусор'] += 1
            continue
        signed = core_raw.startswith(('+', '-'))
        core_off = core_v if signed or abs(core_v) < 500 else core_v - spec['boost']
        if mem_v >= 3600:
            if not official:
                skipped['мусор'] += 1
                continue
            mem_off = mem_v
        else:
            mem_off = mem_v * 2
        groups[model, vendor_of(r['name']), algo].append({'core': core_off, 'mem': mem_off, 'pl_pct': pw, 'hr': r['hashrate'], 'unit': r['unit']})
    presets = {}
    ceilings = defaultdict(lambda: {'core_max': None, 'mem_max': 0})
    for (model, vendor, algo), items in sorted(groups.items()):
        if len(items) < 1:
            continue
        p = {'core': int(statistics.median((i['core'] for i in items))), 'mem': int(statistics.median((i['mem'] for i in items))), 'pl_pct': int(statistics.median((i['pl_pct'] for i in items))), 'n': len(items), 'hr_med': round(statistics.median((i['hr'] for i in items)), 3), 'hr_unit': items[0]['unit']}
        p['pl_w'] = round(models[model]['tdp'] * p['pl_pct'] / 100)
        presets[f'{model}|{vendor}|{algo}'] = p
        c = ceilings[model]
        c['mem_max'] = max(c['mem_max'], p['mem'])
        c['core_max'] = p['core'] if c['core_max'] is None else max(c['core_max'], p['core'])
    out = {'models': models, 'presets': presets, 'ceilings': {m: v for m, v in sorted(ceilings.items())}}
    out_dir = os.path.normpath(os.path.join(HERE, '..', 'ocbot', 'data'))
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, 'kb.json')
    json.dump(out, open(out_path, 'w', encoding='utf-8'), ensure_ascii=False, indent=1, sort_keys=True)
    print('записано:', out_path)
    print('пресетов:', len(presets), ' моделей с потолками:', len(out['ceilings']))
    print('отброшено:', dict(skipped))
    for k in list(presets)[:12]:
        print(' ', k, '->', presets[k])
if __name__ == '__main__':
    main()
