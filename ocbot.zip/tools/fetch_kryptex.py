import html as h
import json
import os
import re
import time
import urllib.parse
import urllib.request
MODELS = ['NVIDIA RTX 3090', 'NVIDIA RTX 3080 Ti', 'NVIDIA RTX 3080', 'NVIDIA RTX 3070 Ti', 'NVIDIA RTX 3070', 'NVIDIA RTX 3060 Ti', 'NVIDIA RTX 3060', 'NVIDIA RTX 2080 Ti', 'NVIDIA RTX 2080', 'NVIDIA RTX 2070', 'NVIDIA RTX 2060', 'NVIDIA GTX 1660 Super', 'NVIDIA GTX 1660 Ti', 'NVIDIA RTX 4090', 'NVIDIA RTX 4080', 'NVIDIA RTX 4070 Ti', 'NVIDIA RTX 4070', 'NVIDIA RTX 4060 Ti', 'NVIDIA RTX 4060', 'NVIDIA RTX 5090', 'NVIDIA RTX 5080', 'NVIDIA RTX 5070 Ti', 'NVIDIA RTX 5070', 'NVIDIA RTX 5060 Ti', 'NVIDIA RTX 5060']
PAGES = 3
HERE = os.path.dirname(os.path.abspath(__file__))
UA = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}

def fetch(url):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=30) as r:
        return r.read().decode('utf-8', 'replace')

def parse(src, model):
    out = []
    for row in re.findall('<tr class="tr-link">(.*?)</tr>', src, re.S):
        m = re.search('class="tr-link__link"[^>]*>\\s*(.*?)\\s*</a>', row, re.S)
        name = h.unescape(m.group(1)).strip() if m else ''
        hr = re.search('⚡️\\s*([\\d.,]+)\\s*((?:k|M|G|T)?H/s)', row)
        algo = re.search('font-size:11px;color:#9ca3af;margin-top:3px">(.*?)</div>', row, re.S)
        clocks = re.search('class="oc-clocks">(.*?)</div>', row, re.S)
        vals = [v.strip() for v in re.findall('<span>([^<]+)</span>', clocks.group(1))] if clocks else []
        rate = re.findall('color:#16a34a">(\\d+)%', row)
        if len(vals) != 3 or not hr:
            continue
        out.append({'model': model, 'name': name, 'algo': h.unescape(algo.group(1)).strip() if algo else '', 'hashrate': float(hr.group(1).replace(',', '')), 'unit': hr.group(2), 'core': vals[0], 'mem': vals[1], 'power': vals[2], 'likes': int(rate[0]) if rate else 0})
    return out

def main():
    out_path = os.path.join(HERE, 'raw_kryptex.json')
    all_rows = json.load(open(out_path, encoding='utf-8')) if os.path.exists(out_path) else []
    seen = {(r['model'], r['name'], r['algo'], r['core'], r['mem'], r['power']) for r in all_rows}
    for model in MODELS:
        got = 0
        for page in range(1, PAGES + 1):
            url = 'https://www.kryptex.com/en/overclocking?' + urllib.parse.urlencode({'device': model, 'algo': 'all', 'page': page})
            try:
                src = fetch(url)
            except Exception as e:
                print(f'{model} p{page}: {e}')
                break
            rows = [r for r in parse(src, model) if (r['model'], r['name'], r['algo'], r['core'], r['mem'], r['power']) not in seen]
            if not rows:
                break
            all_rows += rows
            got += len(rows)
            time.sleep(1.5)
        print(f'{model}: +{got}')
        time.sleep(1.0)
    json.dump(all_rows, open(out_path, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print('всего строк:', len(all_rows))
if __name__ == '__main__':
    main()
