from __future__ import annotations
import fnmatch
import hashlib
import io
import os
import shutil
import urllib.parse
import urllib.request
import zipfile
SHA_FILE = '.ocbot_update_sha'
PROTECTED = ('config*.json', '*.db', '*.sqlite*', 'ocbot_state.json', 'license.json', 'license.key', 'license.json.cache', '*.log', 'ocbot_control.json', '*.bak')

class UpdateError(Exception):
    pass

def fetch(url: str, timeout: int=90, token: str='', lang: str='ru') -> bytes:
    en = lang == 'en'
    if url and '://' not in url:
        try:
            with open(os.path.expanduser(url), 'rb') as f:
                return f.read()
        except OSError as e:
            raise UpdateError(f'could not read file {url}: {e}' if en else f'не удалось прочитать файл {url}: {e}')
    try:
        headers = {'User-Agent': 'ocbot-self-update'}
        host = urllib.parse.urlparse(url).hostname or ''
        if token and (host == 'github.com' or host.endswith('.github.com') or host.endswith('.githubusercontent.com')):
            headers['Authorization'] = f'token {token}'
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.read()
    except Exception as e:
        raise UpdateError(f'could not download {url}: {e}' if en else f'не удалось скачать {url}: {e}')

def _protected(rel: str) -> bool:
    name = os.path.basename(rel)
    if name == 'config.example.json':
        return False
    return any((fnmatch.fnmatch(name, pat) for pat in PROTECTED))

def _members(zf: zipfile.ZipFile, lang: str='ru') -> tuple:
    en = lang == 'en'
    names = [n for n in zf.namelist() if not n.endswith('/')]
    for n in names:
        if n.startswith('/') or '..' in n.split('/') or '\\' in n:
            raise UpdateError(f'unsafe path in the archive: {n}' if en else f'в архиве небезопасный путь: {n}')
    marks = [n for n in names if n.endswith('ocbot/agent.py')]
    if not marks:
        raise UpdateError('not a bot archive (no ocbot/agent.py)' if en else 'это не архив бота (нет ocbot/agent.py)')
    prefix = marks[0][:-len('ocbot/agent.py')]
    return (prefix, [n for n in names if n.startswith(prefix)])

def check_zip(data: bytes, lang: str='ru') -> tuple:
    en = lang == 'en'
    try:
        zf = zipfile.ZipFile(io.BytesIO(data))
        bad = zf.testzip()
    except zipfile.BadZipFile as e:
        raise UpdateError(f'corrupted archive: {e}' if en else f'архив повреждён: {e}')
    if bad:
        raise UpdateError(f'corrupted archive: {bad}' if en else f'архив повреждён: {bad}')
    prefix, members = _members(zf, lang)
    for n in members:
        rel = n[len(prefix):]
        if rel.startswith('ocbot/') and rel.endswith('.py'):
            try:
                compile(zf.read(n), n, 'exec')
            except SyntaxError as e:
                raise UpdateError(f'error in the new code {n}: {e}' if en else f'в новом коде ошибка {n}: {e}')
    return (zf, prefix, members)

def installed_sha(workdir: str) -> str:
    try:
        with open(os.path.join(workdir, SHA_FILE), encoding='utf-8') as f:
            return f.read().strip()
    except OSError:
        return ''

def install(workdir: str, data: bytes, force: bool=False, lang: str='ru') -> str:
    en = lang == 'en'
    sha = hashlib.sha256(data).hexdigest()
    if not force and sha == installed_sha(workdir):
        return 'This version is already installed, nothing to update.' if en else 'Уже установлена эта версия, обновлять нечего.'
    zf, prefix, members = check_zip(data, lang)
    tmp = os.path.join(workdir, '.update_tmp')
    shutil.rmtree(tmp, ignore_errors=True)
    os.makedirs(tmp)
    try:
        for n in members:
            rel = n[len(prefix):]
            if not rel or _protected(rel):
                continue
            dst = os.path.join(tmp, rel)
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            with open(dst, 'wb') as f:
                f.write(zf.read(n))
        old, prev, new = (os.path.join(workdir, 'ocbot'), os.path.join(workdir, 'ocbot.prev'), os.path.join(tmp, 'ocbot'))
        shutil.rmtree(prev, ignore_errors=True)
        if os.path.isdir(old):
            os.rename(old, prev)
        os.rename(new, old)
        copied = 0
        for root, _, files in os.walk(tmp):
            for fn in files:
                src = os.path.join(root, fn)
                rel = os.path.relpath(src, tmp)
                dst = os.path.join(workdir, rel)
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                shutil.copy2(src, dst)
                copied += 1
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    with open(os.path.join(workdir, SHA_FILE), 'w', encoding='utf-8') as f:
        f.write(sha)
    if en:
        return f'Code updated ({len(data) // 1024} KB, other files updated: {copied}). Configs, database and state are untouched. The previous code was saved to ocbot.prev (rollback: --self-update rollback).'
    return f'Код обновлён ({len(data) // 1024} КБ, прочих файлов обновлено: {copied}). Конфиги, база и состояние не тронуты. Прежний код сохранён в ocbot.prev (откат: --self-update rollback).'

def rollback(workdir: str, lang: str='ru') -> str:
    en = lang == 'en'
    old, prev, tmp = (os.path.join(workdir, n) for n in ('ocbot', 'ocbot.prev', 'ocbot.swap'))
    if not os.path.isdir(prev):
        return "Nothing to roll back to: there's no previous version (ocbot.prev)." if en else 'Откатываться некуда: прежней версии (ocbot.prev) нет.'
    shutil.rmtree(tmp, ignore_errors=True)
    os.rename(old, tmp)
    os.rename(prev, old)
    os.rename(tmp, prev)
    try:
        os.remove(os.path.join(workdir, SHA_FILE))
    except OSError:
        pass
    return 'Reverted to the previous code (the current one was saved to ocbot.prev).' if en else 'Возвращён прежний код (текущий сохранён в ocbot.prev).'

def workdir_of_code() -> str:
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def available_update(workdir: str, url: str, token: str='', lang: str='ru') -> str:
    data = fetch(url, token=token, lang=lang)
    sha = hashlib.sha256(data).hexdigest()
    return sha if sha != installed_sha(workdir) else ''

def verification_running(db, rig: str) -> bool:
    try:
        return any((r['kind'] in ('verify', 'recheck') for r in db.unfinished_runs(rig)))
    except Exception:
        return False
