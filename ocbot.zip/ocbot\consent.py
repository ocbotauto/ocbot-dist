from __future__ import annotations
import json
import os
import time
from typing import Callable
from .state import lang_of as _lang
VERSION = 1
DEFAULT_URL_RU = 'https://ocbot.org/guide.ru.html#terms'
DEFAULT_URL_EN = 'https://ocbot.org/guide.html#terms'
DEFAULT_URL = DEFAULT_URL_RU

def path_of(cfg) -> str:
    return os.path.join(os.path.dirname(os.path.abspath(getattr(cfg, 'license_path', 'license.json'))), 'terms_accepted.json')

def accepted(cfg) -> bool:
    try:
        with open(path_of(cfg), encoding='utf-8') as f:
            return int(json.load(f).get('v', 0)) >= VERSION
    except (OSError, ValueError, TypeError, AttributeError):
        return False

def record(cfg) -> None:
    p = path_of(cfg)
    tmp = p + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump({'v': VERSION, 'date': time.strftime('%Y-%m-%d')}, f)
    os.replace(tmp, p)

def url_of(cfg, lang: str=None) -> str:
    en = (lang or _lang(cfg)) == 'en'
    site = (getattr(cfg, 'site_url', '') or '').rstrip('/')
    suffix = '/guide.html#terms' if en else '/guide.ru.html#terms'
    return site + suffix if site else DEFAULT_URL_EN if en else DEFAULT_URL_RU

def text(cfg, lang: str=None) -> str:
    if (lang or _lang(cfg)) == 'en':
        return 'Before you start, please read the terms and disclaimer:\n  ' + url_of(cfg, lang) + '\n(the same text is in the DISCLAIMER.en.md file next to the bot).\nIn short: the bot changes clock offsets and power limits and reboots the rig on its own; all risk is yours. During the trial, verified presets (without the rig name or card UUIDs) are always sent to the shared catalog; with a license key this can be turned off.'
    return 'Перед началом прочитайте условия и отказ от ответственности:\n  ' + url_of(cfg, lang) + '\n(тот же текст лежит в файле DISCLAIMER.md рядом с ботом).\nКоротко: бот меняет частоты и лимиты мощности и сам перезагружает риг, все риски на вас; на пробном периоде проверенные пресеты (без имени рига и UUID карт) обязательно уходят в общий каталог, с ключом это можно отключить.'

def ensure(cfg, inp: Callable[[str], str]=input, out: Callable[[str], None]=print, assume_yes: bool=False, lang: str=None) -> bool:
    if accepted(cfg):
        return True
    en = (lang or _lang(cfg)) == 'en'
    out(text(cfg, lang))
    if not assume_yes:
        try:
            prompt = 'Have you read the terms and do you agree? Type "yes" (or "да"): ' if en else 'Вы прочитали условия и согласны с ними? Введите «да» (или yes): '
            ans = inp(prompt).strip().lower()
        except (EOFError, OSError):
            ans = ''
        if ans not in ('да', 'д', 'yes', 'y'):
            out('Cannot continue without agreeing. Re-run the command once you have read the terms (in a script: add --accept-terms to confirm you have read and agree).' if en else 'Без согласия продолжить нельзя. Повторите команду, когда прочтёте условия (в скрипте: добавьте --accept-terms, это означает, что вы прочитали и согласны).')
            return False
    record(cfg)
    return True
